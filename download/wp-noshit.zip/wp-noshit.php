<?php
/*
*	Plugin Name: No Shit!
*    	Plugin URI: http://www.village-idiot.org/archives/2007/04/18/wp-noshit/
*   	Description: Filters some profanity
* 	Author: Whoo,William Long
* 	Author URI: http://www.williamlong.info
* 	Version: 1.1
*
*   使用这个插件可以将评论中敏感关键字（也就是所谓的“有害信息”）进行过滤（分隔符|），将敏感文字替换为****。
*
*/


function profanity_comment_filter($content) {

// 修改下面一行的内容，增加你需要的过滤关键字，关键字之间使用分隔符|进行分割。
$banned_contents = "fuck|shit|无界|自由门|明慧|自由亚洲|美国之音|人民报|优美客|花园速递|世界通|火凤凰|动态网|大纪元|胡锦涛|温家宝|胡温|李洪志|法轮|民运|反共|专制|专政|独裁|极权|中共|共产|共党|社会主义|六四|民主|人权|毛泽东|马列主义|中国政府|中央政府|游行示威|天安门|达赖|喇嘛|你妈|他妈|我操|tmd";

$patterns = explode("|", $banned_contents);
$finalremove=$content;
$piece_front="";
$piece_back="";
$piece_replace="****";

    for ($x=0; $x < count($patterns); $x++) {

    $safety=0;

        while(strstr(strtolower($finalremove),strtolower($patterns[$x]))) {
        # find & remove all occurrence
       
        $safety=$safety+1;
        if ($safety >= 100000) { break; }

        $occ=strpos(strtolower($finalremove),strtolower($patterns[$x]));
        $piece_front=substr($finalremove,0,$occ);
        $piece_back=substr($finalremove,($occ+strlen($patterns[$x])));
        $finalremove=$piece_front . $piece_replace . $piece_back;
        } # while
       
    }
	return $finalremove;
}
add_filter('comment_text','profanity_comment_filter');
?>