<?php
/*
Plugin Name: Word Filter
Plugin URI: http://www.williamlong.info/archives/1156.html
Description: This plugin replace keywords you chose with a filter words.
Author: William Long
Version: 1.0
Author URI: http://www.williamlong.info
Licence: GNU
*/

$KeyWordsFilterAds = array(
'MoonlightBlog' => '<a href="http://www.moon-blog.com">MoonlightBlog</a>',
'和谐' => '水产',
'江泽民' => '江澤民',
'李鹏' => '李月月鸟',
'邓小平' => '鄧小×',
'胡锦涛' => '胡錦×',
'温家宝' => '溫家×',
'法轮' => '×輪',
'学潮' => '學潮',
'屠杀' => '屠殺',
);

function KeyWordsFilter($content) {
	global $KeyWordsFilterAds;
	$content = strtr($content, $KeyWordsFilterAds);
	return $content;
}

add_filter('the_content', 'KeyWordsFilter');

?>