<%
'///////////////////////////////////////////////////////////////////////////////
'//              Z-Blog
'// 作    者:    朱煊(zx.asd)
'// 版权所有:    RainbowSoft Studio
'// 技术支持:    rainbowsoft@163.com
'// 程序名称:    
'// 程序版本:    
'// 单元名称:    c_system_base.asp
'// 开始时间:    2005.02.11
'// 最后修改:    
'// 备    注:    
'///////////////////////////////////////////////////////////////////////////////


'定义全局变量
Dim objConn

Dim BlogTitle
Dim BlogUser

Dim BlogPath
BlogPath=Server.MapPath("c_system_base.asp")
BlogPath=Left(BlogPath,Len(BlogPath)-Len("c_system_base.asp"))

Dim StarTime
Dim EndTime
StarTime = Timer()

Dim Categorys()
Dim Users()
Dim Tags()
Dim KeyWords


'*********************************************************
' 目的：    System 初始化
'*********************************************************
Sub System_Initialize()

	On Error Resume Next

	GetReallyDirectory()

	If OpenConnect()=False Then
		If Err.Number<>0 Then Err.Clear
		Call ShowError(4)
	End If

	Set BlogUser =New TUser
	BlogUser.Verify()

	GetCategory()
	GetUser()
	GetTags()
	GetKeyWords()

	LoadGlobeCache

	If Err.Number<>0 Then Call ShowError(10)

End Sub
'*********************************************************




'*********************************************************
' 目的：    System 释放
'*********************************************************
Sub System_Terminate()

	Call CloseConnect()

End Sub
'*********************************************************




'*********************************************************
' 目的：    数据库连接
'*********************************************************
Function OpenConnect()

	'判定是否为子目录调用
	Dim strDbPath

	strDbPath=BlogPath & ZC_DATABASE_PATH

	Set objConn = Server.CreateObject("ADODB.Connection")
	objConn.Open "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strDbPath

	OpenConnect=True

End Function
'*********************************************************




'*********************************************************
' 目的：    DB Disable Connect
'*********************************************************
Function CloseConnect()

	objConn.Close
	Set objConn=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    时间计长
'*********************************************************
Function RunTime()

	EndTime=Timer()
	RunTime = CLng(FormatNumber((EndTime-StarTime)*1000,3))

End Function
'*********************************************************




'*********************************************************
' 目的：    分类读取
'*********************************************************
Function GetCategory()

	Dim i,j,k,l

	Dim aryAllData
	Dim arySingleData()

	Erase Categorys

	Dim objRS

	Set objRS=objConn.Execute("SELECT TOP 1 [cate_ID] FROM [blog_Category] ORDER BY [cate_ID] DESC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		i=objRS("cate_ID")
		ReDim Categorys(i)
	End If
	objRS.Close
	Set objRS=Nothing

	Set objRS=objConn.Execute("SELECT [cate_ID],[cate_Name],[cate_Intro],[cate_Order],[cate_Count] FROM [blog_Category] ORDER BY [cate_ID] ASC")
	If (Not objRS.bof) And (Not objRS.eof) Then

		aryAllData=objRS.GetRows(objRS.RecordCount)
		objRS.Close
		Set objRS=Nothing

		k=UBound(aryAllData,1)
		l=UBound(aryAllData,2)
		For i=0 To l
			Set Categorys(aryAllData(0,i))=New TCategory
			Categorys(aryAllData(0,i)).LoadInfoByArray(Array(aryAllData(0,i),aryAllData(1,i),aryAllData(2,i),aryAllData(3,i),aryAllData(4,i)))
		Next

	End If

	GetCategory=True

End Function
'*********************************************************




'*********************************************************
' 目的：    用户读取
'*********************************************************
Function GetUser()

	Dim i,j,k,l

	Dim aryAllData
	Dim arySingleData()

	Erase Users

	Dim objRS

	Set objRS=objConn.Execute("SELECT TOP 1 [mem_ID] FROM [blog_Member] ORDER BY [mem_ID] DESC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		i=objRS("mem_ID")
		ReDim Users(i)
	End If
	objRS.Close
	Set objRS=Nothing


	Set objRS=objConn.Execute("SELECT [mem_ID],[mem_Name],[mem_Level],[mem_Password],[mem_Email],[mem_HomePage],[mem_PostLogs] FROM [blog_Member] ORDER BY [mem_ID] ASC")
	If (Not objRS.bof) And (Not objRS.eof) Then

		aryAllData=objRS.GetRows(objRS.RecordCount)
		objRS.Close
		Set objRS=Nothing

		k=UBound(aryAllData,1)
		l=UBound(aryAllData,2)
		For i=0 To l
			Set Users(aryAllData(0,i))=New TUser
			Users(aryAllData(0,i)).LoadInfoByArray(Array(aryAllData(0,i),aryAllData(1,i),aryAllData(2,i),aryAllData(3,i),aryAllData(4,i),aryAllData(5,i),aryAllData(6,i)))
		Next

	End If

	Getuser=True

End Function
'*********************************************************




'*********************************************************
' 目的：    Tags读取
'*********************************************************
Function GetTags()

	Dim i,j,k,l

	Dim aryAllData
	Dim arySingleData()

	Erase Tags

	Dim objRS

	Set objRS=objConn.Execute("SELECT TOP 1 [tag_ID] FROM [blog_Tag] ORDER BY [tag_ID] DESC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		i=objRS("tag_ID")
		ReDim Tags(i)
	End If

	Set objRS=objConn.Execute("SELECT [tag_ID],[tag_Name],[tag_Intro],[tag_Order],[tag_Count] FROM [blog_Tag] ORDER BY [tag_ID] ASC")
	If (Not objRS.bof) And (Not objRS.eof) Then

		aryAllData=objRS.GetRows(objRS.RecordCount)
		objRS.Close
		Set objRS=Nothing

		k=UBound(aryAllData,1)
		l=UBound(aryAllData,2)
		For i=0 To l
			Set Tags(aryAllData(0,i))=New TTag
			Tags(aryAllData(0,i)).LoadInfoByArray(Array(aryAllData(0,i),aryAllData(1,i),aryAllData(2,i),aryAllData(3,i),aryAllData(4,i)))
		Next

	End If

	GetTags=True

End Function
'*********************************************************




'*********************************************************
' 目的：    KeyWords读取
'*********************************************************
Function GetKeyWords()

	Dim objRS
	Set objRS=objConn.Execute("SELECT [key_ID],[key_Name],[key_URL] FROM [blog_Keyword] ORDER BY [key_ID] ASC")

	If (Not objRS.bof) And (Not objRS.eof) Then
		KeyWords=objRS.GetRows
	End If

	objRS.Close
	Set objRS=Nothing

	GetKeyWords=True

End Function
'*********************************************************




'*********************************************************
' 目的：    读取权限
' 备注:     权限最高为1 最低为5 不是则非法
'           "Root"一定只能为1
'           权限配置方式可以变通
'*********************************************************
Function GetRights(strAction)

	Select Case strAction

		Case "Root"
			GetRights=1

		Case "login"
			GetRights=5
		Case "verify"
			GetRights=5
		Case "logout"
			GetRights=5
		Case "admin"
			GetRights=4
		Case "cmt"
			GetRights=5
		Case "tb"
			GetRights=5
		Case "vrs"
			GetRights=5
		Case "rss"
			GetRights=5
		Case "gettburl"
			GetRights=5
		Case "ArticleMng"
			GetRights=3
		Case "ArticleEdt"
			GetRights=3
		Case "ArticlePst"
			GetRights=3
		Case "ArticleDel"
			GetRights=3
		Case "ArticleBud"
			GetRights=3
		Case "CategoryMng"
			GetRights=1
		Case "CategoryEdt"
			GetRights=1
		Case "CategoryPst"
			GetRights=1
		Case "CategoryDel"
			GetRights=1
		Case "TagMng"
			GetRights=1
		Case "TagEdt"
			GetRights=1
		Case "TagPst"
			GetRights=1
		Case "TagDel"
			GetRights=1
		'Case "KeyWordMng"
		'	GetRights=1
		'Case "KeyWordEdt"
		'	GetRights=1
		'Case "KeyWordPst"
		'	GetRights=1
		'Case "KeyWordDel"
		'	GetRights=1
		Case "CommentMng"
			GetRights=4
		Case "CommentDel"
			GetRights=4
		Case "CommentDelBatch"
			GetRights=4
		Case "TrackBackMng"
			GetRights=3
		Case "TrackBackDel"
			GetRights=3
		Case "TrackBackDelBatch"
			GetRights=3
		Case "TrackBackSnd"
			GetRights=3
		Case "UserMng"
			GetRights=4
		Case "UserEdt"
			GetRights=4
		Case "UserDel"
			GetRights=1
		Case "UserCrt"
			GetRights=1
		Case "BlogReBuild"
			GetRights=3
		Case "FileReBuild"
			GetRights=1
		Case "AskFileReBuild"
			GetRights=1
		Case "FileMng"
			GetRights=2
		Case "FileSnd"
			GetRights=2
		Case "FileUpload"
			GetRights=2
		Case "FileDel"
			GetRights=2
		Case "FileDelBatch"
			GetRights=2
		Case "Search"
			GetRights=5
		'Case "BlogMng"
		'	GetRights=4
		Case "SettingMng"
			GetRights=1
		Case "SettingSav"
			GetRights=1
		Case "PlugInMng"
			GetRights=4
		Case "SiteInfo"
			GetRights=4
		Case "SiteFileMng"
			GetRights=1
		Case "SiteFileEdt"
			GetRights=1
		'Case "SiteFileFnd"
		'	GetRights=1
		Case "SiteFilePst"
			GetRights=1
		Case "SiteFileDel"
			GetRights=1
		Case "Update"
			GetRights=1

		Case Else Call ShowError(1)

	End Select

End Function
'*********************************************************




'*********************************************************
' 目的：    检查权限
'*********************************************************
Function CheckRights(strAction)

	If BlogUser.Level>GetRights(strAction) Then
		CheckRights=False
	Else
		CheckRights=True
	End If

End Function
'*********************************************************




'*********************************************************
' 目的：    Make Calendar
'*********************************************************
Function MakeCalendar(dtmYearMonth)

	Dim strCalendar

	Dim y
	Dim m
	Dim d
	Dim firw
	Dim lasw
	Dim ny
	Dim nm

	Dim i
	Dim j
	Dim k
	Dim b
	Dim s
	Dim t

	Call CheckParameter(dtmYearMonth,"dtm",Date())

	y=year(dtmYearMonth)
	m=month(dtmYearMonth)
	ny=y
	nm=m+1
	If m=12 Then ny=ny+1:nm=1

	firw=Weekday(Cdate(y&"-"&m&"-1"))

	For i=28 to 32
		If IsDate(y&"-"&m&"-"&i) Then
			lasw=Weekday(Cdate(y&"-"&m&"-"&i))
		Else
			Exit For
		End If
	Next

	d=i-1
	k=1

	If firw>5 Then b=42 Else b=35
	If (d=28) And (firw=1) Then b=28
	If (firw>5) And (d<31) Then b=35


'//////////////////////////////////////////////////////////
'	逻辑处理
	Dim aryDateLink(32)
	Dim aryDateID(32)
	Dim aryDateArticle(32)
	Dim objRS

	Set objRS=Server.CreateObject("ADODB.Recordset")
	objRS.CursorType = adOpenKeyset
	objRS.LockType = adLockReadOnly
	objRS.ActiveConnection=objConn
	objRS.Source=""
	objRS.Open("select [log_ID],[log_CateID],[log_AuthorID],[log_Level],[log_PostTime],[log_Url],[log_Istop] from [blog_Article] where ([log_Level]>2) And ([log_PostTime] BETWEEN #"&y&"-"&m&"-1# AND #"&ny&"-"&nm&"-1#)")

	If (Not objRS.bof) And (Not objRS.eof) Then
		For i=1 To objRS.RecordCount
			j=CInt(Day(CDate(objRS("log_PostTime"))))
			aryDateLink(j)=True
			aryDateID(j)=objRS("log_ID")
			Set aryDateArticle(j)=New TArticle
			aryDateArticle(j).LoadInfobyArray Array(objRS("log_ID"),"",objRS("log_CateID"),"","","",objRS("log_Level"),objRS("log_AuthorID"),objRS("log_PostTime"),"","","",objRS("log_Url"),"")
			objRS.MoveNext
			If objRS.eof Then Exit For
		Next
	End If
	objRS.Close
	Set objRS=Nothing
'//////////////////////////////////////////////////////////

	s=ZC_STATIC_DIRECTORY & "/" &y&"_"&Right("00"&(m-1),2) & "." & ZC_STATIC_TYPE
	t=ZC_STATIC_DIRECTORY & "/" &y&"_"&Right("00"&(m+1),2) & "." & ZC_STATIC_TYPE
	If m=1 Then s=ZC_STATIC_DIRECTORY & "/" &(y-1)&"_12" & "." & ZC_STATIC_TYPE
	If m=12 Then t=ZC_STATIC_DIRECTORY & "/" &(y+1)&"_01" & "." & ZC_STATIC_TYPE

	strCalendar=strCalendar & "<div class=""year"&y&" month"&m&""">"
	strCalendar=strCalendar & "<p class=""y""><a href="""&ZC_BLOG_HOST &s&""">&lt;&lt;</a>  <a href="""& ZC_BLOG_HOST &ZC_STATIC_DIRECTORY & "/"&y&"_"&right("00"&m,2)& "." & ZC_STATIC_TYPE&""">"&y&"·"&m&"</a>  <a href="""&ZC_BLOG_HOST &t&""">&gt;&gt;</a></p>"
	strCalendar=strCalendar & "<p class=""w"">Sun</p><p class=""w"">Mon</p><p class=""w"">Tue</p><p class=""w"">Wen</p><p class=""w"">Thu</p><p class=""w"">Fri</p><p class=""w"">Sat</p>"
	j=0
	For i=1 to b
		If (j=>firw-1) and (k=<d) Then
			If aryDateLink(k) Then
				strCalendar=strCalendar & "<p class=""yd""><a class=""l"" href="""& aryDateArticle(k).Url & """>"&(k)&"</a></p>"
			Else
				strCalendar=strCalendar & "<p class=""d"">"&(k)&"</p>"
			End If

			k=k+1
		Else
			strCalendar=strCalendar & "<p class=""nd""></p>"
		End If
		j=j+1
	Next
	strCalendar=strCalendar & "</div>"
	MakeCalendar=strCalendar

End Function
'*********************************************************




'*********************************************************
' 目的：    Load Cache
'*********************************************************
Function LoadGlobeCache()

	On Error Resume Next

	'加载模板
	Dim objStream
	Dim strContent

	Dim aryFileName(30)
	Dim aryFileName_Variable(30)

	Dim i

	aryFileName( 1)="/INCLUDE/archives.asp"
	aryFileName_Variable( 1)="CACHE_INCLUDE_ARCHIVES"
	aryFileName( 2)="/INCLUDE/authors.asp"
	aryFileName_Variable( 2)="CACHE_INCLUDE_AUTHORS"
	aryFileName( 3)="/INCLUDE/calendar.asp"
	aryFileName_Variable( 3)="CACHE_INCLUDE_CALENDAR"
	aryFileName( 4)="/INCLUDE/catalog.asp"
	aryFileName_Variable( 4)="CACHE_INCLUDE_CATALOG"
	aryFileName( 5)="/INCLUDE/comments.asp"
	aryFileName_Variable( 5)="CACHE_INCLUDE_COMMENTS"
	aryFileName( 6)="/INCLUDE/favorite.asp"
	aryFileName_Variable( 6)="CACHE_INCLUDE_FAVORITE"
	aryFileName( 7)="/INCLUDE/link.asp"
	aryFileName_Variable( 7)="CACHE_INCLUDE_LINK"
	aryFileName( 8)="/INCLUDE/misc.asp"
	aryFileName_Variable( 8)="CACHE_INCLUDE_MISC"
	aryFileName( 9)="/INCLUDE/navbar.asp"
	aryFileName_Variable( 9)="CACHE_INCLUDE_NAVBAR"
	aryFileName(10)="/INCLUDE/previous.asp"
	aryFileName_Variable(10)="CACHE_INCLUDE_PREVIOUS"
	aryFileName(11)="/INCLUDE/statistics.asp"
	aryFileName_Variable(11)="CACHE_INCLUDE_STATISTICS"
	aryFileName(12)="/INCLUDE/tags.asp"
	aryFileName_Variable(12)="CACHE_INCLUDE_TAGS"
	aryFileName(13)="/INCLUDE/calendar.asp"
	aryFileName_Variable(13)="CACHE_INCLUDE_CALENDAR_NOW"
	aryFileName(14)="/INCLUDE/trackbacks.asp"
	aryFileName_Variable(14)="CACHE_INCLUDE_TRACKBACKS"

	aryFileName(15)="/TEMPLATE/b_article_commentpost-verify.html"
	aryFileName_Variable(15)="TEMPLATE_ARTICLE_COMMENTPOST-VERIFY"
	aryFileName(16)="/TEMPLATE/b_article_tag.html"
	aryFileName_Variable(16)="TEMPLATE_ARTICLE_TAG"
	aryFileName(17)="/TEMPLATE/b_article_trackback.html"
	aryFileName_Variable(17)="TEMPLATE_ARTICLE_TRACKBACK"
	aryFileName(18)="/TEMPLATE/b_article-multi.html"
	aryFileName_Variable(18)="TEMPLATE_ARTICLE-MULTI"
	aryFileName(19)="/TEMPLATE/b_article-single.html"
	aryFileName_Variable(19)="TEMPLATE_ARTICLE-SINGLE"
	aryFileName(20)="/TEMPLATE/b_pagebar.html"
	aryFileName_Variable(20)="TEMPLATE_PAGEBAR"
	aryFileName(21)="/TEMPLATE/catalog.html"
	aryFileName_Variable(21)="TEMPLATE_CATALOG"
	aryFileName(22)="/TEMPLATE/default.html"
	aryFileName_Variable(22)="TEMPLATE_DEFAULT"
	aryFileName(23)="/TEMPLATE/search.html"
	aryFileName_Variable(23)="TEMPLATE_SEARCH"
	aryFileName(24)="/TEMPLATE/single.html"
	aryFileName_Variable(24)="TEMPLATE_SINGLE"
	aryFileName(25)="/TEMPLATE/b_article_nvabar_l.html"
	aryFileName_Variable(25)="TEMPLATE_ARTICLE_NVABAR_L"
	aryFileName(26)="/TEMPLATE/b_article_nvabar_r.html"
	aryFileName_Variable(26)="TEMPLATE_ARTICLE_NVABAR_R"
	aryFileName(27)="/TEMPLATE/b_article_comment.html"
	aryFileName_Variable(27)="TEMPLATE_ARTICLE_COMMENT"
	aryFileName(28)="/TEMPLATE/b_article_commentpost.html"
	aryFileName_Variable(28)="TEMPLATE_ARTICLE_COMMENTPOST"
	aryFileName(29)="/TEMPLATE/b_article_mutuality.html"
	aryFileName_Variable(29)="TEMPLATE_ARTICLE_mutuality"
	aryFileName(30)="/TEMPLATE/b_article-Istop.html"
	aryFileName_Variable(30)="TEMPLATE_ARTICLE-Istop"

	Application.Lock
	For i=1 to 30
		strContent=""
		strContent=LoadFromFile(BlogPath & "" & aryFileName(i),"utf-8")
		strContent=Replace(strContent,"<"&"%=ZC_BLOG_HOST%"&">",ZC_BLOG_HOST)
		Application(ZC_BLOG_CLSID & aryFileName_Variable(i))=strContent
	Next
	Application.UnLock


	'加载标签
	Dim a,b,c
	a=14
	b=13
	c=1

	Dim t()
	Dim s()
	Dim j


	ReDim s(a)
	s(1)="CACHE_INCLUDE_STATISTICS"
	s(2)="CACHE_INCLUDE_FAVORITE"
	s(3)="CACHE_INCLUDE_LINK"
	s(4)="CACHE_INCLUDE_MISC"
	s(5)="CACHE_INCLUDE_CALENDAR"
	s(6)="CACHE_INCLUDE_COMMENTS"
	s(7)="CACHE_INCLUDE_PREVIOUS"
	s(8)="CACHE_INCLUDE_ARCHIVES"
	s(9)="CACHE_INCLUDE_TAGS"
	s(10)="CACHE_INCLUDE_CATALOG"
	s(11)="CACHE_INCLUDE_NAVBAR"
	s(12)="CACHE_INCLUDE_AUTHORS"
	s(13)="CACHE_INCLUDE_CALENDAR_NOW"
	s(14)="CACHE_INCLUDE_TRACKBACKS"

	ReDim Preserve aryTemplateTagsName(a)
	ReDim Preserve aryTemplateTagsValue(a)

	Application.Lock 
	For j=1 to a
		aryTemplateTagsName(j)=s(j)
		aryTemplateTagsValue(j)=Application(ZC_BLOG_CLSID & s(j))
	Next
	Application.Unlock


	ReDim Preserve aryTemplateTagsName(a+300)
	ReDim Preserve aryTemplateTagsValue(a+300)
	For j=1 to 300
		i=Right("000" & CStr(j),3)
		aryTemplateTagsName(a+j)="ZC_MSG" & i
		Call Execute("aryTemplateTagsValue(a+j)=ZC_MSG" & i)
	Next


	ReDim t(b)
	t(1)="ZC_BLOG_VERSION"
	t(2)="ZC_BLOG_LANGUAGE"
	t(3)="ZC_BLOG_HOST"
	t(4)="ZC_BLOG_TITLE"
	t(5)="ZC_BLOG_SUBTITLE"
	t(6)="ZC_BLOG_NAME"
	t(7)="ZC_BLOG_SUB_NAME"
	t(8)="ZC_BLOG_CSS"
	t(9)="ZC_BLOG_COPYRIGHT"
	t(10)="ZC_BLOG_MASTER"
	t(11)="ZC_CONTENT_MAX"
	t(12)="ZC_EMOTICONS_FILENAME"
	t(13)="ZC_EMOTICONS_FILESIZE"


	ReDim Preserve aryTemplateTagsName(a+300+b)
	ReDim Preserve aryTemplateTagsValue(a+300+b)
	For j=1 to b
		aryTemplateTagsName(a+300+j)=t(j)
		Call Execute("aryTemplateTagsValue(a+300+j)="& t(j))
		'If t(j)="ZC_BLOG_HOST" Then
		'	aryTemplateTagsValue(a+300+j)=Left("http://"&Request.ServerVariables("HTTP_HOST")&Request.ServerVariables("URL"),InStrRev("http://"&Request.ServerVariables("HTTP_HOST")&Request.ServerVariables("URL"),"/"))
		'End If
	Next

	ReDim Preserve aryTemplateTagsName(a+300+b+c)
	ReDim Preserve aryTemplateTagsValue(a+300+b+c)
	aryTemplateTagsName(a+300+b+1)="BLOG_CREATE_TIME"
	aryTemplateTagsValue(a+300+b+1)=Now

	Application.Lock
	Application(ZC_BLOG_CLSID & "TemplateTagsName")=aryTemplateTagsName
	Application(ZC_BLOG_CLSID & "TemplateTagsValue")=aryTemplateTagsValue
	Application.UnLock

	Err.Clear

	LoadGlobeCache=True

End Function
'*********************************************************




'*********************************************************
' 目的：    Clear Cache
'*********************************************************
Function ClearGlobeCache()

	Application.Lock

	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_ARCHIVES")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_AUTHORS")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_CALENDAR")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_CATALOG")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_COMMENTS")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_FAVORITE")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_LINK")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_MISC")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_NAVBAR")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_PREVIOUS")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_STATISTICS")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_TAGS")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_CALENDAR_NOW")=Empty
	Application(ZC_BLOG_CLSID & "CACHE_INCLUDE_TRACKBACKS")=Empty

	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE_COMMENT")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE_COMMENTPOST")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE_COMMENTPOST-VERIFY")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE_TAG")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE_TRACKBACK")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE-MULTI")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE-SINGLE")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_PAGEBAR")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_CATALOG")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_MULTI")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_SEARCH")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_SINGLE")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE_NVABAR_L")=Empty
	Application(ZC_BLOG_CLSID & "TEMPLATE_ARTICLE_NVABAR_R")=Empty

	Application(ZC_BLOG_CLSID & "TemplateTagsName")=Empty
	Application(ZC_BLOG_CLSID & "TemplateTagsValue")=Empty

	Application(ZC_BLOG_CLSID & "CACHE_ARTICLE_VIEWCOUNT")=Empty

	Application.UnLock

	ClearGlobeCache=True

End Function
'*********************************************************




'*********************************************************
' 目的：    Parse Tag 并格式化
'*********************************************************
Function ParseTag(strTag)

	Dim s
	Dim t
	Dim i
	Dim Tag
	Dim b
	Dim objTag

	strTag=Trim(strTag)
	strTag=TransferHTML(strTag,"[normalname]")
	t=Split(strTag," ")

	GetTags()
	For i=LBound(t) To UBound(t)

		b=False

		For Each Tag in Tags
			If IsObject(Tag) Then
				If UCase(Tag.Name)=UCase(t(i)) Then
					b=True
				End If
			End If
		Next

		If b=False Then
			Set objTag=New TTag
			objTag.ID=0
			objTag.Name=t(i)
			objTag.Order=0
			objTag.Intro=""
			objTag.Post
			Set objTag=Nothing
		End If

	Next

	GetTags()
	For i=LBound(t) To UBound(t)
		For Each Tag in Tags
			If IsObject(Tag) Then
				If UCase(Tag.Name)=UCase(t(i)) Then
					t(i)="{"&Tag.ID&"}"
				End If
			End If
		Next
	Next

	s=Join(t)
	s=Replace(s," ","")

	ParseTag=s

End Function
'*********************************************************




'*********************************************************
' 目的：    得到实际上的真实目录
'*********************************************************
Function GetReallyDirectory()

	On Error Resume Next

	Dim fso
	Set fso = CreateObject("Scripting.FileSystemObject")
	If fso.FileExists(BlogPath & "\" & ZC_DATABASE_PATH) Then
		BlogPath=BlogPath
	ElseIf fso.FileExists(BlogPath & "\..\" & ZC_DATABASE_PATH) Then
		BlogPath=BlogPath & "..\"
	ElseIf fso.FileExists(BlogPath & "\..\..\" & ZC_DATABASE_PATH) Then
		BlogPath=BlogPath & "..\..\"
	ElseIf fso.FileExists(BlogPath & "\..\..\..\" & ZC_DATABASE_PATH) Then
		BlogPath=BlogPath & "..\..\..\"
	ElseIf fso.FileExists(BlogPath & "\..\..\..\..\" & ZC_DATABASE_PATH) Then
		BlogPath=BlogPath & "..\..\..\..\"
	ElseIf fso.FileExists(BlogPath & "\..\..\..\..\..\" & ZC_DATABASE_PATH) Then
		BlogPath=BlogPath & "..\..\..\..\..\"
	End If
	Set fso=Nothing

	GetReallyDirectory=True

	Err.Clear

End Function
'*********************************************************
%>