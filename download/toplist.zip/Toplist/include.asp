﻿<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    文章排行插件
'// 最后修改：   2008-10-6
'// 最后版本:    
'///////////////////////////////////////////////////////////////////////////////

'注册插件
Call RegisterPlugin("Toplist","ActivePlugin_Toplist")

'具体的接口挂接
Function ActivePlugin_Toplist() 

	Call Add_Action_Plugin("Action_Plugin_BlogReBuild_Begin","Call Toplist_Main()")

End Function

'*********************************************************
' 重建排行
'*********************************************************
Function Toplist_Main() 

	Dim i
	Dim objRS
	Dim objStream
	Dim objArticle
	Dim strLogUrl
	Dim maxnum
	Dim strtopyear
	Dim strtopmonth
	Dim strtoprate

	Dim strPrevious
	maxnum = CStr(ZC_PREVIOUS_COUNT)

	'热文排行
	strPrevious=""
	Set objRS=objConn.Execute("SELECT top " & maxnum & " [log_ID],[log_Url],[log_Title] FROM [blog_Article] WHERE [log_Level]>1 ORDER BY log_CommNums*100 + log_TrackBackNums*200 + sqr(log_ViewNums)*10 - (date()-Log_PostTime)*(date()-Log_PostTime) DESC")

	While Not objRS.eof
		strLogUrl=objRS("log_Url")
		If IsNull(strLogUrl) Or IsEmpty(strLogUrl) Or strLogUrl="" Then
			strLogUrl=objRS("log_ID")
		End If
		strLogUrl=ZC_BLOG_HOST & ZC_STATIC_DIRECTORY & "/" & strLogUrl & "." & ZC_STATIC_TYPE
		strPrevious=strPrevious & "<li><a href="""& strLogUrl & """>" & objRS("log_Title") & "</a></li>"
		objRS.MoveNext
	Wend
	objRS.close
	strPrevious=TransferHTML(strPrevious,"[no-asp]")
	Set objStream = Server.CreateObject("ADODB.Stream")
	With objStream
	.Type = adTypeText
	.Mode = adModeReadWrite
	.Open
	.Charset = "utf-8"
	.Position = objStream.Size
	.WriteText = strPrevious
	.SaveToFile BlogPath & "/include/toplist.asp",adSaveCreateOverWrite
	.Close
	End With
	Set objStream = Nothing

	'年度排行
	strPrevious=""
	Set objRS=objConn.Execute("select top " & maxnum & " [log_ID],[log_Url],[log_Title] FROM [blog_Article] WHERE [log_Level]>1 AND (log_PostTime>Now()-360) ORDER BY log_ViewNums DESC")

	While Not objRS.eof
		strLogUrl=objRS("log_Url")
		If IsNull(strLogUrl) Or IsEmpty(strLogUrl) Or strLogUrl="" Then
			strLogUrl=objRS("log_ID")
		End If
		strLogUrl=ZC_BLOG_HOST & ZC_STATIC_DIRECTORY & "/" & strLogUrl & "." & ZC_STATIC_TYPE
		strPrevious=strPrevious & "<li><a href="""& strLogUrl & """>" & objRS("log_Title") & "</a></li>"
		objRS.MoveNext
	Wend
	objRS.close
	strPrevious=TransferHTML(strPrevious,"[no-asp]")
	Set objStream = Server.CreateObject("ADODB.Stream")
	With objStream
	.Type = adTypeText
	.Mode = adModeReadWrite
	.Open
	.Charset = "utf-8"
	.Position = objStream.Size
	.WriteText = strPrevious
	.SaveToFile BlogPath & "/include/topyear.asp",adSaveCreateOverWrite
	.Close
	End With
	Set objStream = Nothing
	strtopyear = strPrevious

	'月度排行
	strPrevious=""
	Set objRS=objConn.Execute("select top " & maxnum & " [log_ID],[log_Url],[log_Title] FROM [blog_Article] WHERE [log_Level]>1 AND (log_PostTime>Now()-30) ORDER BY log_ViewNums DESC")

	While Not objRS.eof
		strLogUrl=objRS("log_Url")
		If IsNull(strLogUrl) Or IsEmpty(strLogUrl) Or strLogUrl="" Then
			strLogUrl=objRS("log_ID")
		End If
		strLogUrl=ZC_BLOG_HOST & ZC_STATIC_DIRECTORY & "/" & strLogUrl & "." & ZC_STATIC_TYPE
		strPrevious=strPrevious & "<li><a href="""& strLogUrl & """>" & objRS("log_Title") & "</a></li>"
		objRS.MoveNext
	Wend
	objRS.close
	strPrevious=TransferHTML(strPrevious,"[no-asp]")
	Set objStream = Server.CreateObject("ADODB.Stream")
	With objStream
	.Type = adTypeText
	.Mode = adModeReadWrite
	.Open
	.Charset = "utf-8"
	.Position = objStream.Size
	.WriteText = strPrevious
	.SaveToFile BlogPath & "/include/topmonth.asp",adSaveCreateOverWrite
	.Close
	End With
	Set objStream = Nothing
	strtopmonth = strPrevious

	'总排行
	strPrevious=""
	Set objRS=objConn.Execute("select top " & maxnum & " [log_ID],[log_Url],[log_Title] FROM [blog_Article] WHERE [log_Level]>1 ORDER BY log_ViewNums DESC")

	While Not objRS.eof
		strLogUrl=objRS("log_Url")
		If IsNull(strLogUrl) Or IsEmpty(strLogUrl) Or strLogUrl="" Then
			strLogUrl=objRS("log_ID")
		End If
		strLogUrl=ZC_BLOG_HOST & ZC_STATIC_DIRECTORY & "/" & strLogUrl & "." & ZC_STATIC_TYPE
		strPrevious=strPrevious & "<li><a href="""& strLogUrl & """>" & objRS("log_Title") & "</a></li>"
		objRS.MoveNext
	Wend
	objRS.close
	strPrevious=TransferHTML(strPrevious,"[no-asp]")
	Set objStream = Server.CreateObject("ADODB.Stream")
	With objStream
	.Type = adTypeText
	.Mode = adModeReadWrite
	.Open
	.Charset = "utf-8"
	.Position = objStream.Size
	.WriteText = strPrevious
	.SaveToFile BlogPath & "/include/topalltime.asp",adSaveCreateOverWrite
	.Close
	End With
	Set objStream = Nothing

	'用户推荐排行
	Dim fs
	Dim filespec
	Dim connstr2
	Dim conn2
	Dim strtopid
	filespec = BlogPath + "PLUGIN\Rating\Rating.mdb"
	Set fs = CreateObject("Scripting.FileSystemObject")
	If fs.FileExists(filespec) Then
		connstr2="DBQ=" + filespec + ";DefaultDir=;DRIVER={Microsoft Access Driver (*.mdb)};" 
		set conn2=server.createobject("ADODB.CONNECTION")
		conn2.open connstr2
		Set objRS = conn2.Execute("select top " & maxnum & " id from Score WHERE (Rnumber>=3) ORDER BY Score desc")
		strtopid = " "
		While Not objRS.EOF
			strtopid = strtopid & "log_ID=" & cstr(objRS("id")) & " or " 
			objRS.movenext
		Wend
		objRS.Close
		set conn2 = Nothing
		strtopid = left (strtopid,len(strtopid)-4) '去掉尾部

		strPrevious=""
		Set objRS=objConn.Execute("select top " & maxnum & " [log_ID],[log_Url],[log_Title] FROM [blog_Article] WHERE [log_Level]>1 AND " + strtopid + " ORDER BY log_ViewNums DESC")

		While Not objRS.eof
			strLogUrl=objRS("log_Url")
			If IsNull(strLogUrl) Or IsEmpty(strLogUrl) Or strLogUrl="" Then
				strLogUrl=objRS("log_ID")
			End If
			strLogUrl=ZC_BLOG_HOST & ZC_STATIC_DIRECTORY & "/" & strLogUrl & "." & ZC_STATIC_TYPE
			strPrevious=strPrevious & "<li><a href="""& strLogUrl & """>" & objRS("log_Title") & "</a></li>"
			objRS.MoveNext
		Wend
		objRS.close
		strPrevious=TransferHTML(strPrevious,"[no-asp]")
		Set objStream = Server.CreateObject("ADODB.Stream")
		With objStream
		.Type = adTypeText
		.Mode = adModeReadWrite
		.Open
		.Charset = "utf-8"
		.Position = objStream.Size
		.WriteText = strPrevious
		.SaveToFile BlogPath & "/include/topdigg.asp",adSaveCreateOverWrite
		.Close
		End With
		Set objStream = Nothing
		strtoprate = strPrevious
	End If
	
End Function


'安装插件
Function InstallPlugin_Toplist

	Call SetBlogHint(Empty,Empty,True)

End Function


'卸载插件
Function UnInstallPlugin_Toplist

	Call SetBlogHint(Empty,Empty,True)

End Function   

%>