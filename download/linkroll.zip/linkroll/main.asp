<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog(http://www.rainbowsoft.org)
'// 插件制作:    zx.asd
'// 备    注:    
'// 最后修改：   
'// 最后版本:    
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<!--<% On Error Resume Next %> -->
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../c_function.asp" -->
<!-- #include file="../../c_system_lib.asp" -->
<!-- #include file="../../c_system_base.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6)

BlogTitle="OPML文件转换工具"


%><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<%=ZC_BLOG_LANGUAGE%>" lang="<%=ZC_BLOG_LANGUAGE%>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Language" content="<%=ZC_BLOG_LANGUAGE%>" />
	<link rel="stylesheet" rev="stylesheet" href="../../CSS/admin.css" type="text/css" media="screen" />
	<script language="JavaScript" src="../../script/common.js" type="text/javascript"></script>
	<title><%=BlogTitle%></title>
</head>
<body>

			<div id="divMain">
<div class="Header">OPML文件转换工具</div>
<div id="divMain2">
<%

%>

<form border="1" name="edit" id="edit" method="post" action="linkroll.asp">
<p>OPML文件内容</p>
<hr/>
<p><textarea name="txtOPML" id="txtOPML" cols="80" rows="15" tabindex="14" ></textarea></p>
<br/>
<p>选项</p>
<hr/>
<p><input checked type="radio" name="chkType" value="true"/>导出HTML格式(link.asp)</p>
<p><input type="radio" name="chkType" value="false"/>导出JS格式(link.js)</p>
<hr/>
<p><input type="submit" class="button" value="提交" name="B1" onclick='' /> </p>
</form>
<br/>
</div>
<script>


</script>
</body>
</html>
<%
Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>

