<%@ CODEPAGE=65001 %>
<%

'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.4及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    Blog Roll的代码
'// 最后修改：   2006-9-2
'// 最后版本:    1.1.0
'///////////////////////////////////////////////////////////////////////////////
%>

<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../c_function.asp" -->
<!-- #include file="../../c_system_lib.asp" -->
<!-- #include file="../../c_system_base.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>3 Then Call ShowError(6) 

Dim strOut 
Dim strType
Dim strXMLfile
Dim strLinkfile

strOut=Request.Form("txtOPML")
strType=Request.Form("chkType")

strXMLfile = Server.MapPath("../../linkroll.opml") '默认的opml文件名

'写文件
Dim objStream
Set objStream = Server.CreateObject("ADODB.Stream")
With objStream
.Type = 2
.Mode = 3
.Open
.Charset = "utf-8"
.Position = objStream.Size
.WriteText = strOut
.SaveToFile strXMLfile,2
.Close
End With
Set objStream = Nothing

set xmlObj = Server.CreateObject("Microsoft.XMLDOM")
' load
xmlObj.async = False
'xmlObj.loadXML(strXML)
xmlObj.load(strXMLfile)

strOut = " "
' parse opml
set objRoot = xmlObj.documentElement
set objChannel = objRoot.selectSingleNode("body")

for each child in objChannel.childNodes 
for each category in child.childnodes 
'strOut = strOut + "<li>" + category + "</li>"
for each item in category.childnodes
title=item.getattribute("title")
url = item.getattribute("htmlUrl")
xmlurl = item.getattribute("xmlUrl") 
strOut = strOut + "<li><a href=""" & url &""" target=_blank>" & title & "</a> (<a href=""" & xmlurl &""" target=_blank>" & "RSS</a>)</li>" 
next
next
next

'判断输出格式
if request.Form("chkType")="true" Then
	strLinkfile = Server.MapPath("../../include/link.asp")   '默认输出的文件名
Else
	strLinkfile = Server.MapPath("../../include/link.js")   '默认输出的文件名
	strOut="document.write('" + strOut + "'); " 
End if

'写文件
Set objStream = Server.CreateObject("ADODB.Stream")
With objStream
.Type = 2
.Mode = 3
.Open
.Charset = "utf-8"
.Position = objStream.Size
.WriteText = strOut
.SaveToFile strLinkfile,2
.Close
End With
Set objStream = Nothing

response.write "转换成功 . 请<a href='javascript:history.go(-1);'>返回</A>. "

' clean up
Set objRoot = Nothing
set objChannel = Nothing
Response.Flush 
set xmlObj = nothing 

Public Function getUrl (strXMLurl)
If strXMLurl<>"" then
intPos = InStrRev (strXMLurl,"/")
getUrl = Left (strXMLurl,intPos)
Else
getUrl = ""
End if
End Function

'grab file from Bloglines
'strXMLfile = "http://www.bloglines.com/export?id=admin"
'strXML = getOpmlFromBloglines (strXMLfile)
Public Function getOpmlFromBloglines (strXMLfile)
Set xmlHTTP = Server.CreateObject("Microsoft.XMLHTTP")
xmlHTTP.Open "GET",strXMLfile,false
xmlHTTP.SetRequestHeader "Content-type", "text/xml"
xmlHTTP.Send
getOpmlFromBlog = xmlHTTP.ResponseText
Set xmlHTTP = Nothing
End Function


Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>
