<?php
/*
Plugin Name: WP-PostViews JavaScript Edition 1.20
Plugin URI: http://www.moon-blog.com/2007/12/wordpress-plugin-wp-postviews-javascript-edition.html
Description: Enables user to display how many times a post/page had been viewed. JavaScript Edition can userd with WP-Cache. 
Version: 1.20
Author: Lester 'GaMerZ' Chan (modified by William Long)
Author URI: http://www.lesterchan.net modified by http://www.moon-blog.com
*/

	include_once('wp-config.php');
	include_once('wp-includes/wp-db.php');

	global $wpdb;
	$postid = $_GET['post_id'];
	if (is_numeric($postid)!=true) {
		exit();
	}
	$strsql = "SELECT meta_value,post_id  FROM  $wpdb->postmeta where meta_key = 'views' and post_id=".$postid ;
    $comments = $wpdb->get_var($strsql);
	if ($comments!='') {
		$comments = $comments +1;
		$strout = $comments;
		$strsql = "UPDATE wp_postmeta set meta_value=".$comments." where meta_key = 'views' and post_id='".$postid."' ";
		$wpdb->query($strsql);
	} else {
		$strout = "1";
		$strsql = "INSERT INTO wp_postmeta(post_id,meta_key,meta_value) VALUES (".$postid.", 'views', '1') ";
		$wpdb->query($strsql);
	}
	// echo "document.write (' ".$strout." views ')"
	echo "try{eval('document.getElementById(\"span_views\").innerHTML=\"".$strout."\"');}catch(e){}";

?>
