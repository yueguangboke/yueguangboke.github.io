﻿<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    反垃圾留言的插件代码
'// 最后修改：   2008-7-9
'// 最后版本:    1.0.0
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../function/c_function.asp" -->
<!-- #include file="../../function/c_function_md5.asp" -->
<!-- #include file="../../function/c_system_lib.asp" -->
<!-- #include file="../../function/c_system_base.asp" -->
<!-- #include file="../../function/c_system_event.asp" -->
<!-- #include file="../../function/c_system_plugin.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6) 

BlogTitle="Z-Blog反垃圾留言系统"

%><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<%=ZC_BLOG_LANGUAGE%>" lang="<%=ZC_BLOG_LANGUAGE%>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Language" content="<%=ZC_BLOG_LANGUAGE%>" />
	<link rel="stylesheet" rev="stylesheet" href="../../CSS/admin.css" type="text/css" media="screen" />
	<script language="JavaScript" src="../../script/common.js" type="text/javascript"></script>
	<title><%=BlogTitle%></title>
</head>
<body>

			<div id="divMain">
<div class="Header">反垃圾留言系统</div>
<div id="divMain2">
<form id="edit" name="edit" method="post">
<%

	Dim tmpSng

	tmpSng=LoadFromFile(BlogPath & "/PLUGIN/antispam/include.asp","utf-8")

	Response.Write "<p><b>相关设置</b></p>"
	Response.Write "<hr/>"

	Dim strZC_cc_opt_comment_blocked
	If LoadValueForSetting(tmpSng,True,"Boolean","cc_opt_comment_blocked",strZC_cc_opt_comment_blocked) Then
		strZC_cc_opt_comment_blocked=TransferHTML(strZC_cc_opt_comment_blocked,"[html-format]")
		Response.Write "<p>※开启关键字阻挡功能:</p><p><input name=""strZC_cc_opt_comment_blocked"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_comment_blocked & """ ONCLICK=""ChangeValue(this);"" /></p><p></p>"
	End If

	Dim strZC_cc_opt_comment_blocked_keyword
	If LoadValueForSetting(tmpSng,True,"String","cc_opt_comment_blocked_keyword",strZC_cc_opt_comment_blocked_keyword) Then
		strZC_cc_opt_comment_blocked_keyword=TransferHTML(strZC_cc_opt_comment_blocked_keyword,"[html-format]")
		Response.Write "<p>※关键字阻挡列表(只要评论里含有下列关键字就会直接被阻挡)(分隔符'|'):</p><p><input name=""strZC_cc_opt_comment_blocked_keyword"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_comment_blocked_keyword & """ /></p><p></p>"
	End If

	Dim strZC_cc_opt_comment_filter
	If LoadValueForSetting(tmpSng,True,"Boolean","cc_opt_comment_filter",strZC_cc_opt_comment_filter) Then
		strZC_cc_opt_comment_filter=TransferHTML(strZC_cc_opt_comment_filter,"[html-format]")
		Response.Write "<p>※开启关键字过滤功能:</p><p><input name=""strZC_cc_opt_comment_filter"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_comment_filter & """ ONCLICK=""ChangeValue(this);"" /></p><p></p>"
	End If

	Dim strZC_cc_opt_comment_filter_keyword
	If LoadValueForSetting(tmpSng,True,"String","cc_opt_comment_filter_keyword",strZC_cc_opt_comment_filter_keyword) Then
		strZC_cc_opt_comment_filter_keyword=TransferHTML(strZC_cc_opt_comment_filter_keyword,"[html-format]")
		Response.Write "<p>※关键字过滤列表(会将评论里含有的关键字替换为'×'字符)(分隔符'|'):</p><p><input name=""strZC_cc_opt_comment_filter_keyword"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_comment_filter_keyword & """ /></p><p></p>"
	End If

	Dim strZC_cc_opt_some_chinese_please
	If LoadValueForSetting(tmpSng,True,"Boolean","cc_opt_some_chinese_please",strZC_cc_opt_some_chinese_please) Then
		strZC_cc_opt_some_chinese_please=TransferHTML(strZC_cc_opt_some_chinese_please,"[html-format]")
		Response.Write "<p>※开启中文汉字检查功能(要求评论中至少包含一个汉字):</p><p><input name=""strZC_cc_opt_some_chinese_please"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_some_chinese_please & """ ONCLICK=""ChangeValue(this);"" /></p><p></p>"
	End If

	Dim strZC_cc_opt_referer_filter
	If LoadValueForSetting(tmpSng,True,"Boolean","cc_opt_referer_filter",strZC_cc_opt_referer_filter) Then
		strZC_cc_opt_referer_filter=TransferHTML(strZC_cc_opt_referer_filter,"[html-format]")
		Response.Write "<p>※防止外部提交评论功能:</p><p><input name=""strZC_cc_opt_referer_filter"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_referer_filter & """ ONCLICK=""ChangeValue(this);"" /></p><p></p>"
	End If
	
	Dim strZC_cc_opt_MaxLinks
	If LoadValueForSetting(tmpSng,True,"Numeric","cc_opt_MaxLinks",strZC_cc_opt_MaxLinks) Then
		strZC_cc_opt_MaxLinks=TransferHTML(strZC_cc_opt_MaxLinks,"[html-format]")
		Response.Write "<p>※允许评论的包含的超连接数目(超过此数目则会直接阻挡):</p><p><input name=""strZC_cc_opt_MaxLinks"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_MaxLinks & """ /></p><p></p>"
	End If

	Dim strZC_cc_opt_HalfHourBlock
	If LoadValueForSetting(tmpSng,True,"Numeric","cc_opt_HalfHourBlock",strZC_cc_opt_HalfHourBlock) Then
		strZC_cc_opt_HalfHourBlock=TransferHTML(strZC_cc_opt_HalfHourBlock,"[html-format]")
		Response.Write "<p>※半个小时内允许最多回复的次数(超过此数目则会自动封IP):</p><p><input name=""strZC_cc_opt_HalfHourBlock"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_HalfHourBlock & """ /></p><p></p>"
	End If

	Dim strZC_cc_opt_ip_filter
	If LoadValueForSetting(tmpSng,True,"String","cc_opt_ip_filter",strZC_cc_opt_ip_filter) Then
		strZC_cc_opt_ip_filter=TransferHTML(strZC_cc_opt_ip_filter,"[html-format]")
		Response.Write "<p>※IP黑名单列表(分隔符'|'):</p><p><input name=""strZC_cc_opt_ip_filter"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_ip_filter & """ /></p><p></p>"
	End If

	Response.Write "<hr/>"
	Response.Write "<p><input type=""submit"" class=""button"" value="""& ZC_MSG087 &""" id=""btnPost"" onclick='document.getElementById(""edit"").action=""savesetting.asp"";' /></p>"


%>

</form>

</div>
<script language="javascript">
function ChangeValue(obj){

	if (obj.value=="True")
	{
	obj.value="False";
	return true;
	}

	if (obj.value=="False")
	{
	obj.value="True";
	return true;
	}
}
</script>
</body>
</html>
<%
Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>

