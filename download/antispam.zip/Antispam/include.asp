﻿<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    反垃圾留言的插件代码
'// 最后修改：   2008-7-9
'// 最后版本:    
'///////////////////////////////////////////////////////////////////////////////


'注册插件
Call RegisterPlugin("Antispam","ActivePlugin_Antispam")


'具体的接口挂接
Function ActivePlugin_Antispam() 

	'挂上接口
	'Filter_Plugin_PostComment_Core
	Call Add_Filter_Plugin("Filter_Plugin_PostComment_Core","Antispam_chkComment")

	'网站管理加上二级菜单项
	Call Add_Response_Plugin("Response_Plugin_SettingMng_SubMenu",MakeSubMenu("Antispam 设置","../plugin/Antispam/setting.asp","m-left",False))

End Function

'开启评论禁止发表关键字过滤(True|False)
Const cc_opt_comment_blocked = True

'评论广告禁止发表关键字过滤(分隔符 | )
Const cc_opt_comment_blocked_keyword = "论坛群发|性感美女|乳腺病|尖锐湿疣|货到付款|汽车配件|推广联盟|劳务派遣|网络兼职|网络赚钱|证件公司|打包机|试验机|打标机|条码|标签纸|灌装机|升降机|升降平台|专业注册|网站建设|域名注册|出租网|六合彩|双色球|铃声下载|手机铃声|和弦铃声|手机游戏|免费铃声|手机窃听|手机监听|成人小电影|激情视频|成人用品|成人电影|激情电影|二手电脑|出售枪支|枪支出售|高压电警棒|麻醉枪|麻醉乙醚|左轮手枪|私服|翻译公司|迷幻药|迷药|麻醉剂|迷昏药|催情药|蒙汗药|情趣用品|三唑仑|春药|张韶涵|诚招加盟|诚信经营|注册香港公司|公司注册|职业杀手|奇迹世界|工作服|免费电影|搬家公司|wow|href=|.cn|FUCK"

'开启评论关键字过滤(True|False)
Const cc_opt_comment_filter = True

'评论广告关键字过滤(分隔符 | )
Const cc_opt_comment_filter_keyword = "无界|自由门|大纪元|九评|江泽民|胡锦涛|温家宝|胡温|李洪志|法轮|民运|西藏|反共|专制|专政|独裁|极权|中共|共产|共党|社会主义|六四|民主|人权|毛泽东|马列主义|中国政府|中央政府|游行示威|天安门|达赖|喇嘛|你妈|他妈|我操|党|屁|TMD"

'开启中文汉字检查
Const cc_opt_some_chinese_please = True

'开启提交来源检查
Const cc_opt_referer_filter = False

'IP黑名单列表(分隔符 | )
Const cc_opt_ip_filter = "10.0.0.1|192.168.*.*|222.69.12.133"

'允许发布的连接最大数目，如果禁止使用，则直接为0，使用0后将最大限度禁止广告链接
Const cc_opt_MaxLinks = 15

'如果30分钟内回复/评论连续超过一定数目，则该IP和用户名将被列入黑名单
Const cc_opt_HalfHourBlock = 30

'配置结束


'*********************************************************
' 目的：    检查评论
'*********************************************************
Function Antispam_chkComment(ByRef objComment)

	Call chkIplock()
	
	If cc_opt_some_chinese_please = True Then
		Call chkChinese(objComment.Content)
	End If

	If cc_opt_referer_filter = True Then
		Call chkReferer()
	End If
	
	Call chkLinks(objComment.Content)

	If cc_opt_comment_blocked = True Then
		Call chkBadWord(objComment.Author)
		Call chkBadWord(objComment.Content)
	End If
	
	If cc_opt_comment_filter = True Then
		objComment.Author=filterBadWord(objComment.Author)
		objComment.Content=filterBadWord(objComment.Content)
	End If

	Call chkHalfHour ()

End Function


'*********************************************************
' 目的：    检查引用
'*********************************************************
Function chkTrackBack(objTrackBack)

	Call chkIplock()

	If cc_opt_comment_blocked = True Then
		Call chkBadWord(objTrackBack.Title)
		Call chkBadWord(objTrackBack.Blog)
		Call chkBadWord(objTrackBack.Excerpt)
	End If
	
	If cc_opt_comment_filter = True Then
		objTrackBack.Title=filterBadWord(objTrackBack.Title)
		objTrackBack.Blog=filterBadWord(objTrackBack.Blog)
		objTrackBack.Excerpt=filterBadWord(objTrackBack.Excerpt)
	End If

	Set chkTrackBack=objTrackBack

End Function


'*********************************************************
' 目的：    检查禁用的关键字
'*********************************************************
Function chkBadWord(strInput)
    Dim i
    Dim strOutput
    Dim strFilter
	strOutput = strInput
    strFilter = Split(cc_opt_comment_blocked_keyword, "|")
	For i = 0 To UBound(strFilter)
		If InStr (strOutput, strFilter(i)) > 0 Then
			ExitError "提交信息包含非法词语。"
		End If
    Next
End Function


'*********************************************************
' 目的：    屏蔽替换非法关键字
'*********************************************************
Function filterBadWord(strInput)
    Dim i
    Dim strOutput
    Dim strFilter
    strOutput = strInput
    strFilter = Split(cc_opt_comment_filter_keyword, "|")
	For i = 0 To UBound(strFilter)
		strOutput = Replace(strOutput, strFilter(i), String(Len(strFilter(i)), "×"))
    Next
    filterBadWord = strOutput
End Function


'*********************************************************
' 目的：    检查评论是否包含汉字
'*********************************************************
Function chkChinese(strInput)
    Dim c,e   
    c=Ubound(Split(escape(strInput),"%u"))   
    'e=len(strInput)-c   ' chinese num c, english num e 
	If c = 0 Then
		ExitError "Your comment message must contain at least one chinese word!"
	End if
End Function


'*********************************************************
' 目的：    检查提交来源
'*********************************************************
Function chkReferer()
	'防止垃圾留言功能开始
	dim ComeUrl,cUrl
	ComeUrl=lcase(trim(request.ServerVariables("HTTP_REFERER")))
	if ComeUrl="" then
		ExitError "不允许直接输入地址访问本页面。"
	else
		cUrl=trim("http://" & Request.ServerVariables("SERVER_NAME"))
		if mid(ComeUrl,len(cUrl)+1,1)=":" then
			cUrl=cUrl & ":" & Request.ServerVariables("SERVER_PORT")
		end if
		cUrl=lcase(cUrl & request.ServerVariables("SCRIPT_NAME"))
		if lcase(left(ComeUrl,instrrev(cUrl,"/")))<>lcase(left(cUrl,instrrev(cUrl,"/"))) then
			ExitError "禁止从外部链接地址提交留言。"
		end if
	end if
	'防止垃圾留言功能结束
End Function



'*********************************************************
' 目的：    检查IP地址黑名单
'*********************************************************
Function chkIplock()
	Dim IPlock
	Dim locklist
	Dim i, StrUserIP, StrKillIP, userip
	IPlock = False
	locklist = Trim(cc_opt_ip_filter)
	If locklist = "" Then Exit Function
	userip = request.ServerVariables("HTTP_X_FORWARDED_FOR")
	If userip = "" Then userip = request.ServerVariables("REMOTE_ADDR")
	StrUserIP = userip
	locklist = Split(locklist, "|")
	If StrUserIP = "" Then Exit Function
	StrUserIP = Split(userip, ".")
	If UBound(StrUserIP) <> 3 Then Exit Function
	For i = 0 To UBound(locklist)
		locklist(i) = Trim(locklist(i))
	    If locklist(i) <> "" Then
			StrKillIP = Split(locklist(i), ".")
			If UBound(StrKillIP) <> 3 Then Exit For
			IPlock = True
			If (StrUserIP(0) <> StrKillIP(0)) And InStr(StrKillIP(0), "*") = 0 Then IPlock = False
			If (StrUserIP(1) <> StrKillIP(1)) And InStr(StrKillIP(1), "*") = 0 Then IPlock = False
			If (StrUserIP(2) <> StrKillIP(2)) And InStr(StrKillIP(2), "*") = 0 Then IPlock = False
			If (StrUserIP(3) <> StrKillIP(3)) And InStr(StrKillIP(3), "*") = 0 Then IPlock = False
			If IPlock Then Exit For
	    End If
	Next
	chkIplock = IPlock
	
	If IPlock=True Then ExitError("你的IP地址被禁用")
	
End Function


'*********************************************************
' 目的：    检查文章的连接数，自动封IP地址
'*********************************************************
Function chkLinks(strInput)

	Dim SRegExp,Matches
	Dim userip
	Set SRegExp=New RegExp
	SRegExp.IgnoreCase =True
	SRegExp.Global=True
	SRegExp.Pattern="https:|http:"
	Set Matches = SRegExp.Execute(strInput)
	If Matches.count>cc_opt_MaxLinks Then 
		Set SRegExp=Nothing
		chkLinks=False
		Call ExitError("提交信息包含太多的超链接。")
	End If
	Set SRegExp=Nothing
	If len(strInput)<=5 Then
		chkLinks=False
		Call ExitError("提交信息内容太短。")
	End If
	
	chkLinks=True
	
End Function


'*********************************************************
' 目的：    检查回复频度，自动封IP地址
'*********************************************************
Function chkHalfHour()
	'内容过滤字前面已经处理过，此处进行重复性处理
	Dim objRSchk,userip
	userip = request.ServerVariables("HTTP_X_FORWARDED_FOR")
	If userip = "" Then userip = request.ServerVariables("REMOTE_ADDR")

	Set objRSchk=objConn.Execute("Select count(comm_ID) as maxnum From blog_Comment Where comm_IP='" & userip & "' And datediff('n',comm_PostTime,now())<=30")
	If objRSchk("maxnum") >= cc_opt_HalfHourBlock Then
		'加入黑名单
		AddBlockList userip
		Call ExitError("警告：系统判断你可能在发送垃圾广告，因此你的IP已经被加入黑名单，如果你认为这是误判，请联系系统管理员解封。")
	End If
	Set objRSchk = Nothing
End Function


'*********************************************************
' 目的：    加入IP黑名单
'*********************************************************
Function AddBlockList(strIP)
	Dim strContent,strZC_cc_opt_ip_filter
	strContent=LoadFromFile(BlogPath & "/PLUGIN/antispam/include.asp","utf-8")
	If LoadValueForSetting(strContent,True,"String","cc_opt_ip_filter",strZC_cc_opt_ip_filter) Then
		Call SaveValueForSetting(strContent,True,"String","cc_opt_ip_filter",strZC_cc_opt_ip_filter + "|" + strIP)
		Call SaveToFile(BlogPath & "/PLUGIN/antispam/include.asp",strContent,"utf-8",False)
	End If
End Function



'*********************************************************
' 目的：    错误退出
'*********************************************************
Function ExitError(strInput)
	If IsEmpty(Request.Form("inpAjax"))=False Then
		Call RespondError(vbObjectError+1,strInput)
		Response.End
	End If
	Response.Redirect ZC_BLOG_HOST & "function/c_error.asp?errorid=" & 0 & "&number=" & (vbObjectError+1) & "&description=" & Server.URLEncode(strInput) & "&source="
End Function

%>