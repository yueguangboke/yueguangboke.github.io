﻿<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    反垃圾留言的插件代码
'// 最后修改：   2008-7-9
'// 最后版本:    1.0.0
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../function/c_function.asp" -->
<!-- #include file="../../function/c_function_md5.asp" -->
<!-- #include file="../../function/c_system_lib.asp" -->
<!-- #include file="../../function/c_system_base.asp" -->
<!-- #include file="../../function/c_system_event.asp" -->
<!-- #include file="../../function/c_system_plugin.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6) 

	Dim strContent
	strContent=LoadFromFile(BlogPath & "/PLUGIN/antispam/include.asp","utf-8")

	Dim strZC_cc_opt_comment_blocked
	strZC_cc_opt_comment_blocked=Request.Form("strZC_cc_opt_comment_blocked")
	Call SaveValueForSetting(strContent,True,"Boolean","cc_opt_comment_blocked",strZC_cc_opt_comment_blocked)

	Dim strZC_cc_opt_comment_blocked_keyword
	strZC_cc_opt_comment_blocked_keyword=Request.Form("strZC_cc_opt_comment_blocked_keyword")
	Call SaveValueForSetting(strContent,True,"String","cc_opt_comment_blocked_keyword",strZC_cc_opt_comment_blocked_keyword)

	Dim strZC_cc_opt_comment_filter
	strZC_cc_opt_comment_filter=Request.Form("strZC_cc_opt_comment_filter")
	Call SaveValueForSetting(strContent,True,"Boolean","cc_opt_comment_filter",strZC_cc_opt_comment_filter)

	Dim strZC_cc_opt_comment_filter_keyword
	strZC_cc_opt_comment_filter_keyword=Request.Form("strZC_cc_opt_comment_filter_keyword")
	Call SaveValueForSetting(strContent,True,"String","cc_opt_comment_filter_keyword",strZC_cc_opt_comment_filter_keyword)

	Dim strZC_cc_opt_some_chinese_please
	strZC_cc_opt_some_chinese_please=Request.Form("strZC_cc_opt_some_chinese_please")
	Call SaveValueForSetting(strContent,True,"Boolean","cc_opt_some_chinese_please",strZC_cc_opt_some_chinese_please)

	Dim strZC_cc_opt_referer_filter
	strZC_cc_opt_referer_filter=Request.Form("strZC_cc_opt_referer_filter")
	Call SaveValueForSetting(strContent,True,"Boolean","cc_opt_referer_filter",strZC_cc_opt_referer_filter)

	Dim strZC_cc_opt_ip_filter
	strZC_cc_opt_ip_filter=Request.Form("strZC_cc_opt_ip_filter")
	Call SaveValueForSetting(strContent,True,"String","cc_opt_ip_filter",strZC_cc_opt_ip_filter)

	Dim strZC_cc_opt_MaxLinks
	strZC_cc_opt_MaxLinks=Request.Form("strZC_cc_opt_MaxLinks")
	Call SaveValueForSetting(strContent,True,"Numeric","cc_opt_MaxLinks",strZC_cc_opt_MaxLinks)

	Dim strZC_cc_opt_HalfHourBlock
	strZC_cc_opt_HalfHourBlock=Request.Form("strZC_cc_opt_HalfHourBlock")
	Call SaveValueForSetting(strContent,True,"Numeric","cc_opt_HalfHourBlock",strZC_cc_opt_HalfHourBlock)

	Call SaveToFile(BlogPath & "/PLUGIN/antispam/include.asp",strContent,"utf-8",False)


Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>
<script type="text/javascript">window.location="setting.asp"</script>
