<?php
/*
Plugin Name: WordPress 2.0 Plugin: WP-Stats 2.0
Plugin URI: http://lesterchan.net/portfolio/programming.php
Description: WordPress Statistics
Version: 2.0
Author: Lester 'GaMerZ' Chan
Author URI: http://lesterchan.net
*/

### Require WordPress Header
require(dirname(__FILE__).'/wp-blog-header.php');

### Variables Variables Variables
$comment_author = urldecode(strip_tags(stripslashes(trim($_GET['author']))));
$page = intval($_GET['page']);

### Function: Get Total Posts
function get_totalpostsyear($BlogYear = 2007) {
	global $wpdb;
	$totalposts = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->posts WHERE post_status = 'publish' and year(post_date)=".$BlogYear." ");
	echo $totalposts;
}
### Function: Get Total Comments
function get_totalcommentsyear($BlogYear = 2007) {
	global $wpdb;
	$totalcomments = $wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_approved = '1' and year(comment_date)=".$BlogYear." ");
	echo $totalcomments;
}

function get_month_most_viewed($mode = '', $limit = 5, $days = 30, $BlogYear, $BlogMonth = 1,$display = true) {
	global $wpdb, $post;	
	$limit_date = current_time('timestamp') - ($days*86400); 
	$limit_date = date("Y-m-d H:i:s",$limit_date);	
	$where = '';
	$temp = '';
	if(!empty($mode) && $mode != 'both') {
		$where = "post_type = '$mode'";
	} else {
		$where = '1=1';
	}
	$most_viewed = $wpdb->get_results("SELECT DISTINCT $wpdb->posts.*, (meta_value+0) AS views FROM $wpdb->posts LEFT JOIN $wpdb->postmeta ON $wpdb->postmeta.post_id = $wpdb->posts.ID WHERE year(post_date) = '".$BlogYear."' AND month(post_date) = '".$BlogMonth."' AND $where AND post_status = 'publish' AND meta_key = 'views' AND post_password = '' ORDER  BY views DESC LIMIT $limit");
	if($most_viewed) {
		foreach ($most_viewed as $post) {
			$post_title = get_the_title();
			$post_views = intval($post->views);
			$post_views = number_format($post_views);
			$temp .= "<li><a href=\"".get_permalink()."\">$post_title</a> - $post_views ".__('views', 'wp-postviews')."</li>";
		}
	} else {
		$temp = '<li>'.__('N/A', 'wp-postviews').'</li>'."\n";
	}
	if($display) {
		echo $temp;
	} else {
		return $temp;
	}
}

### Function: Get Total Posts
function get_totalposts() {
	global $wpdb;
	$totalposts = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->posts WHERE post_status = 'publish'");
	echo $totalposts;
}

### Function: Get Total Pages
function get_totalpages() {
	global $wpdb;
	$totalpages = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->posts WHERE post_status = 'static'");
	echo $totalpages;
}

### Function: Get Total Comments
function get_totalcomments() {
	global $wpdb;
	$totalcomments = $wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_approved = '1'");
	echo $totalcomments;
}

### Function: Get Total Comments Poster
function get_totalcommentposters() {
	global $wpdb;
	$totalcommentposters = $wpdb->get_var("SELECT COUNT(DISTINCT comment_author) FROM $wpdb->comments WHERE comment_approved = '1'");
	echo $totalcommentposters;
}

### Function: Get Total Links
function get_totallinks() {
	global $wpdb;
	$totallinks = $wpdb->get_var("SELECT COUNT(link_id) FROM $wpdb->links");
	echo $totallinks;
}

### Function: Get Recent Posts
function get_recentposts($limit = 10) {
    global $wpdb, $post;
    $recentposts = $wpdb->get_results("SELECT $wpdb->posts.ID, post_title, post_name, post_date, user_login FROM $wpdb->posts LEFT JOIN $wpdb->users ON $wpdb->users.ID = $wpdb->posts.post_author WHERE post_date < '".current_time('mysql')."' AND post_status = 'publish' AND post_password = '' ORDER  BY post_date DESC LIMIT $limit");
    foreach ($recentposts as $post) {
			$post_title = htmlspecialchars(stripslashes($post->post_title));
			$post_date = mysql2date('d.m.Y', $post->post_date);
			$user_nickname = htmlspecialchars(stripslashes($post->user_login));
			echo "<li>$post_date - <a href=\"".get_permalink()."\">$post_title</a> ($user_nickname)</li>";
    }
}

### Function: Get Recent Comments
function get_recentcomments($limit = 10) {
    global $wpdb, $post;
    $recentcomments = $wpdb->get_results("SELECT $wpdb->posts.ID, post_title, post_name, comment_author, post_date, comment_date FROM $wpdb->posts INNER JOIN $wpdb->comments ON $wpdb->posts.ID = $wpdb->comments.comment_post_ID WHERE comment_approved = '1' AND post_date < '".current_time('mysql')."' AND (post_status = 'publish' OR post_status = 'static') AND post_password = '' ORDER  BY comment_date DESC LIMIT $limit");
    foreach ($recentcomments as $post) {
			$post_title = htmlspecialchars(stripslashes($post->post_title));
			$comment_author = htmlspecialchars(stripslashes($post->comment_author));
			$comment_date = mysql2date('d.m.Y @ H:i', $post->comment_date);
			echo "<li>$comment_date - $comment_author (<a href=\"".get_permalink()."\">$post_title</a>)</li>";
    }
}

### Function: Get Top Commented Posts
function get_mostcommented($limit = 10) {
    global $wpdb, $post;
    $mostcommenteds = $wpdb->get_results("SELECT  $wpdb->posts.ID, post_title, post_name, post_date, COUNT($wpdb->comments.comment_post_ID) AS 'comment_total' FROM $wpdb->posts LEFT JOIN $wpdb->comments ON $wpdb->posts.ID = $wpdb->comments.comment_post_ID WHERE comment_approved = '1' AND post_date < '".current_time('mysql')."' AND post_status = 'publish' AND post_password = '' GROUP BY $wpdb->comments.comment_post_ID ORDER  BY comment_total DESC LIMIT $limit");
    foreach ($mostcommenteds as $post) {
			$post_title = htmlspecialchars(stripslashes($post->post_title));
			$comment_total = (int) $post->comment_total;
			echo "<li><a href=\"".get_permalink()."\">$post_title</a> - $comment_total comments</li>";
    }
}

### Function: Get Comments' Members Stats
// Treshhold = Number Of Posts User Must Have Before It Will Display His Name Out
// 5 = Default Treshhold; -1 = Disable Treshhold
function get_commentmembersstats($threshhold = -1) {
	global $wpdb;
	$comments = $wpdb->get_results("SELECT comment_author, COUNT(comment_ID) AS 'comment_total' FROM $wpdb->comments WHERE comment_approved = '1' GROUP BY comment_author ORDER BY comment_total DESC");
    foreach ($comments as $comment) {
			$comment_author = strip_tags(stripslashes($comment->comment_author));
			$comment_author_link = urlencode($comment_author);
			$comment_total = intval($comment->comment_total);
			echo "<li><a href=\"wp-stats.php?author=$comment_author_link\">$comment_author</a> ($comment_total)</li>";
			// If Total Comments Is Below Threshold
			if($comment_total <= $threshhold && $threshhold != -1) {
				return;
			}
    }
}

### Function: Get Poll Total Questions
function get_pollquestions() {
	global $wpdb;
	if(function_exists('get_poll')) {
		$totalpollq = $wpdb->get_var("SELECT COUNT(pollq_id) FROM $wpdb->pollsq");
		echo $totalpollq;
	}
}

### Function: Get Poll Total Answers
function get_pollanswers() {
	global $wpdb;
	if(function_exists('get_poll')) {
		$totalpolla = $wpdb->get_var("SELECT COUNT(polla_aid) FROM $wpdb->pollsa");
		echo $totalpolla;
	}
}

### Function: Get Poll Total Votes
function get_pollvotes() {
	global $wpdb;
	if(function_exists('get_poll')) {
		$totalpollip = $wpdb->get_var("SELECT COUNT(pollip_id) FROM $wpdb->pollsip");
		echo $totalpollip;
	}
}
?>
<?php get_header(); ?>
	<div id="content" class="narrowcolumn">
<?php
	### Default wp-stats.php Page
	if(empty($comment_author)) {
?>
		<h2 class="pagetitle">概况</h2>
			<ul>
				<li><b>2007年共有<?php get_totalpostsyear(); ?></b>条日志</li>
				<li><b>2007年共有<?php get_totalcommentsyear(); ?></b>条评论</li>
			</ul>
<?php 
for ($intMonth=1; $intMonth<=12; $intMonth=$intMonth+1) {
?>
		<h2 class="pagetitle"><?php echo $intMonth?>月文章排行</h2>
			<ul><?php get_month_most_viewed("both",5,30,2007,$intMonth); ?></ul>

<?php 
} 
?>
<?php
	### Displaying Comments Posted By User
	} else {
		// Number Of Comments Per Page
		$perpage = 10;
		// Comment Author Link
		$comment_author_link = urlencode($comment_author);
		// Total Comments Posted By User
		$totalcomments = $wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_author='$comment_author'");
		// Checking $page and $offset
		if (empty($page) || $page == 0) { $page = 1; }
		if (empty($offset)) { $offset = 0; }
		// Determin $offset
		$offset = ($page-1) * $perpage;
		// Some Comments Stats
		if(($offset + $perpage) > $totalcomments) { $maxonpage = $totalcomments ; } else { $maxonpage = ($offset+$perpage); }
		if (($offset + 1) > ($totalcomments)) { $displayonpage = $totalcomments ; } else { $displayonpage = ($offset+1); }
		// Count Total Pages
		$totalpages = ceil($totalcomments/$perpage);
		// Getting The Comments
		$gmz_comments =  $wpdb->get_results("SELECT $wpdb->posts.ID, comment_author, comment_date, comment_content, ID, comment_ID, post_date, post_title, post_name FROM $wpdb->comments INNER  JOIN $wpdb->posts ON $wpdb->comments.comment_post_ID = $wpdb->posts.ID WHERE comment_author =  '$comment_author' AND comment_approved = '1' AND post_date < '".current_time('mysql')."' AND (post_status = 'publish' OR post_status = 'static') ORDER  BY comment_post_ID DESC, comment_date DESC  LIMIT $offset, $perpage");
?>
		<h2 class="pagetitle">评论由<?php echo $comment_author; ?>发布</h2>
		<p>显示第<b><?php echo $displayonpage; ?></b>页，共有<b><?php echo $maxonpage; ?></b>页， 共有<b><?php echo $totalcomments; ?></b> 个评论</p>
		<?php
			foreach($gmz_comments as $post) {
				$comment_id = intval($post-> comment_ID);
				$comment_author2 = htmlspecialchars(stripslashes($post->comment_author));
				$comment_date = mysql2date('d.m.Y @ H:i', $post->comment_date);
				$comment_content = wpautop(stripslashes($post->comment_content));
				$post_date = mysql2date('d.m.Y @ H:i', $post->post_date);
				$post_title = htmlspecialchars(stripslashes($post->post_title));

				// If New Title, Print It Out
				if($post_title != $cache_post_title) {
					echo "<p><b><a href=\"".get_permalink()."\" title=\"Posted On $post_date\">$post_title</a></b></p>";
				}
				echo "<blockquote>$comment_content <a href=\"".get_permalink()."#comment-$comment_id\">Comment</a> Posted By <b>$comment_author2</b> On $comment_date</blockquote>";

				$cache_post_title = $post_title;
			}
		?>
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
			<tr>
				<td align="left" width="50%">
					<br />
					<?php
						if($page > 1 && ((($page*$perpage)-($perpage-1)) < $totalcomments)) {
							echo '<p><b>&laquo;</b> <a href="wp-stats.php?author='.$comment_author_link.'&amp;page='.($page-1).'">Previous Page</a></p>';
						} else {
							echo '<p>&nbsp;</p>';
						}
					?>
				</td>
				<td align="right" width="50%">
					<br />
					<?php
						if($page >= 1 && ((($page*$perpage)+1) <  $totalcomments)) {
							echo '<p><a href="wp-stats.php?author='.$comment_author_link.'&amp;page='.($page+1).'">Next page</a> <b>&raquo;</b></p>';
						} else {
							echo '<p>&nbsp;</p>';
						}
					?>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center">
					<br />
					<p>页 (<?php echo $totalpages; ?>):
					<?php
						if ($page >= 4) {
							echo "<a href=\"wp-stats.php?author=$comment_author_link\">&laquo; First</a> ... ";
						}
						if($page > 1) {
							echo " <a href=\"wp-stats.php?author=$comment_author_link&amp;page=".($page-1)."\">&laquo;</a> ";
						}
						for($i = $page - 2 ; $i  <= $page +2; $i++) {
							if ($i >= 1 && $i <= $totalpages) {
								if($i == $page) {
									echo "[$i]";
								} else {
									echo "<a href=\"wp-stats.php?author=$comment_author_link&amp;page=$i\">$i</a> ";
								}
							}
						}
						if($page < $totalpages) {
							echo " <a href=\"wp-stats.php?author=$comment_author_link&amp;page=".($page+1)."\">&raquo;</a> ";
						}
						if (($page+2) < $totalpages) {
							echo " ... <a href=\"wp-stats.php?author=$comment_author_link&amp;page=$totalpages\">Last &raquo;</a>";
						}
					?>
					</p>
				</td>
			</tr>
		</table>	
		<p><b>&laquo;&laquo;</b> </p>
<?php
	} // End If
?>
	</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>