<?php 
/* 
Plugin Name: WordPress Adsense
Version: 1.0
Plugin URI: http://www.moon-blog.com/2007/12/wordpress-mu-adsense-plugin.html
Description: Inserts Google Adsense inside your posts where you see fit.
Author: William Long
Author URI: http://www.moon-blog.com
*/ 

function insert_adsense_code($data) { 
    
/**************************************************************************
** Replace this HTML code with your own customized Google Adsense code.  **
**************************************************************************/

    $adsense_code = '
<!-- Begin Google Adsense code -->

<div style="float: left;margin: 4px;">
<script type="text/javascript"><!--
google_ad_client = "pub-";
google_ad_slot = "";
google_ad_width = 300;
google_ad_height = 250;
//--></script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>

<!-- End Google Adsense code -->
'; 

/**************************************************************************
** All done!  No more changes need to be made below this line!           **
**************************************************************************/

	if (is_single()) {
		return $adsense_code . $data ;
	} else {
	    return $data ;
	}
} 

add_filter('the_content', 'insert_adsense_code'); 

?>