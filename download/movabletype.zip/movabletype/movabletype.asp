<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// ���Ӧ��:    Z-Blog 1.4�����ϵİ汾
'// �������:    williamlong(http://www.williamlong.info)
'// ��    ע:    Z-BLOGת����Movable Type�ĳ���
'// ����޸ģ�   2006-1-4
'// ���汾:    1.2.1
'// ��    ע:    zx.asd��williamlong��1.1�����޸�,williamlong�ٽ����˼����޸�
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../c_function.asp" -->
<!-- #include file="../../c_system_lib.asp" -->
<!-- #include file="../../c_system_base.asp" -->
<!-- #include file="../../c_system_event.asp" -->
<%
Server.ScriptTimeout = 3000
Response.ContentType = "application/x-macbinary"

Call System_Initialize()

'���Ƿ�����
Call CheckReference("")

'���Ȩ��
If BlogUser.Level>1 Then Call ShowError(6) 

Call Export_MT(CLng(Request.Form("inpMin")),CLng(Request.Form("inpMax")),CBool(Request.Form("chkCnt")),CBool(Request.Form("chkInr")),CBool(Request.Form("chkTag")),CBool(Request.Form("chkCmt")),CBool(Request.Form("chkTb")))

Function Export_MT(intIDMin,intIDMax,bolCnt,bolInr,bolTag,bolCmt,bolTb)

	Call CheckParameter(intIDMin,"int",0)
	Call CheckParameter(intIDMax,"int",0)

	Dim strOut

	Dim objRS
	Dim objSubRS
	Dim i,j,k,s,t

	Dim objArticle
	Dim objComment
	Dim objTrackBack

	strOut=""
	strOut=strOut+vbcrlf

	Set objRS=objConn.Execute("SELECT * FROM [blog_Article] WHERE ([log_Level]>0) AND (log_id>="&intIDMin&") AND (log_id<="&intIDMax&") ORDER BY [log_PostTime] ASC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		Do While Not objRS.eof

			Set objArticle=New TArticle
			If objArticle.LoadInfoByID(objRS("log_ID")) Then

				strOut=strOut+"AUTHOR: "+Users(objArticle.AuthorID).Name+vbcrlf
				strOut=strOut+"TITLE: "+objArticle.Title+vbcrlf

				If objArticle.Level<3 Then
					strOut=strOut+"STATUS: draft"+vbcrlf
				Else
					strOut=strOut+"STATUS: publish"+vbcrlf
				End If

				If objArticle.Level=3 Then
					strOut=strOut+"ALLOW COMMENTS: 0"+vbcrlf
					strOut=strOut+"CONVERT BREAKS: 1"+vbcrlf
					strOut=strOut+"ALLOW PINGS: 0"+vbcrlf
				Else
					strOut=strOut+"ALLOW COMMENTS: 1"+vbcrlf
					strOut=strOut+"CONVERT BREAKS: 1"+vbcrlf
					strOut=strOut+"ALLOW PINGS: 1"+vbcrlf
				End If

				strOut=strOut+"PRIMARY CATEGORY: "+Categorys(objArticle.CateID).Name+vbcrlf

				j=objArticle.PostTime
				strOut=strOut+"DATE: "+CStr(Right("00" & Month(j),2))+"/"+CStr(Right("00" & Day(j),2))+"/"+CStr(Year(j))+" "+CStr(Right("00" & Hour(j),2))+":"+CStr(Right("00" & Minute(j),2))+":"+CStr(Right("00" & Second(j),2))+vbcrlf
				strOut=strOut+"-----"+vbcrlf

				If bolInr=True Then
					strOut=strOut+"BODY:"+vbcrlf
					'strOut=strOut+"EXCERPT:"+vbcrlf
					strOut=strOut+objArticle.Intro+vbcrlf
					strOut=strOut+"-----"+vbcrlf
				End If

				If bolCnt=True Then
					strOut=strOut+"EXTENDED BODY:"+vbcrlf
					'strOut=strOut+"BODY:"+vbcrlf
					strOut=strOut+objArticle.Content+vbcrlf
					strOut=strOut+"-----"+vbcrlf
				End If

				If bolTag=True Then
					If objArticle.Tag<>"" Then
						strOut=strOut+"KEYWORDS:"+vbcrlf
						s=objArticle.Tag
						s=Replace(s,"}","")
						t=Split(s,"{")

						For i=LBound(t) To UBound(t)
							If t(i)<>"" Then
								strOut=strOut & Tags(t(i)).Name+vbcrlf
							End If
						Next
						strOut=strOut+"-----"+vbcrlf
					End if
				End If

				If bolCmt=True Then
					If objArticle.CommNums>0 Then 

						Set objSubRS=objConn.Execute("SELECT * FROM [blog_Comment] WHERE [log_ID]="&objArticle.ID&" ORDER BY [comm_PostTime] ASC")

						If (Not objSubRS.bof) And (Not objSubRS.eof) Then
							Do While Not objSubRS.eof

								Set objComment=New TComment
								If objComment.LoadInfoByID(objSubRS("comm_ID")) Then
									strOut=strOut+"COMMENT:"+vbcrlf
									strOut=strOut+"AUTHOR: "+objComment.Author+vbcrlf
									strOut=strOut+"EMAIL: "+Replace(objComment.Email,"@","{at}")+vbcrlf
									strOut=strOut+"IP: "+objComment.IP+vbcrlf
									strOut=strOut+"URL: "+objComment.HomePage+vbcrlf
									j=objComment.PostTime
									strOut=strOut+"DATE: "+CStr(Right("00" & Month(j),2))+"/"+CStr(Right("00" & Day(j),2))+"/"+CStr(Year(j))+" "+CStr(Right("00" & Hour(j),2))+":"+CStr(Right("00" & Minute(j),2))+":"+CStr(Right("00" & Second(j),2))+vbcrlf
									strOut=strOut+objComment.Content+vbcrlf
									strOut=strOut+"-----"+vbcrlf
								End If
								Set objComment=Nothing

								objSubRS.MoveNext
							Loop
						End If

						objSubRS.close
						Set objSubRS=Nothing

					End If
				End If

				If bolTb=True Then
					If objArticle.TrackBackNums>0 Then 

						Set objSubRS=objConn.Execute("SELECT * FROM [blog_TrackBack] WHERE [log_ID]="&objArticle.ID&" ORDER BY [tb_PostTime] ASC")

						If (Not objSubRS.bof) And (Not objSubRS.eof) Then
							Do While Not objSubRS.eof

								Set objTrackBack=New TTrackBack
								If objTrackBack.LoadInfoByID(objSubRS("tb_ID")) Then
									strOut=strOut+"PING:"+vbcrlf
									strOut=strOut+"BLOG NAME: "+objTrackBack.Blog+vbcrlf
									strOut=strOut+"TITLE: "+objTrackBack.Title+vbcrlf
									strOut=strOut+"IP: "+objTrackBack.IP+vbcrlf
									strOut=strOut+"URL: "+objTrackBack.Url+vbcrlf
									j=objTrackBack.PostTime
									strOut=strOut+"DATE: "+CStr(Right("00" & Month(j),2))+"/"+CStr(Right("00" & Day(j),2))+"/"+CStr(Year(j))+" "+CStr(Right("00" & Hour(j),2))+":"+CStr(Right("00" & Minute(j),2))+":"+CStr(Right("00" & Second(j),2))+vbcrlf
									strOut=strOut+objTrackBack.HtmlExcerpt+vbcrlf
									strOut=strOut+"-----"+vbcrlf
								End If
								Set objTrackBack=Nothing

								objSubRS.MoveNext
							Loop
						End If

						objSubRS.close
						Set objSubRS=Nothing

					End If
				End If
				strOut=strOut+"--------"+vbcrlf

			End If
			Set objArticle=Nothing

			objRS.MoveNext
		Loop
	End If
	objRS.Close
	Set objRS=Nothing

	strOut=TransferHTML(UBBCode(strOut,"[face][link][autolink][font][code][image][typeset][media][flash][key]"),"[upload]")

	Response.Write strOut

End Function

Call System_Terminate()

If Err.Number<>0 then
	Call ShowError(0)
End If
%>
