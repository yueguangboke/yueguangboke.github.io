﻿<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8
'// 插件制作:    William Long
'// 备    注:    博客网站导航
'// 最后修改：   William Long
'// 最后版本:    1.8
'///////////////////////////////////////////////////////////////////////////////
%>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="c_option.asp" -->
<!-- #include file="function/c_function.asp" -->
<!-- #include file="function/c_function_md5.asp" -->
<!-- #include file="function/c_system_lib.asp" -->
<!-- #include file="function/c_system_base.asp" -->
<!-- #include file="function/c_system_event.asp" -->
<%

	Call System_Initialize()
	Call CheckReference("")
	Dim objRS
	Dim objRSCate

%><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<%=ZC_BLOG_LANGUAGE%>" lang="<%=ZC_BLOG_LANGUAGE%>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Language" content="<%=ZC_BLOG_LANGUAGE%>" />
	<link rel="stylesheet" rev="stylesheet" href="CSS/admin.css" type="text/css" media="screen" />
	<link rel="stylesheet" rev="stylesheet" href="css/print.css" type="text/css" media="print" />
	<script language="JavaScript" src="script/common.js" type="text/javascript"></script>
	<title>博客网站导航</title>
</head>
<body>

<h1>博客网站导航</h1>

<div class="post">
<%
	Set objRSCate = objConn.Execute("SELECT * FROM [blog_Category] order by cate_order")
	While Not objRSCate.eof
%>
<h2 class="post-title"><a href="http://www.williamlong.info/archives/<%= objRSCate("cate_Intro") %>.html"><%= objRSCate("cate_Name") %></a></h2> 
<div class="post-body"><p><blockquote>
<%
	Set objRS = objConn.Execute("SELECT * FROM [blog_Tag] WHERE tag_ParentID=" + CStr(objRSCate("cate_ID")) + " order by tag_Count DESC")
	While Not objRS.eof
		tag_Name = objRS("tag_Name")
%>
<a href="http://www.williamlong.info/?tags=<%= tag_Name%>" rel="tag"><%= objRS("tag_Intro")%></a>&nbsp;　
<%
		objRS.MoveNext
	Wend
%>
</blockquote></p></div>
<%
	objRSCate.MoveNext
	Wend
%>
</div>

</body>
</html>
<%
'Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>

