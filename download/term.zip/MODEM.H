/*      modem.h

        Definitions for modem functions.

        Copyright (c) 1996,1997
        All Rights Reserved.
*/

#define TRUE          1
#define FALSE         0
#define _COM_CHR8     0X03
#define _COM_STOP1    0X00
#define _COM_NOPARITY 0X00
#define _COM_2400     0Xa0
#define COM_PARAMS (_COM_CHR8|_COM_STOP1|_COM_NOPARITY|_COM_2400)
#define RXQSIZE       200
#define TXQSIZE       200
#define P8259_0       0x20  /*int comtrol resister */
#define P8259_1       0x21  /*int mask resister */
#define END_OF_INT    0X20 /* NON_specific EOI */

#define MCROFF        0  /* MODEM CONTROL REGISTER*/
#define IEROFF        0
#define THREOFF       0Xfd

/* address of bios data area at 400h */
#define BIOS_DATA ((int far *) (0x400000L))

/* interrupt identification number */
#define TXREGEMPTY    2
#define RXDATAREADY   4

/* The address of the comm port is in the short inter 'comport'.*/
#define IER (comport +1)
#define IIR (comport +2)
#define LCR (comport +3)
#define MCR (comport +4)
#define LSR (comport +5)
#define MSR (comport +6)

/* codes to enable individual interrupts */
#define RDAINT        1
#define THREINT       2
#define RLSINT        4
#define MSINT         8
#define bit0(i)       (i&0x0001)
#define turnon_int(i,j) if(((j=inp(IER))&i)==0) outp(IER,(j|i))
typedef struct QTYPE {
     int count;
     int front;
     int rear;
     int maxsize;
     char *data;
     }  QTYPE;

static char rxbuf[RXQSIZE], txbuf[TXQSIZE];
static QTYPE rcvq={0,-1,-1,RXQSIZE,rxbuf},
         trmq={0,-1,-1,TXQSIZE,txbuf};

static QTYPE *txq=&trmq, *rxq=&rcvq;  /*������ */

static short int_number=12,
       comport=0,
       int_enable_mask=0xef,
       int_disable_mask=0x10;

int s_sendchar(int);                  /* ����һ���ַ� */
int s_rcvchar(void);                  /* ����һ���ַ� */
int s_setup(short,unsigned);          /* ��װ�ж����� */
int s_cleanup(void);                  /* ����ж����� */
char *q_getfrom(QTYPE *,char *);
int q_puton(QTYPE *,char *);
void interrupt far s_inthndlr(void);   /* �жϴ������� */
static void(interrupt far *old_handler) ();
static void s_rda(void);               /*����register��ʱ����*/
static void s_trmty(void);             /*����register��ʱ����*/
#ifndef _MODEM_H
#define _MODEM_H


#define DATA_OFF          0    /* offset of data register */
#define LOW_BAUD          0    /* Offset of baud rate divisor - low byte */
#define HI_BAUD           1    /* Offset of baud rate divisor - high byte */
#define INT_ENABLE_OFF    1    /* Offset of Interrupt enable register */
#define INT_ID_OFF        2    /* Offset of Interrupt Identification */
#define LINE_CTRL_OFF     3    /* Line Control Register */
#define STATUS_OFF        5    /* offset of line status register */
#define MODEM_CTRL_OFF    4    /* offset of modem contrl register */
#define MODEM_STAT_OFF    6    /* offset of modem status register */

#define RCV_MASK      0x01
#define XMIT_MASK     0x20


/* Ticks per second */
#define TICKSPERSEC    18.2

/* Numeric Result Codes from modem */
#define M_OK           0
#define M_CONN3        1
#define M_RING         2
#define M_NOCARRIER    3
#define M_ERROR        4
#define M_CONN12       5
#define M_NOTONE       6
#define M_BUSY         7
#define M_NOANSWER     8
#define M_RESERVED     9
#define M_CONN24       10

/* User-defined constants */
#define M_NORING       11
#define M_BADMSG       12
#define M_ONLINE       13
#define M_USRCAN       14
#define TIMEOUT        -1
#define OPENFAIL       -1
#define CREATFAIL      -2
#define DISCONN        0
#define SUCCEED        1
#define ON             1
#define OFF            0

#define SOH        (char)0x01        /* Start Of Heading */
#define EOT        (char)0x04        /* End Of Transmission */
#define ACK        (char)0x06        /* Acknowledge */
#define NAK        (char)0x15        /* Negative Acknowledge */
#define SUB        (char)0x1a
#define CRC        'C'

#define MAXREPLY    64


/* Masks used to set S-registers */
#define MASK_S0        0x00000001L
#define MASK_S1        (MASK_S0 << 1)
#define MASK_S2        (MASK_S0 << 2)
#define MASK_S3        (MASK_S0 << 3)
#define MASK_S4        (MASK_S0 << 4)
#define MASK_S5        (MASK_S0 << 5)
#define MASK_S6        (MASK_S0 << 6)
#define MASK_S7        (MASK_S0 << 7)
#define MASK_S8        (MASK_S0 << 8)
#define MASK_S9        (MASK_S0 << 9)
#define MASK_S10       (MASK_S0 << 10)
#define MASK_S11       (MASK_S0 << 11)
#define MASK_S12       (MASK_S0 << 12)
#define MASK_S13       (MASK_S0 << 13)
#define MASK_S14       (MASK_S0 << 14)
#define MASK_S15       (MASK_S0 << 15)
#define MASK_S16       (MASK_S0 << 16)
#define MASK_S17       (MASK_S0 << 17)
#define MASK_S18       (MASK_S0 << 18)
#define MASK_S19       (MASK_S0 << 19)
#define MASK_S20       (MASK_S0 << 20)
#define MASK_S21       (MASK_S0 << 21)
#define MASK_S22       (MASK_S0 << 22)
#define MASK_S23       (MASK_S0 << 23)
#define MASK_S24       (MASK_S0 << 24)
#define MASK_S25       (MASK_S0 << 25)
#define MASK_S26       (MASK_S0 << 26)
#define MASK_S27       (MASK_S0 << 27)

#define M_STAT(port)    readbyte(port + MODEM_STAT_OFF)

#define DATALEN          128
typedef unsigned char    BYTE;
typedef struct _packetRec {
    BYTE    soh;                /* Start Of Heading */
    BYTE    seq;                /* Sequence# */
    BYTE    nseq;               /* Negative-sequence# = ~seq */
/*    BYTE    buflen;   */         /* data length */
    BYTE    buffer[DATALEN];    /* buffer */
    BYTE    bc[2];              /* block checksum(CRC-16) */
} PacketRec;

#define PACKETSIZE   sizeof(PacketRec)
#define MAXRETRY     5
#define CRC16        0x8005
#define CRC_CCITT    0x1021

/* modem function prototypes */
extern int     dial();
extern int     hangup();
extern int     escseq();
extern int     m_wait4reply();
extern void    m_cmd(char *);
extern char    *m_getstr(void);

extern int    sendfile();
extern int    rcvfile();

extern void   delaytime();

#endif        /* _MODEM_H */
