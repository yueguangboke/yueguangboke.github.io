/*      modem2.c

        Definitions for modem functions.

        Copyright (c) 1996,1997
        All Rights Reserved.
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <time.h>
#include <dos.h>
#include <fcntl.h>
#include <io.h>
#include <bios.h>
#include <sys\types.h>
#include <sys\stat.h>

#include "modem.h"

/*�жϴ�������*/
void interrupt far s_inthndlr(void)
{
    int c;
    register int int_id, intmask;
    enable();
    while(TRUE) {
        int_id=inp(IIR);

        if(int_id>=RXDATAREADY) turnon_int(THREINT,intmask);

        switch (int_id&0xfe) {
            case TXREGEMPTY:
                   s_trmty();
                   break;
            case RXDATAREADY:
                   s_rda();
                   break;
            default:break;
        };
        if (bit0(int_id)==1) {
            outp(P8259_0,END_OF_INT);
            return;
        };
    }
}

/*����׼���ô���*/
static  void s_rda(void)
{
    register int intmask;
    static char c;

    c=inportb(comport);
    q_puton(rxq,&c);
}

/* ����register�մ��� */
static void s_trmty(void)
{
    static char c;
    register int ierval;
    if (q_getfrom(txq,&c)!=NULL) {
        outportb(comport,c);
    }
    else {
        ierval=inp(IER);
        if(ierval&THREINT) outp(IER,ierval&THREOFF);
    }
    return;
}

/* �Ӷ�����ȡ������  */
char *q_getfrom(QTYPE *quere,char *data)        /* get data out of quere */
{
    char *current;

    current=NULL;
    if(quere->front==-1)
    return(current);
    current=&(quere->data[quere->front]);
    *data=*current;
    quere->count--;
    if(quere->count==0) {
        quere->front=quere->rear=-1;
        return(current);
    }
    if(quere->front==quere->maxsize-1) quere->front=0;
    else quere->front++;
    return(current);
}

/* ������ѹ������� */
int q_puton(QTYPE *quere, char *data)     /* put data into quere */
{
    if(quere->count==quere->maxsize)
        return(0);
    if(quere->rear==quere->maxsize-1) {
       quere->rear=0;
       quere->data[quere->rear]=*data;
       quere->count++;
       return(1);
    }
    else  {
       quere->rear++;
       quere->data[quere->rear]=*data;
       quere->count++;
       if(quere->front==-1) quere->front=0;
       return(1);
    }
}

/* ����˿ڱ�־ */
int s_cleanup(void)
{
    int intmask;
    disable();
    outp(IER,IEROFF);
    outp(MCR,MCROFF);
    intmask=inp(P8259_1)|int_disable_mask;
    outp(P8259_1,intmask);
    setvect(int_number,old_handler);
    enable();
}


 /* ����һ���ַ�*/
int s_sendchar(int ch)
{
    int retval, intmask;
    disable();
    retval=q_puton(txq,(char*)&ch);
    enable();
    turnon_int(THREINT,intmask);
    return(retval);
}


/* ����һ���ַ� */
int s_rcvchar(void)
{
    static   int ch, intmask;

    disable();
    if(q_getfrom(rxq,(char *)&ch)==NULL) {
        enable();
        return(-1);
    }
    else {
        enable();
        return(ch);
    }
}


/* �ж�������װ */
int s_setup(short port_number,unsigned commparams)
{
    int intmask;
    if(port_number<0||port_number>3)
        {   printf("invalid com port number\n");
            if(port_number==2) comport=0x3e8;
            if(port_number==3) comport=0x2e8;
        }
    else
        {   comport=*(BIOS_DATA+port_number); }
    if(comport==0) {
       printf("BIOS could not find port !\n");
       return(0);
    }
    /* Set up masks for 8259a pic. To enable interrupt from the port
      this mask is ANDed with the mask resister at 21h */
    if (port_number==0)  {
       int_enable_mask=0xef;
       int_disable_mask=0x10;
       int_number=12;
       }
    if(port_number==1) {
       int_enable_mask=0xf7;
       int_disable_mask=8;
       int_number=11;
    }
    if(port_number==3||port_number==2) {
       int_enable_mask=0xcf;
       int_disable_mask=0x20;
       int_number=13;
    }
    /* Get old interrupt vector and save it.*/
    old_handler=getvect(int_number);
    /* Install the new handle named s_inthndlr disable interrupts */
    disable();

    setvect(int_number,s_inthndlr);
    enable();
    /* set up communication parameters */
    bioscom(0,commparams,port_number);
    /* turn on interrupts from comm port +setup 8259 a */
    disable();
    outp(MCR,0X0b);
    outp(IER,0x03);  /* enable txempty and rxrda interrupt */
    /*printf("inter1=%d\n",inp(IER));*/
    /* Read 8259's interrupt mask register and write it back after AND_ing
                           with int_enable_mask.*/
    intmask=inp(P8259_1)&int_enable_mask;
    outp(P8259_1,intmask);
    enable();
    intmask=inp(IER);
    if(intmask&THREINT) outp(IER,intmask&THREOFF);

    return(1);
}



/* utility prototypes */
int     TICKS;
char    echobuf[MAXREPLY + 1];
int     echotail;
void    delaytime();
void    startTimer();
void    stopTimer();

/* Modem function prototypes */
int     sendbyte();
int     rcvbyte();
int     m_isreply();


/* Level 2 Function prototypes */
void    s_putc(unsigned char);
void    s_puts(char  *);
int     s_waitch(int);
int     s_clrport(int);
int     s_gets(char  *,int,int);
int     s_waitch();
int     s_clrport(int);
char    * m_getstr(void);
int     m_wait4reply(void);


/* Level 1 function prototypes */
void            setdtr();


/* Level 0 function prototypes */


/***********************************************************************
**      Revised XMODEM/YMODEM protocol
**
** A data packet is defined as:
**      typedef struct {
**              BYTE    soh;            - Start of heading
**              BYTE    seq#;           - sequence number
**              BYTE    not_seq#;       - ~seq#
**              BYTE    length;         - data length
**              BYTE    data[128];      - data buffer
**              BYTE    bc;             - block checksum
**      } dataPacketRec;
**
************************************************************************/
/*
** Function:    sendfile() - send a file (ASCII or Binary) to the remote modem.
** Entry:
**      port    - port address
**      filename        - filename to be sent
*/

unsigned short  Checksum();

int sendfile(port, filename)
int     port;
char    *filename;
{
    int                 ack_reply;
    int                 fd;
    int                 retry;
    PacketRec           packet;
    BYTE                *ptr;
    int                 n;
    int                 i;
    int                 buflen;
    unsigned short      bc;
    long                sendcount = 0;

    if ((fd = open(filename, O_RDONLY | O_BINARY)) < 0)
    return(OPENFAIL);               /* Open file failed */

    packet.soh = SOH;
    packet.seq = 0;             /* initialize seqence# */

    printf(" Wait for initial NAK from receiver !\n");
    do {
        ack_reply = s_waitch(10);
    } while ((ack_reply != CRC)&&(!kbhit()));

    if (ack_reply != CRC)   return(DISCONN);
    printf(" Having rcved NAK !\n");
    while ((buflen = read(fd, packet.buffer, DATALEN)) >0 ) {
        if (buflen < DATALEN)
           for (i=buflen;i<DATALEN;i++)
               packet.buffer[i]=SUB;
        sendcount += DATALEN;
        if (packet.seq == 255)          /* next sequence # */
            packet.seq = 0;
        else
            packet.seq++;
        packet.nseq = ~packet.seq;
        packet.bc[0] = 0x00;
        packet.bc[1] = 0x00;
        bc = Checksum((BYTE *)&packet.buffer, DATALEN );
        packet.bc[0] = (bc >> 8) & 0x00FF;
        packet.bc[1] = bc & 0x00FF;

        printf("seq = %d , byte count =%u   \r", packet.seq, sendcount);

        retry = MAXRETRY;
        do {
            ptr = (BYTE *)&packet;

            /* Sending packet */
            for (n = 0; n < PACKETSIZE; n++, ptr++) {
                if (sendbyte(port, *ptr) == 0) {
                    printf("      /* disconnect */");
                    _close(fd);
                    return(DISCONN);
                }
            /*    printf("%c",*ptr);  */
            }

            /* wait for ACK from receiver */
            switch (ack_reply = s_waitch((int)(TICKSPERSEC * 3 + 0.5))) {
                case CRC:
                case NAK:       /* packet was received incorrectly */
                case TIMEOUT:   /* packet/ACK might get lost */
                    if (--retry == 0)           /* DIS-CONNECT */
                    return(DISCONN);
                    break;

                case ACK:
                    retry = 0;
                    break;
            }
        } while (retry > 0);
    }
    _close(fd);

    /* Sending EOT */
    retry = MAXRETRY;
    do {
        if (sendbyte(port, EOT) == 0) {
            _close(fd);
            return(DISCONN);
        }

        /* wait for ACK from receiver */
        switch (ack_reply = s_waitch((int)(TICKSPERSEC * 3 + 0.5))) {
            case NAK:           /* packet was received incorrectly */
            case TIMEOUT:       /* packet/ACK might get lost */
            if (--retry == 0)               /* DIS-CONNECT */
                return(DISCONN);
            break;

            case ACK:
            retry = 0;
            break;
        }
    } while (retry > 0);

    return(SUCCEED);            /* Send successfully */
}


/*
** Function:    sendbyte() - send a byte to the remote modem.
** Entry:
**      port    - port address
**      byte    - data to be sent
*/

int sendbyte(port, byte)
int     port;
unsigned char   byte;
{
    int item;
    while (1) {
    if ((inp(port+MODEM_STAT_OFF) & 0x88) == 0x08)      /* DCD changed from 1 to 0 */
    {
        echotail = 0;
        while ((item=s_rcvchar())!=-1)             /* get result code */
        echobuf[echotail++] = item;
        return(0);
    }

    s_sendchar(byte);         /* ready to transmit character ? */
    return(1);

    }
}


int rcvfile(port, filename)
int     port;
char    *filename;
{
    int                 fd;
    BYTE                seqExpected;
    BYTE                lastSeq;
    PacketRec           packet;
    BYTE                *ptr;
    int                 n;
    int                 retcode;
    unsigned short      bc;
    int                 i;
    int                 buflen;
    long                rcvcount = 0;

    if ((fd = creat(filename, S_IREAD | S_IWRITE)) < 0)
        return(CREATFAIL);
    _close(fd);
    if ((fd = open(filename, O_BINARY | O_WRONLY)) < 0)
        return(OPENFAIL);

    s_clrport(DATALEN);
    lastSeq = 0;
    seqExpected = 1;

    if (sendbyte(port, CRC) == 0) {     /* sending intial NAK */
        _close(fd);
        return(DISCONN);
    }
    printf(" sending intial NAK \n");

    while (1) {
        switch (i = s_waitch((int)(TICKSPERSEC * 3))) {
            case TIMEOUT:       /* send NAK again */
            if (sendbyte(port, NAK) == 0) {
                _close(fd);
                return(DISCONN);
            }
            break;

            case SOH:           /* Start Of Heading */
            ptr = (BYTE *)&packet;
            ptr++;

            n = PACKETSIZE - 1;
            while (n) {
                if ((retcode = rcvbyte(port, ptr)) == 1) {
            /*    printf("%c",*ptr);   */
                ptr++;
                n--;
                }
                else if (retcode == 0) {
                _close(fd);
                return(DISCONN);
                }
            }

            buflen = DATALEN;
            for (i = DATALEN -1;i > 0;i--)
                if (packet.buffer[i]==SUB) {
                    buflen--;
                }
                else break;
            rcvcount +=buflen;
            printf("seq = %d, receive count = %d   \r", packet.seq, rcvcount);

            if ((packet.seq ^ packet.nseq) != 0x00FF)
                sendbyte(port, NAK);        /* sequence# error */
            else if (packet.seq != seqExpected) {
                if (packet.seq == lastSeq)          /* duplicate packet */
                    sendbyte(port, ACK);
                else {                              /* fatal error */
                    _close(fd);
                    return(DISCONN);
                }
            }
            else {          /* sequence# is correct */
                bc = Checksum((BYTE *)&packet.buffer, DATALEN );
                if ((bc ^ ((packet.bc[0] << 8) + packet.bc[1]))==0) {
                write(fd, packet.buffer, buflen);
                sendbyte(port, ACK);
                lastSeq = seqExpected;
                if (seqExpected == 255)
                    seqExpected = 0;
                else
                    seqExpected++;
                }
                else
                sendbyte(port, NAK);    /* checksum error */
            }
            break;

            case EOT:           /* End Of Transmission */
            if (sendbyte(port, ACK) == 0) {
                _close(fd);
                return(DISCONN);
            }
            else {
                _close(fd);
                return(SUCCEED);
            }

            default:            /* Fatal error ? */
            break;
        }
    }
}


int rcvbyte(port, byte)
int     port;
unsigned char   *byte;
{
    int item;
    if ((inp(port+6) & 0x88) == 0x08) {
    return(0);
    }
    else if ((item=s_rcvchar())!=-1) {
    *byte = item;
    return(1);
    }
    else
    return(-1);
}


/*
** Function:    Checksum() - compute crc's
**
** crc-16 is based on the polynomial x^16+x^15+x^2+1
**  The data is assumed to be fed in from least to most significant bit
** crc-ccitt is based on the polynomial x^16+x^12+x^5+1
**  The data is fed in from most to least significant bit
** The prescription for determining the mask to use for a given polynomial
**    is as follows:
**        1.  Represent the polynomial by a 17-bit number
**        2.  Assume that the most and least significant bits are 1
**        3.  Place the right 16 bits into an integer
**        4.  Bit reverse if serial LSB's are sent first
*/

/* function declarations */
unsigned int updcrc(unsigned int,int,unsigned int);

unsigned short Checksum(buf, buflen)
BYTE    *buf;
int     buflen;
{
    /* variables */
    unsigned int crctt;
    int ch;
    int num;

    crctt=0;
    for ( num=0;num<buflen;num++)
    {
        ch=*(buf+num);
        crctt=updcrc(crctt,ch,CRC_CCITT);
    }
    return (crctt);
}

/* update crc */
unsigned int updcrc(crc,c,mask)
unsigned int crc,mask; int c;
{
    int i;
    c<<=8;
    for(i=0;i<8;i++)
    {
        if((crc ^ c) & 0x8000) crc=(crc<<1)^mask;
        else crc<<=1;
        c<<=1;
    }
    return crc;
}


/* constants used when issuing AT commands */
#define CMDBUFSIZ       40
#define ATPREFIX        "AT"
#define SUFFIX          "\015"


/*
** Function:    dial() - dial a phone
** Entry:
**      port    - port address
**      phone   - phone number
*/

#define DIALMODIFIER    "E0V1X4&C1&D2"

int dial(port, phone)
int     port;
char    *phone;
{
    char        dialstr[CMDBUFSIZ];

    strcpy(dialstr, DIALMODIFIER);
    strcat(dialstr, "D");
    strcat(dialstr, phone);
    setdtr(port, ON);           /* turn on DTR - Data Terminal Ready */
    m_cmd(dialstr);
    /* wait for modem response & return it */
    return(m_wait4reply());
}


/*
** Function:    escseq() - change from on-line mode to command mode
** Entry:
**      port    - port address
**      escchar - escape chararacter
*/

int escseq(char  escchar)
{
    int i;

    for (i = 0; i < 3; i++)
        s_putc(escchar);

    delaytime(18);          /*18 delaytime one second */
}


/*
** Function:    hangup() - hang up
** Entry:
**      port    - port address
*/

int hangup(port)
int     port;
{
    char        escchar = '+';

    delaytime(6);                   /*6 short delaytime - 300 msecs */
    escseq(escchar);      /* on-line mode to command mode */
    m_cmd("H0");          /* issue hang up command */
	 sleep(0.5);
    setdtr(port, OFF);

}



/*
** Function:    m_cmd() - send an AT command to Smartmodem
** Entry:
**      port    - port address
**      cmdstr  - AT command string
*/

void m_cmd(char  *cmdstr)
{
    char        cmdbuf[CMDBUFSIZ];

    /* combine AT commands(prefix, cmdstr, suffix) in cmdbuf */
    strcpy(cmdbuf, ATPREFIX);
    strcat(cmdbuf, cmdstr);
    strcat(cmdbuf, SUFFIX);
    s_puts(cmdbuf);       /* send command string to port */
}

/*
** Function:    m_getstr() - get from modem response, if the response is
**                      not received within tsec, return TIMEOUT
** Entry:
**      port    - port address
*/


char * m_getstr(void)
{
    int item;
    char *msg_buf;
    enum {LEADING_CR,LEADING_LF,IN_MSG,EXIT};
    int state = LEADING_CR;
    s_clrport(MAXREPLY);
    strncpy(echobuf, "", MAXREPLY + 1);
    echotail = 0;

    TICKS = TICKSPERSEC * 40;
    startTimer();
    while ((TICKS > 0) && (echotail < MAXREPLY)) {
        if ((item=s_rcvchar())!=-1) {
            echobuf[echotail++] = item;
            if ((m_isreply(echobuf)) >= 0)
            break;
        }
        if (kbhit()) {
            getch();
            break;
        }
    }
    stopTimer();

    msg_buf=echobuf;
    while (state!=EXIT&&(*msg_buf))  {
        switch (state)  {
            case LEADING_CR:
                if (*msg_buf=='\r')
                    state=LEADING_LF;
                break;
            case LEADING_LF:
                if (*msg_buf=='\n')
                    state=IN_MSG;
                break;
            case IN_MSG:
                state=EXIT;
                msg_buf--;
                break;
        }
        msg_buf++;
    }
    return(msg_buf);
}


/*
** Function:    m_wait4reply() - wait for modem response, if the response is
**                      not received within tsec, return TIMEOUT
** Entry:
**      port    - port address
*/


int m_wait4reply(void)
{
    int         retcode = TIMEOUT;
    int item;
    s_clrport(MAXREPLY);
    strncpy(echobuf, "", MAXREPLY + 1);
    echotail = 0;

    TICKS = TICKSPERSEC * 40;
    startTimer();
    while ((TICKS > 0) && (echotail < MAXREPLY)) {
        if ((item=s_rcvchar())!=-1) {
            echobuf[echotail++] = item;
            if ((retcode = m_isreply(echobuf)) >= 0)
            break;
        }
        if (kbhit()) {
            getch();
            break;
        }
    }

    stopTimer();
    return((retcode >= 0) ? retcode : m_isreply(echobuf));
}


/*
** Function:    m_isreply() - translate verbal result code to numberic code,
**                      or -1 if the input string is an invalid result code
** Entry:
**      str     - verbal result code
*/

char    *m_result[] = {
    "\r\nOK\r\n",
    "\r\nCONNECT\r\n",
    "\r\nRING\r\n",
    "\r\nNO CARRIER\r\n",
    "\r\nERROR\r\n",
    "\r\nCONNECT 1200\r\n",
    "\r\nNO DIALTONE\r\n",
    "\r\nBUSY\r\n",
    "\r\nNO ANSWER\r\n",
    "Reserved for future use",
    "\r\nCONNECT 2400\r\n",
    };

int numrows = sizeof(m_result) / sizeof(m_result[0]);

int m_isreply(str)
char    *str;
{
    int row;

    for (row = numrows - 1; row >= 0; row--)
        if (strstr(str, m_result[row]))
            return(row);

    return(-1);
}


/****************************************************************************
** Level 2 functions:
**      s_getc()        - wait until a byte arrives at the port, then read it
**      s_gets()        - get a string within a specified period of time
**      s_putc()        - when the port is ready to send a byte, send it
**      s_puts()        - output a string to a port
**      s_inchar()      - read a byte from the port if a byte arrives, or -1 if
**                        not. No waiting
**      s_waitch()      - read a byte from the port in a specified period of
**                        time
**      s_clrport()     - clear nbytes from port
*****************************************************************************/



void s_putc(unsigned char  c)
{
    s_sendchar(c);
}


void s_puts(char  *cmdbuf)
{
    int cmdlen = strlen(cmdbuf);
    int i;

    for (i = 0; i < cmdlen; i++)
        s_putc(cmdbuf[i]);
}


int s_waitch(int  tsec)
{
    int item;
    TICKS = tsec;
    startTimer();
    while (TICKS > 0) {
        if ((item=s_rcvchar())!=-1)  {
            stopTimer();
            return(item);
        }
    }
    stopTimer();
    return(s_rcvchar());
}


int s_clrport(int  nbytes)
{
    for (; nbytes > 0; nbytes--) {
    if(s_rcvchar()==-1)
        return(TIMEOUT);
    }

    return(0);
}


int  s_getc(void)
{
    return (s_rcvchar());
}


int s_gets(char  *buf,int  bufsiz,int  tsec)
{
    int count = 0;
    int item;

    TICKS = tsec;
    startTimer();
    while ((TICKS > 0) && (count < bufsiz)) {
        if ((item=s_rcvchar())!=-1)
            buf[count++] = item;
    }

    stopTimer();
    buf[count] = '\0';

    return((count > 0) ? count : TIMEOUT);
}


/*****************************************************************
** Level 1 functions:
**      setdtr()        - turn on/off DTR(Data Terminal Ready)
**      s_xmit()        - send a byte to a port
**      s_xmitstat()    - test the status of
**      s_rcv()         - receive a byte from a port
**      s_rcvstat()     - return the status of
*****************************************************************/

void setdtr(port, dtr)
int             port;
unsigned char   dtr;
{
    outp(port + MODEM_CTRL_OFF, dtr);
}



/********************************************************
** Level 0 functions:
**      readbyte()      - read a byte from a port
**      writebyte()     - output a byte to a port
*********************************************************/



/* utilities */
void delaytime(int tsec)
{
    TICKS=tsec;
    startTimer();
    while (TICKS>0);
    stopTimer();
}


/* Interrupt routines */

void (interrupt far *oldint1c)();

void interrupt far newint1c()
{
    enable();            /* Enable interrupt */
    (*oldint1c)();      /* exec the old ISR */

    TICKS--;
}

void startTimer(void)
{
    oldint1c = getvect(0x1C);
    setvect(0x1C, newint1c);
}

void stopTimer(void)
{
    setvect(0x1C, oldint1c);
}
