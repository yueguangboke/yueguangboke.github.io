
/***************************************************************************
 *                                                                         *
 *     File:           TERMINAL EMULATION UTILITY                          *
 *     Function:    Serial communications demo program                     *
 *             Compiled and linked with Borland/Turbo C v2.0               *
 *     Author:               Long Yun Liang                                *
 *     Copyright (c) 12,30,1996       All rights reserved                  *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <process.h>
#include <stdlib.h>
#include <signal.h>
#include <conio.h>
#include <fcntl.h>
#include <ctype.h>
#include "modem.h"


/*
**
** scan codes
**
*/

#define FORMAT         'E'
#define DIAL           'D'
#define ANSWER         'A'
#define XSEND          'S'
#define XRECV          'R'
#define EXIT           'Q'
#define kbCR           13
#define kbUp           72
#define kbRight        77
#define kbLeft         75
#define kbDown         80
#define kbPageUp       73
#define kbPageDn       81
#define kbESC          27

#define ATCMDPREFIX   "Q0V1E1S0=0"
#define dim(x)  (sizeof(x)/sizeof(x[0]))

/*
**
** text attributes
**
*/

#define  NORM  0x07
#define  BOLD  0x08
#define  FAINT 0xF7
#ifndef  BLINK
#define  BLINK 0x80
#endif
#define  REVRS 0x77


/*
**
** parameter messages
**
*/

char	*responses[] = {
	"OK",
	"CONNECT",
	"RING",
	"NO CARRIER",
	"ERROR",
	"CONNECT 1200",
	"NO DIALTONE",
	"BUSY",
	"NO ANSWER",
	NULL,
	"CONNECT 2400",
};



/* global data defined */

int	nres = sizeof(responses) / sizeof(responses[0]);
extern char	echobuf[];
static char com_spec[64];
int  port_number;
int  cmEcho = 0;
int  cmDebug = 0;

int  x = 1;                 /* cursor location       */
int  y = 1;
int  attrib = NORM;


/*
**
** function prototypes
**
*/

int  break_handler();
int  dos_cmd(),exit_cmd(),at_cmd(),help_cmd();
int  term(),send(),receive(),menu();
void parse_cmp_line (int,char *[]);
int  ansi_map(unsigned);
void ansi();
void message ();
void help ();

struct cmd_table  {
     char  *cmd_name;
     int   (*cmd_fxn)();
}

commands[] = {
     "?",help_cmd,
     "DOS",dos_cmd,
     "EXIT",exit_cmd,
};



/*--------------------------------------------------------------------------*/
/*                                                                          */
/* ansi_map() -- map function key into an ANSI escape sequence if we have   */
/* one to correspond to the key. The "emulation" is VT100-type, we map the  */
/* arrow keys to the ANSI escape sequences for up, down, right and left,    */
/* and we map the function keys into the VT100 keypad, assuming application */
/* mode, like Procomm. That is, we take the VT100 keypad, split it in two   */
/* vertically, and use the F-keys to represent the left side, and the       */
/* "shifted" F-keys to represent the right side.                            */
/*                                                                          */
/*              The result, if any, is transmitted to the host.             */
/*                                                                          */
/*--------------------------------------------------------------------------*/

char           *ansi_seq[] = {  /* IBM key	Scan code	VT100 key	 */
   "\033OP",   /* F1            3b00      PF1          */
   "\033OQ",   /* F2            3c00      PF2          */
   "\033Ow",   /* F3            3d00      keypad '7'   */
   "\033Ox",   /* F4            3e00      keypad '8'   */
   "\033Ot",   /* F5            3f00      keypad '4'   */
   "\033Ou",   /* F6            4000      keypad '5'   */
   "\033Oq",   /* F7            4100      keypad '1'   */
   "\033Or",   /* F8            4200      keypad '2'   */
   "\033Op",   /* F9            4300      keypad '0'   */
   "\033Op",   /* F10           4400      keypad '0'   */
   "",         /*               4500                   */
   "",         /*               4600                   */
   "",         /*               4700                   */
   "\033[A",   /* Up Arrow      4800      Up Arrow     */
   "",         /*               4900                   */
   "",         /*               4a00                   */
   "\033[D",   /* Left Arrow    4b00      Left Arrow   */
   "",         /*               4c00                   */
   "\033[C",   /* Right Arrow   4d00      Right Arrow  */
   "",         /*               4e00                   */
   "",         /*               4f00                   */
   "\033[B",   /* Down Arrow    5000      Down Arrow   */
   "",         /*               5100                   */
   "",         /*               5200                   */
   "",         /*               5300                   */
   "\033OR",   /* Shift-F1      5400      PF3          */
   "\033OS",   /* Shift-F2      5500      PF4          */
   "\033Oy",   /* Shift-F3      5600      keypad '9'   */
   "\033Om",   /* Shift-F4      5700      keypad '-'   */
   "\033Ov",   /* Shift-F5      5800      keypad '6'   */
   "\033Ol",   /* Shift-F6      5900      keypad ','   */
   "\033Os",   /* Shift-F7      5a00      keypad '3'   */
   "\033OM",   /* Shift-F8      5b00      keypad 'Enter' */
   "\033On",   /* Shift-F9      5c00      keypad '.'   */
   "\033OM",   /* Shift-F10     5d00      keypad 'Enter' */
   ""
};


main (int argc,char *argv[])
{
    char inp_buf[80];
    int  port;

    if (argc==1) port_number = 3 - 1;
    else parse_cmp_line (argc,argv);

    if (!s_setup(port_number,COM_PARAMS)) help();

    get_comspec (com_spec);

    m_cmd (ATCMDPREFIX);
    while (1)  {
        get_cmd(inp_buf);
        if (!intrinstic (inp_buf))
            extrinsic (inp_buf);
    }
}

void parse_cmp_line (int argc,char *argv[])
{
     int i;
     int ch;

     for (i=1;i<argc;i++)
         if ((argv[i][0]=='-')||(argv[i][0]=='/'))
            switch (ch=toupper (argv[i][1]))
                   {
                   case '1':
                   case '2':
                   case '3':
                   case '4':
                     	port_number = ch - '0' - 1;
                        break;
                   case 'E':
                        cmEcho = 1;
                        break;
                   case 'D':
                        cmDebug = 1;
                        break;
                   default:
                        message();
                        help();
                        break;
                   }
         else
	     help();
}

void message (void)
{
     printf ("TERM (tm) Simulate Terminal Utilities Version 1.00   12-31-96\n");
     printf ("Copyright 1996 by Software Engineering , All Rights Reserved.\n");
}

void help (void)
{
     printf ("\n");
     printf ("Usage: TERM  [PortNumber] <Command> \n");
     printf ("PortNumber are:\n");
     printf ("    /1-4 = Sets the communications port number .\n");
     printf ("Command are:\n");
     printf ("    /D   = Debuging mode .\n");
     printf ("    /E   = Enable echo in terminal .\n");
     printf ("    /?   = Display help information .\n");
     exit (1);
}

intrinstic (char *input_string)
{
    int i,j;

    while (*input_string=='\x20') input_string++;
    if (!strcmp(input_string,"")) return (1);

    if (!strncmp(input_string,"ATD",3))  {
       dial_cmd(input_string+3);
       return(1);
    }
    if (!strncmp(input_string,"ATA",3))  {
       setdtr(comport, ON);
       m_cmd("E0V1X4&C1&D2S0=1");
       term();
       return(1);
    }
    if (!strncmp(input_string,"AT",2)) {
       at_cmd(input_string+2);
       return(1);
    }

    for (i=0;i<dim(commands);i++)  {
        j=strcmp(commands[i].cmd_name,input_string);
        if (j==0)  {
            (*commands[i].cmd_fxn)();
            return(1);
        }
    }
    return(0);
}

extrinsic (char *input_string)
{
    int status;
    status=system(input_string);
    if (status)
        fputs ("\nEXEC of COMMAND.COM failed\n",stderr);
}

get_cmd (char *buffer)
{
    printf ("$ ");
    gets(buffer);
    strupr(buffer);
}

get_comspec (char *buffer)
{
    strcpy (buffer,getenv("COMSPEC"));
    if (buffer[0]==NULL)  {
        fputs ("\nNo COMSPEC variable in Enviroment\n",stderr);
        exit (1);
    }
}

help_cmd()
{
    message();
    printf ("\n");
    printf (" Ctrl-d Log off\n");

}

dos_cmd()
{
    int status;
    status = spawnlp (P_WAIT,com_spec,com_spec,NULL);
    if (status) fputs ("\nEXEC of COMMAND.COM failed\n",stderr);
}

exit_cmd()
{
    hangup(comport);
    s_cleanup();
    exit(0);
}

at_cmd(char *command)
{
    char *retcode;
    setdtr(comport, ON);           /* turn on DTR - Data Terminal Ready */
    m_cmd(command);
    retcode=m_getstr();
    printf("%s\n", retcode);
}

dial_cmd(char *phone)
{
    int	retcode;
    if (!strcmp(phone,""))  {
       printf ("Invalid dial number .\n");
       return 1;
    }
    retcode = dial(comport, phone);
    if ((retcode >= 0) && (retcode < nres))
        printf("%s\n", responses[retcode]);
    else {
        printf("%d\n", retcode);
        hangup(comport);
        return 0;
    }
    if ((retcode == M_CONN3) || (retcode == M_CONN12) ||
        (retcode == M_CONN24)) {
            term();
    }
    return 0;
}

term ()
{
    int  ch = 0;
    int  c;
    clrscr();
    while (1)  {

       /* Poll the keyboard buffer for available keystrokes.       */
       /* Meanwhile, the receive queue is checked for available    */
       /* characters, check for errors and check the modem status  */


       if ((ch=s_rcvchar())!=-1)  {

           /* If a character(s) is available in the receive queue,  */
           /* fetch it. If it is and escape character, it must be   */
           /* check to see if it is the start of an ansi sequence.  */
           /* Otherwise the cursor position is updated, and the     */
           /* character is printed.                                 */

           if (cmDebug)  {
               printf ("%c (%02X) ",ch,ch);
           }
           else if (ch == 0x0c) clrscr();
           else if (ch == kbESC )
           {
              ansi();
              gotoxy(x, y);
              continue;
           }
           else printf ("%c",ch);
       }
       /* When a key is pressed, the key is fetched, and the    */
       /* keyboard flags are checked to see if the alt key was  */
       /* also pressed. If the alt key was pressed, we must     */
       /* check if the key is a valid command, and if so        */
       /* process it accordingly                                */

       if  (kbhit())  {
           ch=getch();
           switch (ch)   {
               case 00:
                   ch = getch();
                   ch &= 0x00ff;
                   switch(ch)  {

                           /* Upload file    */

                        case kbPageUp:
                           send();
                           break;

                           /* Download file   */

                        case kbPageDn:
                           receive();
                           break;

                        default:
                           c = ch << 8;
                           if (c != 0)
                              ansi_map (ch);
                           break;
                   }

                  /* Menu function   */

               case 0x0f:
                  menu();
                  break;

                  /* Hayes modem hang up command   */

               case 0x04:
                  hangup(comport);
                  return;
               default:
                  s_sendchar(ch);
                  if (cmEcho)  {
                      putchar(ch);
                      if (ch=='\r')
                          putchar('\n');
                  }
                  break;
           }
       }
    }
    hangup(comport);
}

send()
{
    int retcode;
    int fd;
    char filename[128];

    printf ("\nUpload filename : ");
    gets (filename);
    if ((fd = open(filename, O_BINARY | O_RDONLY)) < 0)  {
       printf ("File %s not found .\n",strupr(filename));
       return 1;
    }
    else  {
       printf ("Upload file size = %u\n",filelength(fd));
       close (fd);
    }
    retcode = sendfile(comport, filename);
    printf ("\n");
    if (retcode==1)  printf(" Sendfile  Succeed !\n");
    if (retcode==0)  printf(" Sendfile  Disconn !\n");
    if (retcode==-1) printf(" Openfile   Error  !\n");
    return 0;
}

receive()
{
    int retcode;
    int fd;
    char filename[128];

    printf ("\nDownload filename : ");
    gets (filename);
    if ((fd = open(filename, O_BINARY | O_RDONLY)) >= 0)  {
       printf ("File already exist .\n");
       close (fd);
       return 1;
    }
	retcode = rcvfile(comport, filename);
    printf ("\n");
	if (retcode==0)  printf(" Rcvfile Disconn  !\n");
	if (retcode==1)  printf(" Rcvfile Succeed  !\n");
	if (retcode==-1) printf(" Openfile  Error  !\n");
	if (retcode==-2) printf(" Creatfile Error  !\n");
    return 0;
}

menu()
{
    int c;
    char phone_number[32];
    static char *menus[] = {
        "\tE.      Echo flag",
        "\tD.      Dial a phone number",
        "\tA.      Answer incoming call",
        "\tS.      Send a file using XMODEM protocal",
        "\tR.      Receive a file using XMODEM protocal",
        "\tQ.      Exit",
        ""     /* null string terminates list  */
    };
    char **menup;
    do  {
        puts ("\n\n");
        for (menup=menus;**menup!=NULL;menup++)
            printf ("%s\n",*menup);
        printf ("\n\t\tEnter selection (CR to quit menu):");
        if ((c=getche())==kbCR)
           break;
        c=toupper(c);
        switch (c)  {
            case FORMAT:
                cmEcho=!cmEcho;
                break;
            case DIAL:
                printf ("\n\tDial number : ");
                gets (phone_number);
                dial_cmd(phone_number);
                break;
            case ANSWER:
                setdtr(comport, ON);
                m_cmd("E0V1X4&C1&D2S0=1");
                term ();
                break;
            case XSEND:
                send();
                break;
            case XRECV:
                receive();
                break;
            case EXIT:
                break;
            default:
                puts ("Invalid choice \n\007");
                break;
        }
    } while (c!=EXIT);
    puts ("\n");
}

ansi_map (ScanVal)
unsigned        ScanVal;
{
   register        KeyCode;
   register char  *s, c;

   KeyCode = ScanVal >> 8;      /* Isolate to key scan code */
   if ((KeyCode < 0x3b) || (KeyCode > 0x5d))
      return;                   /* Not in range, give up    */
   s = ansi_seq[KeyCode - 0x3b];/* Index to our sequence    */
   s_puts (s);/* Send the mapped string   */
}


/*
**
** ansi control sequence
**
*/

void ansi(void)
{
unsigned key;
int c;
char str[10];
int Pn[10] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
int i=0,p=0;
static int oldx=1;
static int oldy=1;


      /* While we are waiting for the next character, keep   */
      /* checking for keys.                                  */


   while((c = s_getc()) == -1)

   if(bioskey(1))
   {
      key = bioskey(0);
      s_putc((char)key);
   }


      /* If the next character is a '[' it is probably an ansi    */
      /* sequence. If the next character is not a '[', print the  */
      /* previous escape character followed by the new character. */

   if(c != '[')
   {
      cprintf("\x1b%c",c);
      return;
   }

   while(1)
   {

      /* Read the rest of the ansi sequence, while also checking  */
      /* for keys.                                                */

      while((c = s_getc()) == -1)

         if(bioskey(1))
         {
            key = bioskey(0);
            s_putc((char)key);
         }


         /* If the character is numeric, store it still it it's   */
         /* ascii form                                            */

      if(isdigit(c))
      {
         *(str+i++) = c;
         continue;
      }


         /* When no more numeric characters are received, terminate  */
         /* the string and convert it to an integer, storing it in   */
         /* the parameter queue.                                     */

      *(str+i) = '\0';
      i=0;
      Pn[p++] = atoi(str);


         /* Check for the ';' delimiter   */

      if(c == ';')
         continue;


         /* When no more numeric parameters are received, the     */
         /* command should be next. Now we can actually process   */
         /* the command using the stores parameters               */

      else
      {
         switch(c)
         {


               /* (CUP) set cursor position  */

            case 'H':
            case 'F':
               y = Pn[0] ? Pn[0] : 1;
               x = Pn[1] ? Pn[1] : 1;
               return;


               /* (CUU) cursor up   */

            case 'A':
               y -= Pn[0];
               if(y < 1)
                  y = 1;
               return;


               /* (CUD) cursor down */

            case 'B':
               y += Pn[0];
               if(y > 24)
                  y = 24;
               return;


               /* (CUF) cursor forward */

            case 'C':
               x += Pn[0];
               if(x >80)
                  x = 80;
               return;


               /* (CUB) cursor backward   */

            case 'D':
               x -= Pn[0];
               if(x < 1)
                  x = 1;
               return;


               /* (SCP) save cursor position */

            case 's':
               oldx = x;
               oldy = y;
               return;


               /* (RCP) restore cursor position */

            case 'u':
               x = oldx;
               y = oldy;
               return;


               /* clear screen   */

            case 'J':
               if(Pn[0] == 2)
               {
                  clrscr();
                  x=1;
                  y=1;
               }
               else
               {
                  window(1,wherey(),80,24);
                  clrscr();
                  window(1,1,80,24);
                  gotoxy(x, y);
               }
               return;


               /* (EL) erase line   */

            case 'K':
               clreol();
               return;


               /* (IL) insert line   */

            case 'L':
               for (; Pn[0] <0; Pn[0]--)
                  insline();
               return;


               /* (DL) delete line   */

            case 'M':
               for (; Pn[0] <0; Pn[0]--)
                  delline();
               return;


               /* An attribute command is more elaborate than the    */
               /* others because it may have many numeric parameters */

            case 'm':
               for(i=0; i<p; i++)
               {


                     /* values from 30 to 37 define the foreground color   */

                  if(Pn[i] >= 30 && Pn[i] <= 37)
                  {
                     attrib &= 0xf8;
                     attrib |= (Pn[i] - 30);
                  }


                     /* values from 40 to 47 define the background color   */

                  if(Pn[i] >= 40 && Pn[i] <= 47)
                  {
                     attrib &= 0x8f;
                     attrib |= ((Pn[i] - 40) << 4);
                  }


                     /* values from 0 to 7 define the other attributes   */

                  if(Pn[i] >= 0 && Pn[i] <= 7)
                     switch(Pn[i])
                     {

                        case 0:
                           attrib = NORM;
                           break;

                        case 1:
                           attrib |= BOLD;
                           break;

                        case 2:
                           attrib &= FAINT;
                           break;

                        case 5:
                        case 6:
                           attrib |= BLINK;
                           break;

                        case 7:
                           attrib ^= REVRS;
                           break;

                        default:
                           attrib = NORM;
                     }
               }


               /* The red and blue bits in the ansi standard are     */
               /* reversed relative to the IBM. Therefore, before we */
               /* set the new attributes, if these bits are in       */
               /* opposite states toggled. This must be done for     */
               /* both the foreground and background.                */

               if((attrib & 0x05) == 0x04 || (attrib & 0x05) == 0x01)
                  attrib ^= 0x05;

               if((attrib & 0x50) == 0x40 || (attrib & 0x50) == 0x10)
                  attrib ^= 0x50;

               textattr(attrib);

            default:
               return;
         }
      }
   }
}
