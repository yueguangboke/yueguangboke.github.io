﻿<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.7
'// 插件制作:    William Long
'// 备    注:    博客年度统计
'// 最后修改：   William Long
'// 最后版本:    1.7
'///////////////////////////////////////////////////////////////////////////////
%>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="c_option.asp" -->
<!-- #include file="function/c_function.asp" -->
<!-- #include file="function/c_function_md5.asp" -->
<!-- #include file="function/c_system_lib.asp" -->
<!-- #include file="function/c_system_base.asp" -->
<!-- #include file="function/c_system_event.asp" -->
<%
	BlogYear="2007"  ' 统计的年份，修改这个数字可以统计不同年份的数据

	Call System_Initialize()
	Call CheckReference("")
	Dim objRS
	Set objRS = objConn.Execute("SELECT COUNT([log_ID])AS allArticle,SUM([log_CommNums]) AS allCommNums,SUM([log_ViewNums]) AS allViewNums,SUM([log_TrackBackNums]) AS allTrackBackNums FROM [blog_Article] WHERE year(log_PostTime)=" + BlogYear + " ")
	If (Not objRS.bof) And (Not objRS.eof) Then
		allArticle=objRS("allArticle")
		allCommNums=objRS("allCommNums")
		allTrackBackNums=objRS("allTrackBackNums")
		allViewNums=objRS("allViewNums")
	End If

%><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<%=ZC_BLOG_LANGUAGE%>" lang="<%=ZC_BLOG_LANGUAGE%>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Language" content="<%=ZC_BLOG_LANGUAGE%>" />
	<link rel="stylesheet" rev="stylesheet" href="CSS/admin.css" type="text/css" media="screen" />
	<script language="JavaScript" src="script/common.js" type="text/javascript"></script>
	<title>博客年度统计系统</title>
</head>
<body>

<p><h1>博客年度统计系统</h1></p>

<h3>全年综合统计:</h3>
<ul>
	<li><strong>文章数</strong>: <%= allArticle%>条日志</li>
	<li><strong>浏览数</strong>: <%= allViewNums%>次</li>
	<li><strong>评论数</strong>: 
<%
	Dim objRS1
	Set objRS1=objConn.Execute("SELECT COUNT([comm_ID]) FROM [blog_Comment] WHERE year(comm_PostTime)=" + BlogYear + " ")
	If (Not objRS1.bof) And (Not objRS1.eof) Then
		Response.Write objRS1(0)&"条评论"
	End If
%>
	</li>
	<li><strong>引用数</strong>: 
<%
	Dim objRS2
	Set objRS2=objConn.Execute("SELECT COUNT([tb_ID]) FROM [blog_TrackBack] WHERE year(tb_PostTime)=" + BlogYear + " ")
	If (Not objRS2.bof) And (Not objRS2.eof) Then
		Response.Write objRS2(0)&"条引用"
	End If
%>
	</li>
</ul>
<p>　</p>
<h3>月度热门文章:</h3>

<%
	For intMonth=1 To 12
%>
<p><strong><%= intMonth%>月</strong> </p>
<ul>
<%
	Set objRS = objConn.Execute("SELECT TOP 5 log_ID,log_URL,log_Title FROM [blog_Article] WHERE year(log_PostTime)=" + BlogYear + " and month(log_PostTime)=" + CStr(intMonth) +" order by log_ViewNums DESC")
	While Not objRS.eof
		ID = objRS("log_ID")
		Alias = objRS("log_URL")
		log_Title = objRS("log_Title")
		If IsNull(Alias) Or IsEmpty(Alias) Or Alias="" Then
			StaticName = ID
		Else
			StaticName = Alias
		End If
%>
	<li>
	<a target="_blank" href="<%= ZC_BLOG_HOST & ZC_STATIC_DIRECTORY & "/" & FileName & StaticName & "." & ZC_STATIC_TYPE %>">
	<%= log_Title%></a>
	</li>
<%
		objRS.MoveNext
	Wend
%>
</ul>
<%
	Next
%>

</body>
</html>
<%
Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>

