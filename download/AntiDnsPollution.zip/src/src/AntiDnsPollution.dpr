program AntiDnsPollution;

{$APPTYPE CONSOLE}

{$R ..\res\AntiDNSSollutionVersionDOS.res}

uses
  SysUtils,
  UMain in 'UMain.pas',
  DNSResponseFilter in 'DNSResponseFilter.pas';

begin
  { TODO -oUser -cConsole Main : Insert code here }
  Main;
end.
