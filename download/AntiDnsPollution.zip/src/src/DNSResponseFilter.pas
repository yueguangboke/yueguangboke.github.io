unit DNSResponseFilter;

interface

uses
  Windows, Messages, SysUtils, Classes, IdWinsock2, IdUDPClient, IdUDPServer,
  IdComponent, IdGlobal, IdSocketHandle;

type
  TProperties = record
    BindIP: string;
    DnsServer: string;
    ResponseTimeout: Integer;
    FakeDnsServer: string;
    FakeRespTimeout: Integer;
    TryTimes: Integer;
  end;


  EDNSResponseFilterError = class (Exception);
  EIllegalArgumentError = class(EDNSResponseFilterError);
  EArrayIndexOutOfBoundsError = class(EDNSResponseFilterError);

  TDNSResponseFilter = class (TComponent)
  private
    FServerProps: TProperties;
    FMREWSync: TMREWSync;
    FStopped: LongBool;
    FFakeIPs: TList;
    FServer: TIdUDPServer;
    FFilterCount: Integer;
    FDNSCount: Integer;
    class function SkipDnsName(ABuf: PAnsiChar; AOffset, ALen: Integer): Integer;
    class function FindResponseAddr(ABuf: PAnsiChar; ALen: Integer): Cardinal;
    procedure OnUDPRead(AThread: TIdUDPListenerThread; AData: TIdBytes; ABinding: TIdSocketHandle);
    procedure SetDefaultServerProps;
  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;

    procedure LoadProperties(const APropertyFile: string);
    procedure SaveProperties(const APropertyFile: string);

    function FakeIPCount: Integer;

    procedure Start;
    procedure Stop;

    property FilterCount: Integer read FFilterCount;
    property DNSCount: Integer read FDNSCount;
  end;

implementation

uses
  IniFiles;

const
  DefaultIniSectionName = 'AntiDnsPollution';
  DefaultDNSRequestData: array [0.. 28] of Byte = ($00, $02, $01, $00, $00, // 5
                                                   $01, $00, $00, $00, $00, // 10
                                                   $00, $00, $07, $74, $77, // 15
                                                   $69, $74, $74, $65, $72, // 20
                                                   $03, $63, $6f, $6d, $00, // 25
                                                   $00, $01, $00, $01);

{ TDNSResponseFilter }

constructor TDNSResponseFilter.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FMREWSync := TMREWSync.Create;
  FFakeIPs := TList.Create;
  FFakeIPs.Capacity := 100;
  FServer := TIdUDPServer.Create(Self);
  FServer.ThreadedEvent := True;
  with FServer.Bindings.Add do
  begin
    IP := '0.0.0.0';
    Port := 53;
  end;
  FServer.OnUDPRead := OnUDPRead;
  SetDefaultServerProps;
end;

destructor TDNSResponseFilter.Destroy;
begin
  FServer.Free;
  FFakeIPs.Free;
  FMREWSync.Free;
  inherited Destroy;
end;

function TDNSResponseFilter.FakeIPCount: Integer;
begin
  FMREWSync.BeginRead;
  try
    Result := FFakeIPs.Count;
  finally
    FMREWSync.EndRead;
  end;
end;

class function TDNSResponseFilter.FindResponseAddr(ABuf: PAnsiChar;
  ALen: Integer): Cardinal;
var
  I: Integer;
  LAddr: LongRec;
begin
  I := SkipDnsName(ABuf, SkipDnsName(ABuf, 12, ALen) + 4, ALen) + 10;
  if (I + 4) > ALen then
    raise EArrayIndexOutOfBoundsError.CreateFmt('i (%d) is out of bounds', [I + 4]);
  Move(ABuf[i], LAddr.Bytes[0], SizeOf(LAddr));
  Result := Integer(LAddr);
end;

procedure TDNSResponseFilter.LoadProperties(const APropertyFile: string);
var
  LPropIni: TIniFile;
begin
  LPropIni := TIniFile.Create(APropertyFile);
  try
    FServerProps.BindIP := LPropIni.ReadString(DefaultIniSectionName,
      'BindIP', FServerProps.BindIP);
    FServerProps.DnsServer := LPropIni.ReadString(DefaultIniSectionName,
      'DnsServer', FServerProps.DnsServer);
    FServerProps.ResponseTimeout := LPropIni.ReadInteger(DefaultIniSectionName,
      'ResponseTimeout', FServerProps.ResponseTimeout);
    FServerProps.FakeDnsServer := LPropIni.ReadString(DefaultIniSectionName,
      'FakeDnsServer', FServerProps.FakeDnsServer);
    FServerProps.FakeRespTimeout := LPropIni.ReadInteger(DefaultIniSectionName,
      'FakeRespTimeout', FServerProps.FakeRespTimeout);
    FServerProps.TryTimes := LPropIni.ReadInteger(DefaultIniSectionName,
      'TryTimes', FServerProps.TryTimes);
  finally
    LPropIni.Free;
  end;
end;

procedure TDNSResponseFilter.OnUDPRead(AThread: TIdUDPListenerThread;
  AData: TIdBytes; ABinding: TIdSocketHandle);

  function IsFilteredIP(ABuf: PAnsiChar; ALen: Integer): Boolean;
  var
    LResponseAddr: Cardinal;
    I: Integer;
  begin
    Result := False;
    LResponseAddr := INADDR_ANY;
    try
      LResponseAddr := FindResponseAddr(PAnsiChar(@AData[0]), Length(AData));
    except
      // do nothing
    end;
    if LResponseAddr <> INADDR_ANY then
    begin
      Result := False;
      FMREWSync.BeginRead;
      try
        for I := 0 to FFakeIPs.Count - 1 do
          if LResponseAddr = Cardinal(FFakeIPs[I]) then
          begin
            InterlockedIncrement(FFilterCount);
            Result := True;
            Break;
          end;
      finally
        FMREWSync.EndRead;
      end;
    end;
  end;
  
var
  LBuf: TIdBytes;
  LClient: TIdUDPClient;
  LRecievedLen: Integer;
begin
  InterlockedIncrement(FDNSCount);
  SetLength(LBuf, MAXWORD);
  LClient := TIdUDPClient.Create;
  try
    LClient.Host := FServerProps.DnsServer;
    LClient.Port := 53;
    LClient.ReceiveTimeout := FServerProps.ResponseTimeout;
    LClient.SendBuffer(AData);
    LRecievedLen := LClient.ReceiveBuffer(LBuf);
    if LRecievedLen > 0 then
    begin
      if not IsFilteredIP(PAnsiChar(@LBuf[0]), LRecievedLen) then
        ABinding.SendTo(ABinding.PeerIP, ABinding.PeerPort, LBuf, 0, LRecievedLen);
    end;
  finally
    LClient.Free;
  end;
end;

procedure TDNSResponseFilter.SaveProperties(const APropertyFile: string);
var
  LPropIni: TIniFile;
begin
  LPropIni := TIniFile.Create(APropertyFile);
  try
    LPropIni.WriteString(DefaultIniSectionName, 'BindIP', FServerProps.BindIP);
    LPropIni.WriteString(DefaultIniSectionName, 'DnsServer', FServerProps.DnsServer);
    LPropIni.WriteInteger(DefaultIniSectionName, 'ResponseTimeout', FServerProps.ResponseTimeout);
    LPropIni.WriteString(DefaultIniSectionName, 'FakeDnsServer', FServerProps.FakeDnsServer);
    LPropIni.WriteInteger(DefaultIniSectionName, 'FakeRespTimeout', FServerProps.FakeRespTimeout);
    LPropIni.WriteInteger(DefaultIniSectionName, 'TryTimes', FServerProps.TryTimes);
  finally
    LPropIni.Free;
  end;
end;

procedure TDNSResponseFilter.SetDefaultServerProps;
begin
  FServerProps.BindIP := '0.0.0.0';
  FServerProps.DnsServer := '208.67.222.222';
  FServerProps.ResponseTimeout := 10000;
  FServerProps.FakeDnsServer := '129.250.3.125';
  FServerProps.FakeRespTimeout := 1000;
  FServerProps.TryTimes := 100;
end;

class function TDNSResponseFilter.SkipDnsName(ABuf: PAnsiChar; AOffset,
  ALen: Integer): Integer;
begin
  while SmallInt(ABuf[AOffset]) <> 0 do
  begin
    if SmallInt(ABuf[AOffset]) < 0 then
    begin
      if (Byte(ABuf[AOffset]) = $c0) and (Byte(ABuf[AOffset + 1]) = $0c) then
      begin
        Result := AOffset + 2;
        Exit;
      end;
      raise EIllegalArgumentError.Create('Argument ABUF is illegal.');
    end;
    Inc(AOffset, Byte(ABuf[AOffset]));
    Inc(AOffset);
    if AOffset >= ALen then
      raise EArrayIndexOutOfBoundsError.CreateFmt('AOffset (%d) is out of bounds',
        [AOffset]);
  end;
  Inc(AOffset);
  Result := AOffset;
end;

procedure TDNSResponseFilter.Start;
var
  LBuf: TIdBytes;
  LClient: TIdUDPClient;
  LFakeIPList: TList;
  LTryTimes: Integer;
  I: Integer;
  LRequest: TIdBytes;
  LRecievedLen: Integer;
  LResponseAddr: Cardinal;
begin
  if not FServer.Active then
  begin
    InterlockedExchange(FFilterCount, 0);
    InterlockedExchange(FDNSCount, 0);
    InterlockedExchange(Integer(FStopped), Integer(False));

    FServer.Bindings[0].IP := FServerProps.BindIP;

    SetLength(LBuf, MAXWORD);
    LFakeIPList := TList.Create;
    try
      LFakeIPList.Capacity := 100;
      LClient := TIdUDPClient.Create;
      try
        LClient.ReceiveTimeout := FServerProps.FakeRespTimeout;
        LClient.Host := FServerProps.FakeDnsServer;
        LClient.Port := 53;
        LTryTimes := FServerProps.TryTimes;
        for I := 1 to LTryTimes do
        begin
          if FStopped then Abort;
          LRequest := RawToBytes(DefaultDNSRequestData[0], SizeOf(DefaultDNSRequestData));
          LClient.SendBuffer(LRequest);
          try
            LRecievedLen := LClient.ReceiveBuffer(LBuf);
          except
            Continue;
          end;
          LResponseAddr := INADDR_ANY;
          try
            LResponseAddr := FindResponseAddr(PAnsiChar(@LBuf[0]), LRecievedLen);
          except
            on E: EDNSResponseFilterError do
            begin
              // nothing
            end;
          else
            raise;
          end;
          if (LResponseAddr <> INADDR_ANY) and
            (LFakeIPList.IndexOf(Pointer(LResponseAddr)) = -1) then
            LFakeIPList.Add(Pointer(LResponseAddr));
        end;
        FMREWSync.BeginWrite;
        try
          FFakeIPs.Assign(LFakeIPList);
        finally
          FMREWSync.EndWrite;
        end;
        if not FStopped then
          FServer.Active := True;
      finally
        LClient.Free;
      end;
    finally
      LFakeIPList.Free;
    end;
  end;
end;

procedure TDNSResponseFilter.Stop;
begin
  InterlockedExchange(Integer(FStopped), Integer(True));
  FServer.Active := False;
end;

end.
