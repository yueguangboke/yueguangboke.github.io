<%@ CODEPAGE=65001 %>
<%

'///////////////////////////////////////////////////////////////////////////////
'// ���Ӧ��:    Z-Blog 1.4�����ϵİ汾
'// �������:    williamlong(http://www.williamlong.info)
'// ��    ע:    Blog Roll�Ĵ���
'// ����޸ģ�   2006-2-13
'// ���汾:    1.0.0
'// ��    ע:    �����includeĿ¼��ִ�У�opml�ļ���Ϊexport.opml
'///////////////////////////////////////////////////////////////////////////////

strXMLfile = Server.MapPath("export.opml") 'Ĭ�ϵ�opml�ļ���
strLinkfile = Server.MapPath("link.asp")   'Ĭ��������ļ���

set xmlObj = Server.CreateObject("Microsoft.XMLDOM")
' load
xmlObj.async = False
'xmlObj.loadXML(strXML)
xmlObj.load(strXMLfile)

strOut = " "
' parse opml
set objRoot = xmlObj.documentElement
set objChannel = objRoot.selectSingleNode("body")

for each child in objChannel.childNodes 
for each category in child.childnodes 
'response.write category
for each item in category.childnodes
title=item.getattribute("title")
xmlurl = item.getattribute("xmlUrl") 
url= getUrl (xmlurl)
strOut = strOut + "<li><a href=" & url &" target=_blank>" & title & "</a> (<a href=" & xmlurl &" target=_blank>" & "RSS</a>)</li>" 
next
next
Next

	'д�ļ�
	Dim objStream
	Set objStream = Server.CreateObject("ADODB.Stream")
	With objStream
	.Type = 2
	.Mode = 3
	.Open
	.Charset = "utf-8"
	.Position = objStream.Size
	.WriteText = strOut
	.SaveToFile strLinkfile,2
	.Close
	End With
	Set objStream = Nothing

response.write "Success ..."

' clean up
Set objRoot = Nothing
set objChannel = Nothing
Response.Flush 
set xmlObj = nothing 

Public Function getUrl (strXMLurl)
If strXMLurl<>"" then
intPos = InStrRev (strXMLurl,"/")
getUrl = Left (strXMLurl,intPos)
Else
getUrl = ""
End if
End Function

'grab file from Bloglines
'strXMLfile = "http://www.bloglines.com/export?id=admin"
'strXML = getOpmlFromBloglines (strXMLfile)
Public Function getOpmlFromBloglines (strXMLfile)
Set xmlHTTP = Server.CreateObject("Microsoft.XMLHTTP")
xmlHTTP.Open "GET",strXMLfile,false
xmlHTTP.SetRequestHeader "Content-type", "text/xml"
xmlHTTP.Send
getOpmlFromBlog = xmlHTTP.ResponseText
Set xmlHTTP = Nothing
End Function

%>
