﻿<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    Akismet反垃圾留言的插件代码
'// 最后修改：   2009-2-11
'// 最后版本:    1.0.0
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../function/c_function.asp" -->
<!-- #include file="../../function/c_function_md5.asp" -->
<!-- #include file="../../function/c_system_lib.asp" -->
<!-- #include file="../../function/c_system_base.asp" -->
<!-- #include file="../../function/c_system_event.asp" -->
<!-- #include file="../../function/c_system_plugin.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6) 

	Dim strContent
	strContent=LoadFromFile(BlogPath & "/PLUGIN/Akismet/include.asp","utf-8")

	Dim strZC_cc_opt_comment_Akismet
	strZC_cc_opt_comment_Akismet=Request.Form("strZC_cc_opt_comment_Akismet")
	Call SaveValueForSetting(strContent,True,"String","cc_opt_comment_Akismet",strZC_cc_opt_comment_Akismet)

	Dim strZC_cc_opt_comment_verify
	strZC_cc_opt_comment_verify=Request.Form("strZC_cc_opt_comment_verify")
	Call SaveValueForSetting(strContent,True,"Boolean","cc_opt_comment_verify",strZC_cc_opt_comment_verify)

	Call SaveToFile(BlogPath & "/PLUGIN/Akismet/include.asp",strContent,"utf-8",False)


Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>
<script type="text/javascript">window.location="setting.asp"</script>
