<%
	Response.Redirect "setting.asp"
%>