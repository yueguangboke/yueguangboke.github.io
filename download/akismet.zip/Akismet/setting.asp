﻿<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    Akismet反垃圾留言的插件代码
'// 最后修改：   2009-2-11
'// 最后版本:    1.0.0
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../function/c_function.asp" -->
<!-- #include file="../../function/c_function_md5.asp" -->
<!-- #include file="../../function/c_system_lib.asp" -->
<!-- #include file="../../function/c_system_base.asp" -->
<!-- #include file="../../function/c_system_event.asp" -->
<!-- #include file="../../function/c_system_plugin.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6) 

BlogTitle="Akismet反垃圾留言系统"

%><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<%=ZC_BLOG_LANGUAGE%>" lang="<%=ZC_BLOG_LANGUAGE%>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Language" content="<%=ZC_BLOG_LANGUAGE%>" />
	<link rel="stylesheet" rev="stylesheet" href="../../CSS/admin.css" type="text/css" media="screen" />
	<script language="JavaScript" src="../../script/common.js" type="text/javascript"></script>
	<title><%=BlogTitle%></title>
</head>
<body>

			<div id="divMain">
<div class="Header">Akismet反垃圾留言系统</div>
<div class="SubMenu"><span class="m-left m-now"><a href="setting.asp">Akismet配置</a></span><span class="m-left"><a href="setting1.asp">审核评论<%
	Dim objRS1
	Set objRS1=objConn.Execute("SELECT COUNT([comm_ID]) FROM [blog_Comment] WHERE [log_ID]<0")
	If (Not objRS1.bof) And (Not objRS1.eof) Then
		Response.Write "("&objRS1(0)&"条未审核的评论)"
	End If
%></a></span><span class="m-left"><a href="setting2.asp">标记垃圾评论</a></span></div>

<div id="divMain2">
<form id="edit" name="edit" method="post">
<%

	Dim tmpSng

	tmpSng=LoadFromFile(BlogPath & "/PLUGIN/Akismet/include.asp","utf-8")

	Dim strZC_cc_opt_comment_Akismet
	If LoadValueForSetting(tmpSng,True,"String","cc_opt_comment_Akismet",strZC_cc_opt_comment_Akismet) Then
		strZC_cc_opt_comment_Akismet=TransferHTML(strZC_cc_opt_comment_Akismet,"[html-format]")
		Response.Write "<p>※WordPress.com API Key (<a href='http://wordpress.com/api-keys/'>申请</a>):</p><p><input name=""strZC_cc_opt_comment_Akismet"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_comment_Akismet & """ ONCLICK=""ChangeValue(this);"" /></p><p></p>"
	End If

	Dim strZC_cc_opt_comment_verify
	If LoadValueForSetting(tmpSng,True,"Boolean","cc_opt_comment_verify",strZC_cc_opt_comment_verify) Then
		strZC_cc_opt_comment_verify=TransferHTML(strZC_cc_opt_comment_verify,"[html-format]")
		Response.Write "<p>※是否手动审核垃圾留言:</p><p><input name=""strZC_cc_opt_comment_verify"" style=""width:99%"" type=""text"" value=""" & strZC_cc_opt_comment_verify & """ ONCLICK=""ChangeValue(this);"" /></p><p></p>"
	End If

	Response.Write "<hr/>"
	Response.Write "<p><input type=""submit"" class=""button"" value="""& ZC_MSG087 &""" id=""btnPost"" onclick='document.getElementById(""edit"").action=""savesetting.asp"";' /></p>"


%>

</form>

</div>
<script language="javascript">
function ChangeValue(obj){

	if (obj.value=="True")
	{
	obj.value="False";
	return true;
	}

	if (obj.value=="False")
	{
	obj.value="True";
	return true;
	}
}
</script>
</body>
</html>
<%
Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>

