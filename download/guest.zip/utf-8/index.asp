<%@ CODEPAGE=65001 %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->

<%

response.buffer=true
Response.Expires=0

usercookies=Request.Cookies("usercookies")
if not session("password")<>"" then
if usercookies > "0" then
	name=Request.Cookies("usernamebook")
	password=Request.Cookies("passwordbook")
	sql="select * from admin where id=1"
	set rs8=conn.execute(sql)
	if not(rs8.bof and rs8.eof) then
		if password=rs8("userpass") and name=rs8("username") then
		   session("user")=name
		   session("password")="wpassword"
		end if
	end if
end if
end if

Set rs9 = Server.CreateObject("ADODB.Recordset")
sql9 ="SELECT * From about Order By id DESC"
RS9.open sql9,Conn,3,3
mypagesize=cint(rs9("num"))  '每页显示留言数
badnicks=rs9("badnicks")
badwords=rs9("badwords")

Set rs = Server.CreateObject("ADODB.Recordset")
sql = "Select * FROM guestbook Order By dateandtime Desc"
rs.open sql,conn,1,1

IF not IsNumeric(Request("page")) Or IsEmpty(Request("page")) Then
page=1
Else
Page=Int(Abs(Request("page")))
End if
rs.pagesize = mypagesize
total  = rs.RecordCount
rs.absolutepage = page

if request("test")="insert" then

'校验码判断开始
If Request("checkcode")="" Then
	MessageBox "别椤着,请返回输入验证码啊~~~"
    response.end
Elseif Session("CheckCode")="" then
	MessageBox "请返回后请刷新登录页面后重新输入正确的信息~~~"
    response.end
ElseIf Cstr(Session("CheckCode"))<>Cstr(Trim(Request("checkcode"))) Then
	MessageBox "您输入的验证码和系统产生的不一致，请重新输入。~~~"
    response.end
End if
'校验码判断结束

'防止垃圾留言功能开始
dim ComeUrl,cUrl
ComeUrl=lcase(trim(request.ServerVariables("HTTP_REFERER")))
if ComeUrl="" then
	MessageBox "错误信息：对不起，为了系统安全，不允许直接输入地址访问本页面。"
	response.end
else
	cUrl=trim("http://" & Request.ServerVariables("SERVER_NAME"))
	if mid(ComeUrl,len(cUrl)+1,1)=":" then
		cUrl=cUrl & ":" & Request.ServerVariables("SERVER_PORT")
	end if
	cUrl=lcase(cUrl & request.ServerVariables("SCRIPT_NAME"))
	if lcase(left(ComeUrl,instrrev(ComeUrl,"/")))<>lcase(left(cUrl,instrrev(cUrl,"/"))) then
		MessageBox "错误信息：留言本防垃圾留言功能已经打开，禁止从外部链接地址提交留言。"
		response.end
	end if
end if
'防止垃圾留言功能结束

txtname=left(request("txtname"),30)
txtemail=left(request("txtemail"),30)
txthomepage=left(request("txthomepage"),50)
txtoicq=left(request("txtoicq"),10)
if request.form("xxx")="" then
pic="images/1.gif"
else
pic=request.form("xxx")
end if
txtcome=left(request("txtcome"),20)
sex=request("sex")
txtcontent=left(request("txtcontent"),500)

'设置灌水限制
posttime=60
if cint(posttime)<>0 then
	if not isnull(session("posttime")) or cint(posttime)>0 then
		if DateDiff("s",session("posttime"),Now())<cint(posttime) then
		MessageBox "错误信息：留言本防灌水功能已经打开，限制"&posttime&"秒内不能重复留言。"
		response.end
		end if
	end if
end if

if txtemail<>"" and IsValidEmail(txtemail)=false then
	MessageBox "错误信息：邮件地址填写出错：请确认你的邮件地址。" 
	response.end
end if

if txtname="" then
	MessageBox "别椤着,输入内容啊~~~"
    response.end
end if

if txtcontent=""  then
	MessageBox "错误信息：请填入你的名字！"
    response.end
end if

if txtemail="" then txtemail="不告诉你!"
if txtoicq="" then txtoicq="打死我也不说!"
if txtcome="" then txtcome="保密!"
if txthomepage="" or txthomepage="http://" then txthomepage="还没有呢!"

Function htmlencode(source)

	Dim objRegExp

	source=Replace(source,vbTab,"&nbsp;&nbsp;")
	source=Replace(source,"<"&"%","&lt;"&"%")
	source=Replace(source,"%"&">","%"&"&gt;")
	source=Replace(source,"<a ","<a rel=""nofollow"" ")
	Set objRegExp=New RegExp
	objRegExp.IgnoreCase =True
	objRegExp.Global=True
	objRegExp.Pattern="<[^>]*>"
	source= objRegExp.Replace(source,"")
	source=Replace(source,"&","&amp;")
	source=Replace(source,"<","&lt;")
	source=Replace(source,">","&gt;")
	source=Replace(source,"""","&quot;")

	htmlencode=source

End Function

function MessageBox(strOutput)
		response.write "<script language='javascript'>" & VbCRlf
	    response.write "alert('" & strOutput & "');" & VbCrlf
	    response.write "history.go(-1);" & vbCrlf
	    response.write "</script>" & VbCRLF
	    response.end
end function

function IsValidEmail(email)
 dim names, name, i, c
 IsValidEmail = true
 names = Split(email, "@")
 if UBound(names) <> 1 then
   IsValidEmail = false
   exit function
 end if
 for each name in names
   if Len(name) <= 0 then
     IsValidEmail = false
     exit function
   end if
   for i = 1 to Len(name)
     c = Lcase(Mid(name, i, 1))
     if InStr("abcdefghijklmnopqrstuvwxyz_-.", c) <= 0 and not IsNumeric(c) then
       IsValidEmail = false
       exit function
     end if
   next
   if Left(name, 1) = "." or Right(name, 1) = "." then
      IsValidEmail = false
      exit function
   end if
 next
 if InStr(names(1), ".") <= 0 then
   IsValidEmail = false
   exit function
 end if
 i = Len(names(1)) - InStrRev(names(1), ".")
 if i <> 2 and i <> 3 then
   IsValidEmail = false
   exit function
 end if
 if InStr(email, "..") > 0 then
   IsValidEmail = false
 end if

end function

function IsLongStr(str)
dim longStrs,longstr
IsLongStr = true
longStrs = Split(str,"")
for each longStr in longStrs
	if len(longstr) > 50 then
	ISlongStr = false
	end if
next
end function

txtname=htmlencode(txtname)
txtcome=htmlencode(txtcome)
txtemail=htmlencode(txtemail)
txtcome=htmlencode(txtcome)
txthomepage=txthomepage
txtoicq=htmlencode(txtoicq)
txtcontent=htmlencode(txtcontent)
reply = "没有"

'使用屏蔽昵称
check_name=txtname
badnicks=split(badnicks,",")
for i = 0 to ubound(badnicks)
	if instr(check_name,badnicks(i))>0 then
		MessageBox "错误信息：您使用了屏蔽的昵称。"
		response.end
		exit for
	end if
next

'使用屏蔽字符
check_content=txtcontent
badwords=split(badwords,",")
for i = 0 to ubound(badwords)
	if instr(check_content,badwords(i))>0 then
		MessageBox "错误信息：您使用了非法的留言内容。"
		response.end
		exit for
	end if
next

Set rs= Server.CreateObject("ADODB.Recordset")
sql="select * from guestbook"
rs.open sql,conn,3,2
rs.addnew

		rs("name")=txtname
		rs("email")=txtemail
       	rs("homepage")=txthomepage
        rs("come")=Trim(txtcome)
		rs("oicq")=txtoicq
		rs("content")=Trim(txtcontent)
		rs("head")=pic
		rs("dateandtime")=now()
		rs("reply")=reply
		rs("ip")=Request.ServerVariables("REMOTE_HOST")
		rs("sex")=cint(sex)
		rs.update
		rs.close
		if cint(posttime)<>0 then
			session("posttime")=now()
		end if
		response.redirect "index.asp"
end if
%>
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" CONTENT="<%=rs9("name")%>,留言簿">
<meta name="description" content="<%=rs9("name")%>的留言簿">
<TITLE><%=rs9("name")%></TITLE>
<style>
<!--
table, td{ font:9pt "宋体" }
.td{ font-family:"宋体";font-size:9pt;line-height:150% }
.big{ font:14.8px "宋体" }
-->
</style>
<script language=javascript>
<!--
function check()
{
if(document.login.txtname.value=="")
{alert("姓名不能为空^_^");return false}
if(document.login.txtcontent.value=="")
{alert("留言内容不能为空^_^");return false}
if(document.login.checkcode.value=="")
{alert("校验码不能为空^_^");return false}
}
-->
</script>
</head>

<body leftMargin="0" topMargin="0">

<table width="540" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td background="images/bg_left.gif" valign="top" width="100%">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td colspan="3"><img src="images/left_kuang_top.gif" width="100%" height="4"></td>
        </tr>
        <tr>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
          <td width="100%" valign="top">
            <table width="100%" border="0" cellspacing="0" cellpadding="5" height="100%">
              <tr>
                <td class="td" valign="top">
                  <table align=center border=0 cellpadding=0 cellspacing=1 bgcolor="<%=rs9("bian")%>" width=100%>
                    <tbody>
                    <%
dim i
i=1
do while not rs.eof  and mypagesize>0
id=rs("gbookid")
name=rs("name")
email=rs("email")
homepage=rs("homepage")
oicq=rs("oicq")
head=rs("head")
content=rs("content")
content=Autolink(content)
dateandtime=rs("dateandtime")
reply=rs("reply")
reply=addlink(reply)
sex=rs("sex")
%>
                    <tr>
                      <td bgcolor="<%=rs9("bgss")%>" rowspan=2 width=80>
                        <center>
                          <% if rs9("textonly")=0 then %><img border=0 src="<%=head%>"> <br><% end if %>
                          <br>
                          <%=name%>
                        </center>
                      </td>
                      <td bgcolor="<%=rs9("bgss")%>" height=20>
                        <table border=0 cellpadding=0 cellspacing=0 width="99%">
                          <tbody>
                          <tr>
                            <td valign=bottom width="50%"><font class=cha2>　发表于：<%=dateandtime%></font>
                            </td>
                            <td align=right width="50%"><img align=absBottom alt=<%=name%>来自<%=rs("come")%> border=0
            height=16 src="images/icon_profile.gif" width=16> <a
            <% if right(email,1)<>"!" then %> href="mailto:<%=email%>" <% end if %>  rel="nofollow" title="<%=name%>的邮件地址是：<%=email%>"><img align=absBottom
            border=0 height=16 src="images/icon_email.gif" width=16></a> <a
            title="<%=name%>的QQ号是：<%=oicq%>"><img align=absBottom
            border=0 height=16 src="images/icon_editor_oicq.gif" width=16></a>
                              <a
            <% if right(homepage,1)<>"!" then %> href="<%=homepage%>" <% end if %> target="_blank" rel="nofollow" title="<%=name%>的主页地址是：<%=homepage%>"><img
            align=absBottom border=0 height=16 src="images/icon_homepage.gif"
            width=16></a> <img align=absBottom alt=<%=name%>的IP地址是：<%=rs("ip")%>
            height=16 src="images/icon_ip.gif" width=16>
<% if session("password")="wpassword" then %>
							  <a href="reply.asp?gbookid=<%=id%>" title="只有版主才有回复的权限"><img  align=absBottom src="images/icon_reply_topic.gif" width="16" height="16" border="0"></a>
                              <a href="del.asp?gbookid=<%=id%>" title="只有版主才有删除留言的权限"><img  align=absBottom src="images/icon_delete_reply.gif" width="16" height="16" border="0"></a>
<% end if %>
                            </td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td bgcolor="<%=rs9("bgsrc")%>" height=80>
                        <table border=0 cellpadding=0 cellspacing=2 width="100%">
                          <tbody>
                          <tr>
                            <td><%=content%></td>
                          </tr>
                          <tr>
                            <td>
                              <%if reply<>"没有" then%>
                              <br>
                              <hr size=1>
                              <font color="#000000">版主回复：</font><font color=#B08291><%=reply%></font>
                              <%end if%>
                            </td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    <%
mypagesize=mypagesize-1
i=i+1
rs.movenext
loop
%>
                    <tr>
                      <td bgcolor="<%=rs9("bgs")%>" colspan=2 height=18 valign=bottom>
                        <div align=center>
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <form name="form2" method="post" action="index.asp">
                              <tr>
                                <td align="right" height="22"><font color="#000000">共<b><%=rs.pagecount%></b>页<b><%=total%></b>条留言
                                  当前第<b><%=page%></b>页 <a href="?page=1" class="black">首页</a>
                                  <%if page>1 then%>
                                  <a href=?page=<%=page-1%> class="black">上一页</a>
                                  <%else%>
                                  上一页
                                  <%end if%>
                                  <%if page<rs.pagecount   then%>
                                  <a href=?page=<%=page+1%> class="black">下一页</a>
                                  <%else%>
                                  下一页
                                  <%end if%>
                                  <a href=?page=<%=rs.pagecount%> class="black">尾页</a>
								  <!--
                                  <select name="page" class="bottom">
                                    <%for i=1 to rs.pagecount%>
                                    <option value=<%=i%>
									<%
					  if i=page then
					  response.write" selected"
					  end if
					  %>
									><%=i%></option>
                                    <%next%>
                                  </select>
                                  <input type="submit" name="Submit22" value="转向" class="bottom">
                                  </font>
								  -->
								  <BR>

                                    <%for i=1 to rs.pagecount
       if i=page then
          response.write "[<font color=#666666><b>"+Cstr(i)+"</b></font>] "
	   else
	      response.write "[<b>"+"<a href='?page="+cstr(i)+"'>"+Cstr(i)+"</a></b>]   "
	   end if
                                    next%>
								  
								  </td>
                              </tr>
                            </form>
                          </table>
                        </div>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                  <table align=center border=0 cellpadding=2 cellspacing=1 bgcolor="#D1DCE5" width=100%>
                    <form action=index.asp method=post name=login onSubmit="return check()">
                      <input type=hidden name=test value=insert>
                      <tr>
                        <td bgcolor="#FFFFFF" valign=top>
                          <table border=0 cellpadding=0 cellspacing=2>
                            <tbody>
                            <tr>
                              <td align=right width=20><img height=16 src="images/icon_edit_topic.gif" width=16></td>
                              <td width=33><font class=cha2>姓名<a name="bottom"></a></font></td>
                              <td>
                                <input maxlength=20 name=txtname size=20>
                                <input name=username type=hidden>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img border=0 height=16 src="images/icon_email.gif" width=16></td>
                              <td width=33><font class=cha2>Email</font></td>
                              <td>
                                <input maxlength=100 name=txtemail size=20>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img height=16 src="images/icon_homepage.gif" width=16></td>
                              <td width=33><font class=cha2>主页</font></td>
                              <td>
                                <input maxlength=100 name=txthomepage size=20 value=http://>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img border=0 height=16 src="images/icon_editor_oicq.gif" width=16></td>
                              <td width=33><font class=cha2>oicq</font></td>
                              <td>
                                <input maxlength=9 name=txtoicq size=20>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img height=16 src="images/icon_profile.gif" width=16></td>
                              <td width=33><font class=cha2>来自</font></td>
                              <td>
                                <select name=txtcome size=1>
                                  <option selected value=世界一角>请选择..
                                  <option value=北京>北京
                                  <option value=广东>广东
                                  <option value=上海>上海
                                  <option value=新疆>新疆
                                  <option value=辽宁>辽宁
                                  <option value=广西>广西
                                  <option value=海南>海南
                                  <option value=湖南>湖南
                                  <option value=甘肃>甘肃
                                  <option value=河北>河北
                                  <option value=湖北>湖北
                                  <option value=江西>江西
                                  <option value=江苏>江苏
                                  <option value=西藏>西藏
                                  <option value=山东>山东
                                  <option value=浙江>浙江
                                  <option value=安徽>安徽
                                  <option value=福建>福建
                                  <option value=吉林>吉林
                                  <option value=黑龙江>黑龙江
                                  <option value=山西>山西
                                  <option value=云南>云南
                                  <option value=贵州>贵州
                                  <option value=四川>四川
                                  <option value=陕西>陕西
                                  <option value=重庆>重庆
                                  <option value=天津>天津
                                  <option value=河南>河南
                                  <option value=青海>青海
                                  <option value=宁夏>宁夏
                                  <option value=台湾>台湾
                                  <option value=香港>香港
                                  <option value=澳门>澳门
                                  <option value=亚洲>亚洲
                                  <option value=美洲>美洲
                                  <option value=欧洲>欧洲
                                  <option value=澳洲>澳洲
                                  <option value=非洲>非洲
                                  <option value=其它地区>其它地区</option>
                                </select>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img height=16 src="images/icon_delete_reply.gif" width=16></td>
                              <td width=33><font class=cha2>校验</font></td>
                              <td>
                                <input maxlength=10 name=checkcode size=8> <img src="checkcode.asp" align="absbottom">
                              </td>
                            </tr>
                            </tbody>
                          </table>
                        </td>
                        <td bgcolor="#FFFFFF" valign=top align="center">
                          <table border=0 cellpadding=1 cellspacing=0>
                            <tbody>
                            <tr>
                              <td colspan=3 height="100">
                                <textarea class=editbox2 cols=34 name=txtcontent rows=5 type="text"></textarea>
                              </td>
                            </tr>
                            <tr>
                              <td><% if rs9("textonly")=0 then %>
							  <img alt=个人形象代表 height=32 id=face src="images/1.gif" width=32></td>
                              <td>头像</td>
                              <td>
                                <select name=xxx
            onChange="document.images['face'].src=options[selectedIndex].value;" size=1>
                                  <option selected value=images/1.gif select>头像1
                                  <option value=images/2.gif>头像2
                                  <option value=images/3.gif>头像3
                                  <option value=images/4.gif>头像4
                                  <option value=images/5.gif>头像5
                                  <option value=images/6.gif>头像6
                                  <option value=images/7.gif>头像7
                                  <option value=images/8.gif>头像8
                                  <option value=images/9.gif>头像9
                                  </option>
                                </select>
								<% end if %>
                                <input class=bottom name=Submit type=submit value="提交">
                                <input class=bottom name=reset type=reset value="重填">
                              </td>
                            </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </form>
                  </table>
                </td>
              </tr>
            </table>
          </td>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
        </tr>
        <tr>
          <td colspan="3"><img src="images/left_kuang_bottom.gif" width="100%" height="4"></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
        <tr>
          <td height="8"></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td colspan="3"><img src="images/left_kuang_top.gif" width="100%" height="4"></td>
        </tr>
        <tr>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
          <td width="100%" height="25" bgcolor="#D1DCE5" align="center">
	[ <a href="../">网站首页</a> ] 
	[ <a href="index.asp">查看留言</a> ] 
	[ <a href="login.asp">管理登录</a> ] 
	[ <a href="logout.asp">注销退出</a> ] 
		  </td>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
        </tr>
        <tr>
          <td colspan="3"><img src="images/left_kuang_bottom.gif" width="100%" height="4"></td>
        </tr>
      </table>
    </td>
    <td width="8" bgcolor="#FFFFFF"></td>
  </tr>
<tr><td><CENTER><br><br><a href="http://www.moon-soft.com/">月光软件站</a>·<a href="http://www.moon-soft.com/help/legal.htm">版权所有</a></CENTER></td></tr>
</table>

</body>
</html>
