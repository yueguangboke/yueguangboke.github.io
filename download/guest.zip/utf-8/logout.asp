<%
	session("user")=""
	session("password")=""
	Response.Cookies("usercookies") = 0
	Response.Cookies("usernamebook")=""
	Response.Cookies("passwordbook")=""

	Response.Redirect "index.asp"
%>