<%@ CODEPAGE=65001 %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->

<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body leftMargin="0" topMargin="0">

<%
dim sql
dim rs
dim seekerrs
dim founduser
dim name
dim companyid
dim userpass
dim errmsg
dim founderr
founderr=false
FoundUser=false
name=trim(request("name"))
password=MD5(replace(trim(Request("password")),"'",""))

set rs=server.createobject("adodb.recordset")
sql="select * from admin where id=1"
rs.open sql,conn,1,1
 if not(rs.bof and rs.eof) then
 if password=rs("userpass") and name=rs("username") then

   '判断更新cookies
   Response.Cookies("usernamebook")=name
   Response.Cookies("passwordbook")=password
   usercookies=request("CookieDate")
   If isnull(usercookies) or usercookies="" Then usercookies="0"
   select case usercookies
   case "0"
      Response.Cookies("usercookies") = usercookies
   case 1
      Response.Cookies("usernamebook").Expires=Date+1
      Response.Cookies("passwordbook").Expires=Date+1
      Response.Cookies("usercookies").Expires=Date+1
      Response.Cookies("usercookies") = usercookies
   case 2
      Response.Cookies("usernamebook").Expires=Date+31
      Response.Cookies("passwordbook").Expires=Date+31
      Response.Cookies("usercookies").Expires=Date+31
      Response.Cookies("usercookies") = usercookies
   case 3
      Response.Cookies("usernamebook").Expires=Date+365
      Response.Cookies("passwordbook").Expires=Date+365
      Response.Cookies("usercookies").Expires=Date+365
      Response.Cookies("usercookies") = usercookies
   end select

   session("user")=name
   session("password")="wpassword"
   response.redirect "admin.asp"
 else
   response.write "<link rel='stylesheet' type='text/css' href='css/style.css'>"
   response.write "<body bgcolor='#ffffff'>" 
   response.write "<script language='javascript'>"
   response.write "alert('你想搞破坏吗~~~');"
   response.write "history.go(-1);" 
   response.write "</script>"
   response.end
end if
end if
rs.close
conn.close
set rs=nothing
set conn=nothing
%>
</body>
</html>
