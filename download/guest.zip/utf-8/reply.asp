<%@ CODEPAGE=65001 %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->
<%
if request.form("txtreply")<>"" then 

 if session("user")<>"admin" then
   Set rs10= Server.CreateObject("ADODB.Recordset")
   sql0="select * from admin where id=1"
   rs10.open sql0,conn,1,3
   admin=rs10("username")
   password=rs10("userpass")
   user=trim(request("username"))
   passwd=MD5(cstr(Request("password")))
   rs10.close
 end if

 if (passwd=password and user=admin) or session("user")="admin" then
   session("user")="admin"
   reply=request("txtreply")
   gbookid=cint(request("gbookid"))
   Set rs= Server.CreateObject("ADODB.Recordset")
   sql="select * from guestbook where gbookid="&gbookid
   rs.open sql,conn,1,3
   rs("reply")=reply
   rs.update
   rs.close
%>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv=refresh content="1; url=index.asp">
<title>回复成功</title><BODY bgcolor="#ffffff"  text="#000000" link="#000080" alink="#800000" vlink="#2f2f4f" marginheight=0 marginwidth=0 topmargin=10 leftmargin=20 rightmargin=0>
<p>　</p><p align="center"><font size="2">Please Wait......</font></p>
<p align="center"><font size="2">回复成功！二秒钟后系统自动返回留言簿页面</font></p>
<%
 else
      response.write "<link rel='stylesheet' type='text/css' href='style/style.css'>"
      response.write "<body bgcolor='#ffffff'>" 
      response.write "<P align=center><font color=#ff0000>Sorry,请输入正确的管理员名字和密码</font>"
	  response.end
 end if

else
%>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>...:::版主留言回复:::...</title>
<style>
<!--
table, td{font:9pt "宋体";color:#999999}
.td{font:9pt "宋体";line-height:150%}
A{ COLOR: #ce0000; TEXT-DECORATION: none }
A:hover{ COLOR: #ce0000; TEXT-DECORATION:underline }
.input{ border-top:1px solid #efefef;border-left:1px solid #efefef;background:#ffffff;color:#ce0000;height:18px; font-style:normal; font-variant:normal; font-weight:normal; font-size:9pt }
.inputaa{ border-top:1px solid #efefef;border-left:1px solid #efefef;background:#ffffff;color:#ce0000; font-style:normal; font-variant:normal; font-weight:normal; font-size:9pt}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<p align="center" class="td"><font color="#FF0000">+ + + + + + 斑 竹 回 复 留 言 + + 
  + + + +</font></p>
<form method="POST" action="reply.asp?gbookid=<%=request("gbookid")%>">
	<% if session("user")<>"admin" then %>
    <table width="300" border="1" cellspacing="0" cellpadding="1" align="center"
      bordercolordark="#ecf5ff" bordercolorlight="#c0c0c0">
        <tr>
          <td><table width="100%" border="0" cellspacing="1" cellpadding="1">
            <tr>
                      <td width="33%" align="right" height="30">用户名：</td>
              <td width="67%">
              <input name="username" maxlength="20" class="input" size="20">
               </td>
            </tr>
            <tr>
                      <td width="33%" align="right" height="30">密 码：</td>
              <td width="67%">
              <input type="password" name="password" maxlength="16" class="input"
              size="20">
               </td>
            </tr>
            <tr>
              <td colspan="2" height="15"></td>
            </tr>
          </table>
          </td>
        </tr>
       </table>
	   <% end if %>
	   <p align="center">
    <textarea rows="6" name="txtreply" cols="40" class="inputaa"></textarea>
    <br>
  <input type="submit" value="确定" name="B1">&nbsp;<input type="reset" value="重写" name="B2"></p>
</form>
<p align="center">　</p>

</body>

</html>

<% end if %>