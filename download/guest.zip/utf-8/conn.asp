<%
'    on error resume next 
	dim conn
	dim dbpath
   	set conn=server.createobject("adodb.connection")
	DBPath = Server.MapPath("#database.mdb")
'	conn.Open "driver={Microsoft Access Driver (*.mdb)};dbq=" & DBPath
	conn.Open "Provider=Microsoft.JET.OLEDB.4.0;User Id=Admin;Data Source = " & DBPath
%>