<%
	session("user")=""
	session("password")=""
	Response.Cookies("usercookies") = 0
	Response.Cookies("username")=""
	Response.Cookies("password")=""

	Response.Redirect "index.asp"
%>