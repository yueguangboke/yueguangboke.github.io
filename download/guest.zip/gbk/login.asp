<%@ Language=VBScript %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->

<html>

<head>
<title>...::ϵͳ��½:::.</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<style>
<!--
table,td{font:9pt "����";color:#999999}
.td{font:9pt "����";line-height:150%}
A{ COLOR: #ce0000; TEXT-DECORATION: none }
A:hover{ COLOR: #ce0000; TEXT-DECORATION:underline }
.input{ border-top:1 solid #efefef;border-left:1 solid #efefef;background:#ffffff;font:9pt;color:#ce0000;height:18px }
select{background-color: #FFFFFF;border: 1px dotted #999999;font-size: 9pt;color: #999999;}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<div align="center"><center>
    <p><font color="#FF0000">+ + + + + + �� �� Ա �� ½ + + + + + +</font></p>
    <table width="400" border="0" cellspacing="2" cellpadding="1" align="center">
      <tr> 
        <td align="center">[<a href="/">��������ҳ��</a>] 
          [<a href=index.asp>���鿴���ԡ�</a>]</td>
      </tr>
    </table>

    
    <table border="0" cellspacing="1" width="90%">
  <tr>
    <td>��<form method="post" action="chklogin.asp">
      <table width="45%" border="1" cellspacing="0" cellpadding="1" align="center"
      bordercolordark="#ecf5ff" bordercolorlight="#c0c0c0">
        <tr>
          <td><table width="100%" border="0" cellspacing="1" cellpadding="1">
            <tr>
              <td width="33%" align="right" height="30">�û�����</td>
              <td width="67%">
              <input name="name" maxlength="20" class="input" size="20">
              </td>
            </tr>
            <tr>
              <td width="33%" align="right" height="30">�� �룺</td>
              <td width="67%">
              <input type="password" name="password" maxlength="16" class="input" size="20">
              </td>
            </tr>
            <tr>
              <td width="33%" align="right" height="30">����ʱ�䣺</td>
              <td width="67%">
              <select name=CookieDate>
			  <option selected value=0>������</option>
			  <option value=1>����һ��</option>
			  <option value=2>����һ��</option>
			  <option value=3>����һ��</option>
			  </select>
              </td>
            </tr>
            <tr>
              <td colspan="2" height="15"></td>
            </tr>
          </table>
          </td>
        </tr>
        <tr align="center">
          <td height="40">
          <input type="submit" name="submit" value="ȷ��" class="input"> &nbsp; 
          <input type="reset" name="reset" value="��д" class="input">
          </td>
        </tr>
      </table>
    </form>
    </td>
  </tr>
</table>
</center></div>
</body>
</html>
