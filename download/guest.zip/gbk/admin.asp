<%@ Language=VBScript %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<%
if session("password")<>"wpassword" then
response.redirect "login.asp"
response.end
end if

response.buffer=true
Response.Expires=0
Set rs9 = Server.CreateObject("ADODB.Recordset")
sql9 ="SELECT * From about Order By id DESC"
RS9.open sql9,Conn,3,3
%>

<html>
<head>
<title><%=rs9("name")%>ϵͳ����</title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<link rel="stylesheet" href="style/style.css">
<style>
<!--
body {  font-size: 9pt}
table {  font-size: 9pt}
-->
</style>
</head>

<body bgcolor="#FFFFFF" background="point.gif"> 

<form method="post" action="adminsave.asp" name="system">
  <table width="500" border="1" cellspacing="1" cellpadding="0" align="center" bordercolorlight="#CCCCFF" bordercolordark="#FFFFFF">
    <tr bgcolor="#FFCC00"> 
      <td colspan="2"> 
        <div align="center"><a href=index.asp><%=rs9("name")%></a> ϵͳ���ģ�</div>
      </td>
    </tr>
    <tr> 
      <td colspan="2"> 
        <div align="right"><font color="#FF9999"> </font></div>
      </td>
    </tr>
    <tr> 
      <td width="102">������ҳ</td>
      <td> 
        <input type="text" name="homepage" size="50" value="<%=rs9("home")%>">
      </td>
    </tr>
    <tr> 
      <td width="102">���ƣ�</td>
      <td> 
        <input type="text" name="name" size="50" value="<%=rs9("name")%>">
      </td>
    </tr>
    <tr> 
      <td width="102">LOGO��</td>
      <td> 
        <input type="text" name="logo" size="50" value="<%=rs9("logo")%>">
      </td>
    </tr>
    <tr> 
      <td width="102">��վ��ַ��</td>
      <td> 
        <input type="text" name="logourl" size="50" value="<%=rs9("logourl")%>">
      </td>
    </tr>

    <tr> 
      <td width="102">ÿҳ��ʾ��¼����</td>
      <td> 
        <input type="text" name="num" size="50" value="<%=rs9("num")%>">
      </td>
    </tr>
    <tr> 
      <td width="102">����ʹ�õ��ǳƣ�</td>
      <td> 
        <input type="text" name="badnicks" size="50" value="<%=rs9("badnicks")%>">
      </td>
    </tr>
    <tr> 
      <td width="102">����ʹ�õ��ַ���</td>
      <td> 
        <input type="text" name="badwords" size="50" value="<%=rs9("badwords")%>">
      </td>
    </tr>
	<tr> 
      <td width="102">����߿�</td>
      <td> 
        <input type="text" name="bian" size="20" value="<%=rs9("bian")%>">
      </td>
    </tr>
    <tr> 
      <td width="102">����ɫ�</td>
      <td> 
        <input type="text" name="bgs" size="20" value="<%=rs9("bgs")%>">
        <font color=<%=rs9("bgs")%>><b>��ǰ����ɫ</b></font></td>
    </tr>
    <tr> 
      <td width="102">����ɫǳ��</td>
      <td> 
        <input type="text" name="bgss" size="30" value="<%=rs9("bgss")%>">
        <font color=<%=rs9("bgss")%>><b>��ǰ����ɫ</b></font> </td>
    </tr>
    <tr> 
      <td width="102">����ɫ��ǳ��</td>
      <td> 
        <input type="text" name="bgsrc" size="30" value="<%=rs9("bgsrc")%>">
        <font color=<%=rs9("bgsrc")%>><b>��ǰ����ɫ</b></font> </td>
    </tr>
<%rs9.close%>
    <tr> 
<%
Set rs8 = Server.CreateObject("ADODB.Recordset")
sql8 ="SELECT * From admin Order By id DESC"
RS8.open sql8,Conn,3,3
%>
      <td width="102">���û���</td>
      <td> 
        <input type="text" name="username" size="30" value="<%=rs8("username")%>">
      </td>
    </tr>
    <tr> 
      <td width="102">������</td>
      <td> 
        <input type="text" name="userpass" size="30" value="">
      </td>
    </tr>
    <tr> 
      <td colspan="2"> 
        <div align="center"> 
          <input type="submit" name="Submit" value="�� �� �� ��">
          <input type="reset" name="reset" value="ȡ �� �� ��">
          <input type="button" name="admin" value="�� �� �� ��" onClick="javascript:document.location.href='index.asp';">
          <input type="button" name="admin" value="ע �� �� ��" onClick="javascript:document.location.href='logout.asp';">
        </div>
      </td>
    </tr>
    <tr> 
      <td colspan="2">�� �� �� �ͣ��� 
        <input type="text" name="textfield" size="10" value="#e9b03a">
        ǳ 
        <input type="text" name="textfield2" size="10" value="#f3d192">
        ��ǳ 
        <input type="text" name="textfield3" size="10" value="#fbf0dd">
      </td>
    </tr>
    <tr> 
      <td colspan="2">�� �� �� ���� 
        <input type="text" name="textfield4" size="10" value="#7285cf">
        ǳ 
        <input type="text" name="textfield22" size="10" value="#a5b0e0">
        ��ǳ 
        <input type="text" name="textfield32" size="10" value="#e9ebf8">
      </td>
    </tr>
    <tr> 
      <td colspan="2">�� �� �� �磺�� 
        <input type="text" name="textfield5" size="10" value="#7285cf">
        ǳ 
        <input type="text" name="textfield23" size="10" value="#dfdfdf">
        ��ǳ 
        <input type="text" name="textfield33" size="10" value="#f2f2f2">
      </td>
    </tr>
    <tr> 
      <td colspan="2">�� �� �� �䣺�� 
        <input type="text" name="textfield6" size="10" value="#ffc4e2">
        ǳ 
        <input type="text" name="textfield24" size="10" value="#ffd0e9">
        ��ǳ 
        <input type="text" name="textfield34" size="10" value="#ffeef7">
      </td>
    </tr>
  </table>
</form>
</body>
</html>
<%rs8.close%>