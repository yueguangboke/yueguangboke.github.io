<%@ Language=VBScript %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->
<% 
if session("password")<>"wpassword" then
response.redirect "login.asp"
response.end
end if

name=request("name")
logo=request("logo")
logourl=request("logourl")
num=request("num")
badnicks=request("badnicks")
badwords=request("badwords")
bgs=request("bgs")
bgss=request("bgss")
homepage=request("homepage")
bgsrc=request("bgsrc")
biankk=request("bian")
username=request("username")
userpass=MD5(Server.Htmlencode(Request("userpass")))

If logo="" then
response.write "SORRY <br>"
response.write "��������������д�ˣ�"
response.end
end if

if len(logourl)>=100 then
response.write("<table width=300 border=0 cellspacing=0 cellpadding=0 align=center>")
response.write("<tr><td>���������վ·��̫���ˣ���</td></tr>")
response.write(" <tr><td>������<a href=vbscript:history.back()>��ȥ����</a>������</td></tr>")
response.write("</table>")
response.end
end if

sql="update about set name='"&name&"',logourl='"&logourl&"',logo='"&logo&"',bian='"&biankk&"',num="&num&",badnicks='"&badnicks&"',badwords='"&badwords&"',bgs='"&bgs&"',bgss='"&bgss&"',home='"&homepage&"',bgsrc='"&bgsrc&"'"
conn.execute(sql)
if Request("userpass")<>"" then
sql2="update admin set username='"&username&"',userpass='"&userpass&"'"
conn.execute(sql2)
end if

%>
<html>
<head>
<title>OK</title>
<meta http-equiv=refresh content="1; url=admin.asp">
<BODY bgcolor="#ffffff"  text="#000000" link="#000080" alink="#800000" vlink="#2f2f4f" marginheight=0 marginwidth=0 topmargin=10 leftmargin=20 rightmargin=0>
<BR>
<p align="center">�Ѿ��ɹ����ӵ����ݿ⣡</p>
<p align="center">�����Ӻ�ϵͳ�Զ����ص�����ҳ��</p>
</body></html>


