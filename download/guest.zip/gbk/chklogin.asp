<%@ Language=VBScript %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->

<%
dim sql
dim rs
dim seekerrs
dim founduser
dim name
dim companyid
dim userpass
dim errmsg
dim founderr
founderr=false
FoundUser=false
name=trim(request("name"))
password=MD5(replace(trim(Request("password")),"'",""))

set rs=server.createobject("adodb.recordset")
sql="select * from admin where id=1"
rs.open sql,conn,1,1
 if not(rs.bof and rs.eof) then
 if password=rs("userpass") and name=rs("username") then

   '�жϸ���cookies
   Response.Cookies("username")=name
   Response.Cookies("password")=password
   usercookies=request("CookieDate")
   If isnull(usercookies) or usercookies="" Then usercookies="0"
   select case usercookies
   case "0"
      Response.Cookies("usercookies") = usercookies
   case 1
      Response.Cookies("username").Expires=Date+1
      Response.Cookies("password").Expires=Date+1
      Response.Cookies("usercookies").Expires=Date+1
      Response.Cookies("usercookies") = usercookies
   case 2
      Response.Cookies("username").Expires=Date+31
      Response.Cookies("password").Expires=Date+31
      Response.Cookies("usercookies").Expires=Date+31
      Response.Cookies("usercookies") = usercookies
   case 3
      Response.Cookies("username").Expires=Date+365
      Response.Cookies("password").Expires=Date+365
      Response.Cookies("usercookies").Expires=Date+365
      Response.Cookies("usercookies") = usercookies
   end select

   session("user")=name
   session("password")="wpassword"
   response.redirect "admin.asp"
 else
   response.write "<link rel='stylesheet' type='text/css' href='css/style.css'>"
   response.write "<body bgcolor='#ffffff'>" 
   response.write "<script language='javascript'>"
   response.write "alert('������ƻ���~~~');"
   response.write "history.go(-1);" 
   response.write "</script>"
   response.end
end if
end if
rs.close
conn.close
set rs=nothing
set conn=nothing
%>


