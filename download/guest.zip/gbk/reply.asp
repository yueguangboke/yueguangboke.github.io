<%@ Language=VBScript %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->
<%
if request.form("txtreply")<>"" then 

 if session("user")<>"admin" then
   Set rs10= Server.CreateObject("ADODB.Recordset")
   sql0="select * from admin where id=1"
   rs10.open sql0,conn,1,3
   admin=rs10("username")
   password=rs10("userpass")
   user=trim(request("username"))
   passwd=MD5(cstr(Request("password")))
   rs10.close
 end if

 if (passwd=password and user=admin) or session("user")="admin" then
   session("user")="admin"
   reply=request("txtreply")
   gbookid=cint(request("gbookid"))
   Set rs= Server.CreateObject("ADODB.Recordset")
   sql="select * from guestbook where gbookid="&gbookid
   rs.open sql,conn,1,3
   rs("reply")=reply
   rs.update
   rs.close
%>
<meta http-equiv=refresh content="1; url=index.asp">
<title>�ظ��ɹ�</title><BODY bgcolor="#ffffff"  text="#000000" link="#000080" alink="#800000" vlink="#2f2f4f" marginheight=0 marginwidth=0 topmargin=10 leftmargin=20 rightmargin=0>
<p>��</p><p align="center"><font size="2">Please Wait......</font></p>
<p align="center"><font size="2">�ظ��ɹ��������Ӻ�ϵͳ�Զ��������Բ�ҳ��</font></p>
<%
 else
      response.write "<link rel='stylesheet' type='text/css' href='style/style.css'>"
      response.write "<body bgcolor='#ffffff'>" 
      response.write "<P align=center><font color=#ff0000>Sorry,��������ȷ�Ĺ���Ա���ֺ�����</font>"
	  response.end
 end if

else
%>

<html>

<head>
<meta http-equiv="Content-Language" content="zh-cn">
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<title>...:::�������Իظ�:::...</title>
<style>
<!--
table, td{font:9pt "����";color:#999999}
.td{font:9pt "����";line-height:150%}
A{ COLOR: #ce0000; TEXT-DECORATION: none }
A:hover{ COLOR: #ce0000; TEXT-DECORATION:underline }
.input{ border-top:1px solid #efefef;border-left:1px solid #efefef;background:#ffffff;color:#ce0000;height:18px; font-style:normal; font-variant:normal; font-weight:normal; font-size:9pt }
.inputaa{ border-top:1px solid #efefef;border-left:1px solid #efefef;background:#ffffff;color:#ce0000; font-style:normal; font-variant:normal; font-weight:normal; font-size:9pt}
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<p align="center" class="td"><font color="#FF0000">+ + + + + + �� �� �� �� �� �� + + 
  + + + +</font></p>
<form method="POST" action="reply.asp?gbookid=<%=request("gbookid")%>">
	<% if session("user")<>"admin" then %>
    <table width="300" border="1" cellspacing="0" cellpadding="1" align="center"
      bordercolordark="#ecf5ff" bordercolorlight="#c0c0c0">
        <tr>
          <td><table width="100%" border="0" cellspacing="1" cellpadding="1">
            <tr>
                      <td width="33%" align="right" height="30">�û�����</td>
              <td width="67%">
              <input name="username" maxlength="20" class="input" size="20">
               </td>
            </tr>
            <tr>
                      <td width="33%" align="right" height="30">�� �룺</td>
              <td width="67%">
              <input type="password" name="password" maxlength="16" class="input"
              size="20">
               </td>
            </tr>
            <tr>
              <td colspan="2" height="15"></td>
            </tr>
          </table>
          </td>
        </tr>
       </table>
	   <% end if %>
	   <p align="center">
    <textarea rows="6" name="txtreply" cols="40" class="inputaa"></textarea>
    <br>
  <input type="submit" value="ȷ��" name="B1">&nbsp;<input type="reset" value="��д" name="B2"></p>
</form>
<p align="center">��</p>

</body>

</html>

<% end if %>