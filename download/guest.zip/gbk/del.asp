<%@ Language=VBScript %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<!--#INCLUDE FILE="md5.asp" -->
<%
 if session("user")<>"admin" then
   Set rs10= Server.CreateObject("ADODB.Recordset")
   sql0="select * from admin where id=1"
   rs10.open sql0,conn,1,3
   admin=rs10("username")
   password=rs10("userpass")
   user=trim(request("username"))
   passwd=MD5(cstr(Request("password")))
   rs10.close
 end if

 if (passwd=password and user=admin) or session("user")="admin" then
   session("user")="admin"
   gbookid=cint(request("gbookid"))
   dim sql 
   sql="delete from guestbook where gbookid="&gbookid
   conn.execute sql
   response.redirect "index.asp"
 else
%>
<html>

<head>
<meta http-equiv="Content-Language" content="zh-cn">
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>...::ɾ������:::...</title>
<style>
<!--
table,td{font:9pt "����";color:#999999}
.td{font:9pt "����";line-height:150%}
A{ COLOR: #ce0000; TEXT-DECORATION: none }
A:hover{ COLOR: #ce0000; TEXT-DECORATION:underline }
.input{ border-top:1 solid #efefef;border-left:1 solid #efefef;background:#ffffff;font:9pt;color:#ce0000;height:18px }
-->
</style>
</head>

<body bgcolor="#FFFFFF">
<p align="center"><font color="#FF0000">+ + + + + + �� �� Ա ɾ �� �� �� + + + + + +</font></p>
<form method="POST" action="del.asp?gbookid=<%=request("gbookid")%>">
    <table width="300" border="1" cellspacing="0" cellpadding="1" align="center"
      bordercolordark="#ecf5ff" bordercolorlight="#c0c0c0">
		<tr>
          <td><table width="100%" border="0" cellspacing="1" cellpadding="1">
		  	<% if session("user")<>"admin" then %>
            <tr>
                      <td width="33%" align="right" height="30">�û�����</td>
              <td width="67%">
              <input name="username" maxlength="20" class="input" size="20">
               </td>
            </tr>
            <tr>
                      <td width="33%" align="right" height="30">�� �룺</td>
              <td width="67%">
              <input type="password" name="password" maxlength="16" class="input"
              size="20">
               </td>
            </tr>
			<% end if %>
            <tr>
              <td colspan="2" height="15" align=center><input type="submit" value="ȷ��" name="B1">&nbsp;<input type="reset" value="��д" name="B2"></td>
            </tr>
          </table>
          </td>
        </tr>
       </table>
</form>

</body>

</html>
<% end if %>
