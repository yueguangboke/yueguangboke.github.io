<%@ Language=VBScript %>
<!--#INCLUDE FILE="conn.asp" -->
<!--#INCLUDE FILE="config.asp" -->
<%

response.buffer=true
Response.Expires=0

usercookies=Request.Cookies("usercookies")
if not session("password")<>"" then
if usercookies > "0" then
	name=Request.Cookies("username")
	password=Request.Cookies("password")
	sql="select * from admin where id=1"
	set rs8=conn.execute(sql)
	if not(rs8.bof and rs8.eof) then
		if password=rs8("userpass") and name=rs8("username") then
		   session("user")=name
		   session("password")="wpassword"
		end if
	end if
end if
end if

Set rs9 = Server.CreateObject("ADODB.Recordset")
sql9 ="SELECT * From about Order By id DESC"
RS9.open sql9,Conn,3,3
mypagesize=cint(rs9("num"))  'ÿҳ��ʾ������
badnicks=rs9("badnicks")
badwords=rs9("badwords")

Set rs = Server.CreateObject("ADODB.Recordset")
sql = "Select * FROM guestbook Order By dateandtime Desc"
rs.open sql,conn,1,1

IF not IsNumeric(Request("page")) Or IsEmpty(Request("page")) Then
page=1
Else
Page=Int(Abs(Request("page")))
End if
rs.pagesize = mypagesize
total  = rs.RecordCount
rs.absolutepage = page

if request("test")="insert" then

'У�����жϿ�ʼ
If Request("checkcode")="" Then
	MessageBox "�����,�뷵��������֤�밡~~~"
    response.end
Elseif Session("CheckCode")="" then
	MessageBox "�뷵�غ���ˢ�µ�¼ҳ�������������ȷ����Ϣ~~~"
    response.end
ElseIf Cstr(Session("CheckCode"))<>Cstr(Trim(Request("checkcode"))) Then
	MessageBox "���������֤���ϵͳ�����Ĳ�һ�£����������롣~~~"
    response.end
End if
'У�����жϽ���

'��ֹ�������Թ��ܿ�ʼ
dim ComeUrl,cUrl
ComeUrl=lcase(trim(request.ServerVariables("HTTP_REFERER")))
if ComeUrl="" then
'	MessageBox "������Ϣ���Բ���Ϊ��ϵͳ��ȫ��������ֱ�������ַ���ʱ�ҳ�档"
'	response.end
else
	cUrl=trim("http://" & Request.ServerVariables("SERVER_NAME"))
	if mid(ComeUrl,len(cUrl)+1,1)=":" then
		cUrl=cUrl & ":" & Request.ServerVariables("SERVER_PORT")
	end if
	cUrl=lcase(cUrl & request.ServerVariables("SCRIPT_NAME"))
	if lcase(left(ComeUrl,instrrev(ComeUrl,"/")))<>lcase(left(cUrl,instrrev(cUrl,"/"))) then
'		MessageBox "������Ϣ�����Ա����������Թ����Ѿ��򿪣���ֹ���ⲿ���ӵ�ַ�ύ���ԡ�"
'		response.end
	end if
end if
'��ֹ�������Թ��ܽ���

txtname=left(request("txtname"),30)
txtemail=left(request("txtemail"),30)
txthomepage=left(request("txthomepage"),50)
txtoicq=left(request("txtoicq"),10)
if request.form("xxx")="" then
pic="images/1.gif"
else
pic=request.form("xxx")
end if
txtcome=left(request("txtcome"),20)
sex=request("sex")
txtcontent=left(request("txtcontent"),500)

'���ù�ˮ����
posttime=60
if cint(posttime)<>0 then
	if not isnull(session("posttime")) or cint(posttime)>0 then
		if DateDiff("s",session("posttime"),Now())<cint(posttime) then
		MessageBox "������Ϣ�����Ա�����ˮ�����Ѿ��򿪣�����"&posttime&"���ڲ����ظ����ԡ�"
		response.end
		end if
	end if
end if

if txtemail<>"" and IsValidEmail(txtemail)=false then
	MessageBox "������Ϣ���ʼ���ַ��д��������ȷ������ʼ���ַ��" 
	response.end
end if

if txtname="" then
	MessageBox "�����,�������ݰ�~~~"
    response.end
end if

if txtcontent=""  then
	MessageBox "������Ϣ��������������֣�"
    response.end
end if

if txtemail="" then txtemail="��������!"
if txtoicq="" then txtoicq="������Ҳ��˵!"
if txtcome="" then txtcome="����!"
if txthomepage="" or txthomepage="http://" then txthomepage="��û����!"

function MessageBox(strOutput)
		response.write "<script language='javascript'>" & VbCRlf
	    response.write "alert('" & strOutput & "');" & VbCrlf
	    response.write "history.go(-1);" & vbCrlf
	    response.write "</script>" & VbCRLF
	    response.end
end function

function IsValidEmail(email)
 dim names, name, i, c
 IsValidEmail = true
 names = Split(email, "@")
 if UBound(names) <> 1 then
   IsValidEmail = false
   exit function
 end if
 for each name in names
   if Len(name) <= 0 then
     IsValidEmail = false
     exit function
   end if
   for i = 1 to Len(name)
     c = Lcase(Mid(name, i, 1))
     if InStr("abcdefghijklmnopqrstuvwxyz_-.", c) <= 0 and not IsNumeric(c) then
       IsValidEmail = false
       exit function
     end if
   next
   if Left(name, 1) = "." or Right(name, 1) = "." then
      IsValidEmail = false
      exit function
   end if
 next
 if InStr(names(1), ".") <= 0 then
   IsValidEmail = false
   exit function
 end if
 i = Len(names(1)) - InStrRev(names(1), ".")
 if i <> 2 and i <> 3 then
   IsValidEmail = false
   exit function
 end if
 if InStr(email, "..") > 0 then
   IsValidEmail = false
 end if

end function

function IsLongStr(str)
dim longStrs,longstr
IsLongStr = true
longStrs = Split(str,"")
for each longStr in longStrs
	if len(longstr) > 50 then
	ISlongStr = false
	end if
next
end function

txtname=server.htmlencode(txtname)
txtcome=server.htmlencode(txtcome)
txtemail=server.htmlencode(txtemail)
txtcome=server.htmlencode(txtcome)
txthomepage=txthomepage
txtoicq=server.htmlencode(txtoicq)
txtcontent=server.htmlencode(txtcontent)
reply = "û��"

'ʹ�������ǳ�
check_name=txtname
badnicks=split(badnicks,",")
for i = 0 to ubound(badnicks)
	if instr(check_name,badnicks(i))>0 then
		MessageBox "������Ϣ����ʹ�������ε��ǳơ�"
		response.end
		exit for
	end if
next

'ʹ�������ַ�
check_content=txtcontent
badwords=split(badwords,",")
for i = 0 to ubound(badwords)
	if instr(check_content,badwords(i))>0 then
		MessageBox "������Ϣ����ʹ���˷Ƿ����������ݡ�"
		response.end
		exit for
	end if
next

Set rs= Server.CreateObject("ADODB.Recordset")
sql="select * from guestbook"
rs.open sql,conn,3,2
rs.addnew

		rs("name")=txtname
		rs("email")=txtemail
       	rs("homepage")=txthomepage
        rs("come")=txtcome
		rs("oicq")=txtoicq
		rs("content")=txtcontent
		rs("head")=pic
		rs("dateandtime")=now()
		rs("reply")=reply
		rs("ip")=Request.ServerVariables("REMOTE_HOST")
		rs("sex")=cint(sex)
		rs.update
		rs.close
		if cint(posttime)<>0 then
			session("posttime")=now()
		end if
		response.redirect "index.asp"
end if
%>
<HTML>
<HEAD>
<TITLE><%=rs9("name")%></TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta name="Keywords" CONTENT="<%=rs9("name")%>,���Բ�">
<meta name="description" content="<%=rs9("name")%>�����Բ�">
<style>
<!--
BODY{ SCROLLBAR-FACE-COLOR: #cccccc; FONT-SIZE: 10px; SCROLLBAR-HIGHLIGHT-COLOR: #cccccc; SCROLLBAR-SHADOW-COLOR: #cccccc; COLOR: #333333; SCROLLBAR-3DLIGHT-COLOR: #ffffff; LINE-HEIGHT: normal; SCROLLBAR-ARROW-COLOR: #000000; SCROLLBAR-TRACK-COLOR: #efefef; FONT-STYLE: normal; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; SCROLLBAR-DARKSHADOW-COLOR: #999999 }
table, td{ font:9pt "����" }
A { COLOR: #000000; TEXT-DECORATION: none }
A:hover { COLOR: #000000; TEXT-DECORATION:none }
.td{ font-family:"����";font-size:9pt;line-height:150% }
.big{ font:14.8px "����" }
input{ height:18px;border-left:1px ridge #ffffff;border-top:1px ridge #ffffff;border-bottom:1px ridge;border-right:1px ridge;background-color:#efefef;font-style:normal; font-variant:normal; font-weight:normal; font-size:9pt; font-family:���� }
select{background-color: #FFFFFF;border: 1px dotted #999999;font-size: 9pt;color: #999999;}
-->
</style>
<script language=javascript>
<!--
function check()
{
if(document.login.txtname.value=="")
{alert("��������Ϊ��^_^");return false}
if(document.login.txtcontent.value=="")
{alert("�������ݲ���Ϊ��^_^");return false}
if(document.login.checkcode.value=="")
{alert("У���벻��Ϊ��^_^");return false}
}
-->
</script>
<LINK HREF="../images/text.css" TYPE="text/css" REL="stylesheet">
</head>

<body leftMargin="0" topMargin="0">
<center><script src="../top.js"></script></center>

<BR>
<table width="540" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td background="images/bg_left.gif" valign="top" width="100%">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td colspan="3"><img src="images/left_kuang_top.gif" width="100%" height="4"></td>
        </tr>
        <tr>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
          <td width="100%" valign="top">
            <table width="100%" border="0" cellspacing="0" cellpadding="5" height="100%">
              <tr>
                <td class="td" valign="top">
                  <table align=center border=0 cellpadding=0 cellspacing=1 bgcolor="<%=rs9("bian")%>" width=100%>
                    <tbody>
                    <%
dim i
i=1
do while not rs.eof  and mypagesize>0
id=rs("gbookid")
name=rs("name")
email=rs("email")
homepage=rs("homepage")
oicq=rs("oicq")
head=rs("head")
content=rs("content")
content=Autolink(content)
dateandtime=rs("dateandtime")
reply=rs("reply")
reply=addlink(reply)
sex=rs("sex")
%>
                    <tr>
                      <td bgcolor="<%=rs9("bgss")%>" rowspan=2 width=80>
                        <center>
                          <% if rs9("textonly")=0 then %><img border=0 src="<%=head%>"> <br><% end if %>
                          <br>
                          <%=name%>
                        </center>
                      </td>
                      <td bgcolor="<%=rs9("bgss")%>" height=20>
                        <table border=0 cellpadding=0 cellspacing=0 width="99%">
                          <tbody>
                          <tr>
                            <td valign=bottom width="50%"><font class=cha2>�������ڣ�<%=dateandtime%></font>
                            </td>
                            <td align=right width="50%"><img align=absBottom alt=<%=name%>����<%=rs("come")%> border=0
            height=16 src="images/icon_profile.gif" width=16> <a
            <% if right(email,1)<>"!" then %> href="mailto:<%=email%>" <% end if %> title="<%=name%>���ʼ���ַ�ǣ�<%=email%>"><img align=absBottom
            border=0 height=16 src="images/icon_email.gif" width=16></a> <a
            title="<%=name%>��QQ���ǣ�<%=oicq%>"><img align=absBottom
            border=0 height=16 src="images/icon_editor_oicq.gif" width=16></a>
                              <a
            <% if right(homepage,1)<>"!" then %> href="<%=homepage%>" <% end if %> target=_blank title="<%=name%>����ҳ��ַ�ǣ�<%=homepage%>"><img
            align=absBottom border=0 height=16 src="images/icon_homepage.gif"
            width=16></a> <img align=absBottom alt=<%=name%>��IP��ַ�ǣ�<%=rs("ip")%>
            height=16 src="images/icon_ip.gif" width=16>
<% if session("password")="wpassword" then %>
							  <a href="reply.asp?gbookid=<%=id%>" title="ֻ�а������лظ���Ȩ��"><img  align=absBottom src="images/icon_reply_topic.gif" width="16" height="16" border="0"></a>
                              <a href="del.asp?gbookid=<%=id%>" title="ֻ�а�������ɾ�����Ե�Ȩ��"><img  align=absBottom src="images/icon_delete_reply.gif" width="16" height="16" border="0"></a>
<% end if %>
                            </td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    <tr>
                      <td bgcolor="<%=rs9("bgsrc")%>" height=80>
                        <table border=0 cellpadding=0 cellspacing=2 width="100%">
                          <tbody>
                          <tr>
                            <td><%=content%></td>
                          </tr>
                          <tr>
                            <td>
                              <%if reply<>"û��" then%>
                              <br>
                              <hr size=1>
                              <font color="#000000">�����ظ���</font><font color=#B08291><%=reply%></font>
                              <%end if%>
                            </td>
                          </tr>
                          </tbody>
                        </table>
                      </td>
                    </tr>
                    <%
mypagesize=mypagesize-1
i=i+1
rs.movenext
loop
%>
                    <tr>
                      <td bgcolor="<%=rs9("bgs")%>" colspan=2 height=18 valign=bottom>
                        <div align=center>
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">
                            <form name="form2" method="post" action="index.asp">
                              <tr>
                                <td align="right" height="22"><font color="#000000">��<b><%=rs.pagecount%></b>ҳ<b><%=total%></b>������
                                  ��ǰ��<b><%=page%></b>ҳ <a href="?page=1" class="black">��ҳ</a>
                                  <%if page>1 then%>
                                  <a href=?page=<%=page-1%> class="black">��һҳ</a>
                                  <%else%>
                                  ��һҳ
                                  <%end if%>
                                  <%if page<rs.pagecount   then%>
                                  <a href=?page=<%=page+1%> class="black">��һҳ</a>
                                  <%else%>
                                  ��һҳ
                                  <%end if%>
                                  <a href=?page=<%=rs.pagecount%> class="black">βҳ</a>
								  <!--
                                  <select name="page" class="bottom">
                                    <%for i=1 to rs.pagecount%>
                                    <option value=<%=i%>
									<%
					  if i=page then
					  response.write" selected"
					  end if
					  %>
									><%=i%></option>
                                    <%next%>
                                  </select>
                                  <input type="submit" name="Submit22" value="ת��" class="bottom">
                                  </font>
								  -->
								  <BR>

                                    <%for i=1 to rs.pagecount
       if i=page then
          response.write "[<font color=#666666><b>"+Cstr(i)+"</b></font>] "
	   else
	      response.write "[<b>"+"<a href='?page="+cstr(i)+"'>"+Cstr(i)+"</a></b>]   "
	   end if
                                    next%>
								  
								  </td>
                              </tr>
                            </form>
                          </table>
                        </div>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                  <table align=center border=0 cellpadding=2 cellspacing=1 bgcolor="#D1DCE5" width=100%>
                    <form action=index.asp method=post name=login onSubmit="return check()">
                      <input type=hidden name=test value=insert>
                      <tr>
                        <td bgcolor="#FFFFFF" valign=top>
                          <table border=0 cellpadding=0 cellspacing=2>
                            <tbody>
                            <tr>
                              <td align=right width=20><img height=16 src="images/icon_edit_topic.gif" width=16></td>
                              <td width=33><font class=cha2>����<a name="bottom"></a></font></td>
                              <td>
                                <input maxlength=20 name=txtname size=20>
                                <input name=username type=hidden>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img border=0 height=16 src="images/icon_email.gif" width=16></td>
                              <td width=33><font class=cha2>Email</font></td>
                              <td>
                                <input maxlength=100 name=txtemail size=20>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img height=16 src="images/icon_homepage.gif" width=16></td>
                              <td width=33><font class=cha2>��ҳ</font></td>
                              <td>
                                <input maxlength=100 name=txthomepage size=20 value=http://>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img border=0 height=16 src="images/icon_editor_oicq.gif" width=16></td>
                              <td width=33><font class=cha2>oicq</font></td>
                              <td>
                                <input maxlength=9 name=txtoicq size=20>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img height=16 src="images/icon_profile.gif" width=16></td>
                              <td width=33><font class=cha2>����</font></td>
                              <td>
                                <select name=txtcome size=1>
                                  <option selected value=����һ��>��ѡ��..
                                  <option value=����>����
                                  <option value=�㶫>�㶫
                                  <option value=�Ϻ�>�Ϻ�
                                  <option value=�½�>�½�
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=�ӱ�>�ӱ�
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=ɽ��>ɽ��
                                  <option value=�㽭>�㽭
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=������>������
                                  <option value=ɽ��>ɽ��
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=�Ĵ�>�Ĵ�
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=���>���
                                  <option value=����>����
                                  <option value=�ຣ>�ຣ
                                  <option value=����>����
                                  <option value=̨��>̨��
                                  <option value=���>���
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=ŷ��>ŷ��
                                  <option value=����>����
                                  <option value=����>����
                                  <option value=��������>��������</option>
                                </select>
                              </td>
                            </tr>
                            <tr>
                              <td align=right><img height=16 src="images/icon_delete_reply.gif" width=16></td>
                              <td width=33><font class=cha2>У��</font></td>
                              <td>
                                <input maxlength=10 name=checkcode size=8> <img src="checkcode.asp" align="absbottom">
                              </td>
                            </tr>
                            </tbody>
                          </table>
                        </td>
                        <td bgcolor="#FFFFFF" valign=top align="center">
                          <table border=0 cellpadding=1 cellspacing=0>
                            <tbody>
                            <tr>
                              <td colspan=3 height="100">
                                <textarea class=editbox2 cols=34 name=txtcontent rows=5 type="text"></textarea>
                              </td>
                            </tr>
                            <tr>
                              <td><% if rs9("textonly")=0 then %>
							  <img alt=����������� height=32 id=face src="images/1.gif" width=32></td>
                              <td>ͷ��</td>
                              <td>
                                <select name=xxx
            onChange="document.images['face'].src=options[selectedIndex].value;" size=1>
                                  <option selected value=images/1.gif select>ͷ��1
                                  <option value=images/2.gif>ͷ��2
                                  <option value=images/3.gif>ͷ��3
                                  <option value=images/4.gif>ͷ��4
                                  <option value=images/5.gif>ͷ��5
                                  <option value=images/6.gif>ͷ��6
                                  <option value=images/7.gif>ͷ��7
                                  <option value=images/8.gif>ͷ��8
                                  <option value=images/9.gif>ͷ��9
                                  </option>
                                </select>
								<% end if %>
                                <input class=bottom name=Submit type=submit value="�ύ">
                                <input class=bottom name=reset type=reset value="����">
                              </td>
                            </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </form>
                  </table>
                </td>
              </tr>
            </table>
          </td>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
        </tr>
        <tr>
          <td colspan="3"><img src="images/left_kuang_bottom.gif" width="100%" height="4"></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF">
        <tr>
          <td height="8"></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td colspan="3"><img src="images/left_kuang_top.gif" width="100%" height="4"></td>
        </tr>
        <tr>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
          <td width="100%" height="25" bgcolor="#D1DCE5" align="center">
	[ <a href="../">��վ��ҳ</a> ] 
	[ <a href="index.asp">�鿴����</a> ] 
	[ <a href="login.asp">������¼</a> ] 
	[ <a href="logout.asp">ע���˳�</a> ] 
		  </td>
          <td width="4" background="images/left_kuang_left.gif"><img src="images/left_kuang_left.gif" width="4" height="2"></td>
        </tr>
        <tr>
          <td colspan="3"><img src="images/left_kuang_bottom.gif" width="100%" height="4"></td>
        </tr>
      </table>
    </td>
    <td width="8" bgcolor="#FFFFFF"></td>
  </tr>
<tr><td><CENTER><br><br><a href="http://www.moon-soft.com/">�¹�����վ</a>��<a href="http://www.moon-soft.com/help/legal.htm">��Ȩ����</a></CENTER></td></tr>
</table>

</body>
</html>
