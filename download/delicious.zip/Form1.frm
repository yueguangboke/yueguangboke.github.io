VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "DEL.ICIO.US���ݵ�������"
   ClientHeight    =   2730
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3315
   LinkTopic       =   "Form1"
   ScaleHeight     =   2730
   ScaleWidth      =   3315
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdToXML 
      Caption         =   "ת����RSS�ļ�"
      Height          =   375
      Left            =   840
      TabIndex        =   2
      Top             =   1680
      Width           =   1695
   End
   Begin VB.CommandButton cmdToTXT 
      Caption         =   "ת�����ı����ݿ�"
      Height          =   375
      Left            =   840
      TabIndex        =   0
      Top             =   480
      Width           =   1695
   End
   Begin VB.CommandButton cmdTodata 
      Caption         =   "ת����������"
      Height          =   375
      Left            =   840
      TabIndex        =   1
      Top             =   1080
      Width           =   1695
   End
   Begin VB.Label Label1 
      Caption         =   "�������¹ⲩ�� www.williamlong.info"
      Height          =   255
      Left            =   360
      TabIndex        =   3
      Top             =   2400
      Width           =   2895
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'///////////////////////////////////////////////////////////////////////////////
'//
'// ��������:    DEL.ICIO.US ���ݵ�������
'// ��    ��:    William Long
'// ��Ȩ����:    �¹ⲩ��
'// ����֧��:    http://www.williamlong.info
'// ����汾:    1.0
'// ��Ԫ����:
'// ��    ע:    2008-5-7
'///////////////////////////////////////////////////////////////////////////////


' ���ڸ�ʽת��
Function getMyDate(ByVal strdate As String) As String
getMyDate = CStr(Year(strdate)) + "-" + Right("0" + CStr(Month(strdate)), 2) + "-" + Right("0" + CStr(Day(strdate)), 2) + " " + Right("0" + CStr(Hour(strdate)), 2) + ":" + Right("0" + CStr(Minute(strdate)), 2) + ":" + Right("0" + CStr(Second(strdate)), 2)
End Function

Function UDate(oldDate)
  UDate = DateDiff("s", "01/01/1970 00:00:00", oldDate)
End Function

Function unUDate(intTimeStamp)
  unUDate = DateAdd("s", intTimeStamp, "01/01/1970 00:00:00")
End Function

' ��ȡUTF-8��ʽ�ļ�
Function LoadFromFile(strFullName, strCharset)
    Dim objStream
    Set objStream = CreateObject("ADODB.Stream")
    With objStream
    .Type = 2
    .Mode = 3
    .Open
    .Charset = strCharset
    .Position = objStream.Size
    .LoadFromFile strFullName
    LoadFromFile = .ReadText
    .Close
    End With
    Set objStream = Nothing
End Function
'*********************************************************


Private Sub cmdTodata_Click()
    Dim strOut As String

    connstr = "Provider=Microsoft.JET.OLEDB.4.0;User Id=Admin;Data Source = " & App.Path & "\db2.mdb "
    Set conn = CreateObject("ADODB.CONNECTION")
    conn.Open connstr

    Set rs = CreateObject("ADODB.RECORDSET")   'get last file
    rs.Open "select * from bookmarks order by id desc ", conn, 3, 3
    While Not rs.EOF
        rs("lastvisit") = unUDate(rs("lastvisit"))
        rs("adddate") = unUDate(rs("adddate"))
        rs.movenext
    Wend
    rs.Close
    MsgBox "ת���ɹ�!"
End Sub

Private Sub cmdToTXT_Click()
    Dim strOut As String
    strOut = LoadFromFile(App.Path & "\delicious.html", "utf-8")
    strOut = Replace(strOut, "<!DOCTYPE NETSCAPE-Bookmark-file-1>" & vbLf & "<META HTTP-EQUIV=""Content-Type"" CONTENT=""text/html; charset=UTF-8"">" & vbLf & "<!-- This is an automatically generated file." & vbLf & "It will be read and overwritten." & vbLf & "Do Not Edit! -->" & vbLf & "<TITLE>Bookmarks</TITLE>" & vbLf & "<H1>Bookmarks</H1>" & vbLf, "")
    strOut = Replace(strOut, "<DL><p>", "")
    strOut = Replace(strOut, "</DL><p>", "")
    strOut = Replace(strOut, "<DT><A HREF=""", "")
    strOut = Replace(strOut, """ LAST_VISIT=""", vbTab)
    strOut = Replace(strOut, """ ADD_DATE=""", vbTab)
    strOut = Replace(strOut, """ TAGS=""", vbTab)
    strOut = Replace(strOut, """>", vbTab)
    strOut = Replace(strOut, "</A>" & vbLf & "<DD>", vbTab)

    Dim fsoout, txtoutfile
    Set fsoout = CreateObject("Scripting.FileSystemObject")
    Set txtoutfile = fsoout.CreateTextFile(App.Path & "\delicious.txt", True)
    txtoutfile.Write (strOut) ' д��һ�С�
    txtoutfile.Close
    
    MsgBox "ת���ɹ���"
    
End Sub

Private Sub cmdToXML_Click()

    Dim strOut As String

    connstr = "Provider=Microsoft.JET.OLEDB.4.0;User Id=Admin;Data Source = " & App.Path & "\db2.mdb "
    Set conn = CreateObject("ADODB.CONNECTION")
    conn.Open connstr
    
    strOut = "<?xml version=""1.0"" encoding=""GB2312""?><rss version=""2.0""><channel><title>blog</title><description></description><pubDate>Sat, 26 Jan 2008 14:54:04 +0000</pubDate>  <language>en</language>"

    Set rs = CreateObject("ADODB.RECORDSET")   'get last file
    rs.Open "select * from bookmarks order by adddate ", conn, 1, 1
    While Not rs.EOF
        strOut = strOut + "<item rdf:about=""" + rs("url") + """>" + vbLfLf
        strOut = strOut + " <title>" + rs("title") + "</title>" + vbLfLf
        strOut = strOut + " <link>" + rs("url") + "</link>" + vbLfLf
        strOut = strOut + " <description>" + rs("description") + "</description>" + vbLfLf
        strOut = strOut + " <dc:creator>williamlong</dc:creator>" + vbLfLf
        strOut = strOut + " <dc:date>" + Replace(getMyDate(CStr(rs("adddate"))), " ", "T") + "Z</dc:date>" + vbLfLf
        strOut = strOut + " <dc:subject>" + rs("tag") + "</dc:subject>" + vbLfLf
        strOut = strOut + "</item>" + vbLfLf
        rs.movenext
    Wend
    
    strOut = strOut + "</channel></rss>"
    
    strOut = Replace(strOut, "&", "&amp;")
    MsgBox "ת���ɹ���"
    
    Dim fsoout, txtoutfile
    Set fsoout = CreateObject("Scripting.FileSystemObject")
    Set txtoutfile = fsoout.CreateTextFile(App.Path & "\DB2.xml", True)
    txtoutfile.Write (strOut) ' д��һ�С�
    txtoutfile.Close

End Sub
