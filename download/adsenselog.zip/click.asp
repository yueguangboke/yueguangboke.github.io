<%
'***************************************************************************
'*                                                                         *
'*     File:        Adsense�����׷������                                *
'*                                                                         *
'*     Author:      William Long                                           *
'*                                                                         *
'*     Website:     www.williamlong.info                                   *
'*                                                                         *
'***************************************************************************

db="db.mdb"  'Ĭ�����ݿ��ַ��Ϊ�˰�ȫ�ԣ����޸�������ݺ�Ĭ�����ݿ�����
Set conn = Server.CreateObject("ADODB.Connection")
connstr="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Server.MapPath(db)
conn.Open connstr

action=Request.QueryString("action")
choseip=Request.QueryString("choseip")
search=Request.QueryString("search")

if action<>"" then
url=Request.QueryString("url")
corp=Request.QueryString("corp")
times=now()
ip=Request.ServerVariables("HTTP_X_FORWARDED_FOR")
If ip = "" Then 
	ip = request.ServerVariables("REMOTE_ADDR") 
end if
sql="INSERT INTO db (ip,timer,url,corp) values ('"&ip&"','"&times&"','"&url&"','"&corp&"')"
conn.Execute (sql)
set sql=nothing
end if

if session("user")<>"OK" then
	response.end
end if

if search="yes" then
years=CInt(Request.Form("year"))
months=CInt(Request.Form("month"))
days=CInt(Request.Form("day"))
set rs=server.CreateObject("ADODB.RecordSet")
rs.Source="select * from db Order By id DESC"
rs.Open rs.Source,conn,1,1

%>
<head>
<title>2006��<%=months%>��<%=days%>��Google Adsense�����ͳ�Ʊ�</title>
</head>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b><%=years%>��<%=months%>��<%=days%>��Google Adsense�����ͳ�Ʊ�</b>
<table border="1" width="71%" height="67">
	<tr>
		<td width="31" align="center" height="17"><span style="font-size: 9pt">���</span></td>
		<td width="250" height="17" align="center"><span style="font-size: 9pt">���ҳ��</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">������</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">ʱ��</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">IP</span></td>
	</tr>
<%
i=1
do while not rs.eof
if  year(rs(3))=years and month(rs(3))=months and day(rs(3))=days then

%>
	<tr>
		<td width="31" align="center"><span style="font-size: 9pt"><%=i%></span></td>
		<td width="250"><a title="��˴�ǰ��:<%=rs(1)%>" target="_blank" href="<%=rs(1)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=mid(rs(1),1,50)%></font></span></a></td>
		<td><a title="��˴�ǰ��:<%=rs(2)%>" target="_blank" href="http://<%=rs(2)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=rs(2)%></font></span></a></td>
		<td ><span style="font-size: 9pt"><%=rs(3)%></span></td>
		<td><a title="��˴��鿴IP:<%=rs(4)%>��ȫ�����" target="_blank" href="click.asp?choseip=<%=rs(4)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=rs(4)%></font></span></a></td>
	</tr>
<%
end if
rs.movenext
i=i+1
loop
rs.close
set rs=nothing
else

if choseip<>"" then
set rs=server.CreateObject("ADODB.RecordSet")
rs.Source="select * from db where ip='"&choseip&"' Order By id DESC"
rs.Open rs.Source,conn,1,1

%>
<head>
<title>Google Adsense���IP:<%=choseip%>���ͳ�Ʊ�</title>
</head>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Google Adsense���IP:<%=choseip%>���ͳ�Ʊ�</b>
<table border="1" width="71%" height="67">
	<tr>
		<td width="31" align="center" height="17"><span style="font-size: 9pt">���</span></td>
		<td width="250" height="17" align="center"><span style="font-size: 9pt">���ҳ��</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">������</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">ʱ��</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">IP</span></td>
	</tr>
<%
i=1
do while not rs.eof
%>

	<tr>
		<td width="31" align="center"><span style="font-size: 9pt"><%=i%></span></td>
		<td width="250"><a title="��˴�ǰ��:<%=rs(1)%>" target="_blank" href="<%=rs(1)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=mid(rs(1),1,50)%></font></span></a></td>
		<td><a title="��˴�ǰ��:<%=rs(2)%>" target="_blank" href="http://<%=rs(2)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=rs(2)%></font></span></a></td>
		<td ><span style="font-size: 9pt"><%=rs(3)%></span></td>
		<td><span style="font-size: 9pt"><%=rs(4)%></span></td>
	</tr>
<%
rs.movenext
i=i+1
loop
rs.close
set rs=nothing
set i=nothing
else
set rs=server.CreateObject("ADODB.RecordSet")
rs.Source="select * from db Order By id DESC"
rs.Open rs.Source,conn,1,1

%>
<head>
<title>Google Adsense�����ͳ�Ʊ�</title>
</head>

<table border="0" width="71%">
	<tr>
		<td valign="top">
		<b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Google Adsense�����ͳ�Ʊ�</b></td>
		<td width="177" valign="top"><form method="POST" action="click.asp?search=yes" target="_blank">
    <select size="1" name="year" value="<%=year(now())%>">
	<option selected><%=year(now())%></option>
	<option>2006</option>
	<option>2007</option>
	<option>2008</option>
	</select><select size="1" name="month" value="<%=month(now())%>">
	<option selected><%=month(now())%></option>
	<option>1</option>
	<option>2</option>
	<option>3</option>
	<option>4</option>
	<option>5</option>
	<option>6</option>
	<option>7</option>
	<option>8</option>
	<option>9</option>
	<option>10</option>
	<option>11</option>
	<option>12</option>
	</select><select size="1" name="day" value="<%=day(now())%>">
	<option selected><%=day(now())%></option>
	<option>1</option>
	<option>2</option>
	<option>3</option>
	<option>4</option>
	<option>5</option>
	<option>6</option>
	<option>7</option>
	<option>8</option>
	<option>9</option>
	<option>10</option>
	<option>11</option>
	<option>12</option>
	<option>13</option>
	<option>14</option>
	<option>15</option>
	<option>16</option>
	<option>17</option>
	<option>18</option>
	<option>19</option>
	<option>20</option>
	<option>21</option>
	<option>22</option>
	<option>23</option>
	<option>24</option>
	<option>25</option>
	<option>26</option>
	<option>27</option>
	<option>28</option>
	<option>29</option>
	<option>30</option>
	<option>31</option>
	</select><input value="��ѯ" type="submit" name="Submit2"></form></td></tr>
</table>

<table border="1" width="71%" height="67">
	<tr>
		<td width="31" align="center" height="17"><span style="font-size: 9pt">���</span></td>
		<td width="250" height="17" align="center"><span style="font-size: 9pt">���ҳ��</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">������</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">ʱ��</span></td>
		<td height="17" align="center"><span style="font-size: 9pt">IP</span></td>
	</tr>
<%
i=1
do while not rs.eof
if  year(rs(3))=year(now()) and month(rs(3))=month(now()) and day(rs(3))=day(now()) then
%>

	<tr>
		<td width="31" align="center"><span style="font-size: 9pt"><%=i%></span></td>
		<td width="250"><a title="��˴�ǰ��:<%=rs(1)%>" target="_blank" href="<%=rs(1)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=mid(rs(1),1,50)%></font></span></a></td>
		<td><a title="��˴�ǰ��:<%=rs(2)%>" target="_blank" href="http://<%=rs(2)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=rs(2)%></font></span></a></td>
		<td><span style="font-size: 9pt"><%=rs(3)%></span></td>
		<td><a title="��˴��鿴IP:<%=rs(4)%>��ȫ�����" target="_blank" href="click.asp?choseip=<%=rs(4)%>"><span style="font-size: 9pt" style="text-decoration: none">
		<font color="#000000"><%=rs(4)%></font></span></a></td>
	</tr>
<%
end if
rs.movenext
i=i+1
loop
rs.close
set rs=nothing
set i=nothing
end if
end if
%>
</table>
