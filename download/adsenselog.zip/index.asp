<%
'***************************************************************************
'*                                                                         *
'*     File:        Adsense�����׷������                                *
'*                                                                         *
'*     Author:      William Long                                           *
'*                                                                         *
'*     Website:     www.williamlong.info                                   *
'*                                                                         *
'***************************************************************************
 
 userpassword="admin888"   ' �޸�Ĭ�������ڴ��޸�

If session("user")<>"" Then
	response.redirect "click.asp"
ElseIf request("password")<>"" Then 
	If request("password")=userpassword Then 
		session("user")="OK"
		response.redirect "click.asp"
	Else
		response.write "Wrong Password."
	End if
Else
%>

<form method=post action="index.asp">
<input type="password" name="password"><input type="submit">
</form>

<%
End if

%>