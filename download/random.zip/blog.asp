<%

Function WriteBlogFile

	'���ݿ�·��
	connstr="DBQ=c:\wwwroot\DATA\zblog.mdb;DefaultDir=;DRIVER={Microsoft Access Driver (*.mdb)};" 
	'����ļ���ַ
    txtfilename = "c:\wwwroot\blog.js"
	'ģ���ļ���ַ
	templetfile = "c:\wwwroot\template\blog.htm"
	'��������Ŀ¼
	patharchives="http://www.williamlong.info/post/"
	'del.icio.us��ժ·��
	deliciousurl="http://del.icio.us/feeds/js/williamlong?count=10"
	
	intCutLen=22

    If DateDiff("n", GetFileDate (txtfilename), Now) <= 20 Then 'ÿ��20��������һ��Ŀ���ļ�
		Exit Function
		response.end
	End if

    set conn=server.createobject("ADODB.CONNECTION")
    conn.open connstr

    Set fso = CreateObject("Scripting.FileSystemObject")
    Set txtfile = fso.OpenTextFile(templetfile, 1)
    txttemplet = txtfile.ReadAll
    txtfile.Close

    Set rs = CreateObject("ADODB.RECORDSET")

	'��������
	strSql = "select top 20 log_ID,log_Title from blog_Article order by log_ID desc "
    rs.Open strSql, conn, 1, 1
    strnew = " "
    strnew2 = " "
	lastid=rs("log_ID")
    For icount=1 To 20
		If icount<11 Then 
	        strnew = strnew & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
		else
	        strnew2 = strnew2 & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
		End if
        rs.movenext
    next
    rs.Close

	'�������
	randomize
	tempid=CStr(CInt(Rnd*CInt(lastid))+20)
	strSql = "select top 20 log_ID,log_Title from blog_Article where log_ID>" & tempid & " order by log_ID "
    rs.Open strSql, conn, 1, 1
    strtemp = " "
    strtemp2 = " "
    For icount=1 To 20
		If icount<11 Then 
	        strtemp = strtemp & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
		else
	        strtemp2 = strtemp2 & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
		End if
        rs.movenext
    next
    rs.Close

	'������������  ʵ���Ǳ����ȵ�����
	strSql = "select top 10 log_ID,log_Title from blog_Article WHERE (log_ID>0) AND  (log_PostTime>Now()-90) ORDER BY log_CommNums DESC "
    rs.Open strSql, conn, 1, 1
    strcommonth = " "
    For icount=1 To 10
        strcommonth = strcommonth & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
        rs.movenext
    next
    rs.Close
    
	'������������
	strSql = "select top 10 log_ID,log_Title from blog_Article WHERE (log_ID>0) AND  (log_PostTime>Now()-360) ORDER BY log_CommNums DESC "
    rs.Open strSql, conn, 1, 1
    strcomyear = " "
    For icount=1 To 10
        strcomyear = strcomyear & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
        rs.movenext
    next
    rs.Close

	'��������
	strSql = "select top 10 log_ID,log_Title from blog_Article WHERE (log_ID>0) AND  (log_PostTime>Now()-30) ORDER BY log_ViewNums DESC "
    rs.Open strSql, conn, 1, 1
    strtopmonth = " "
    While Not rs.EOF
        strtopmonth = strtopmonth & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
        rs.movenext
    Wend
    rs.Close
    
	'��������
	strSql = "select top 10 log_ID,log_Title from blog_Article WHERE (log_ID>0) AND  (log_PostTime>Now()-360) ORDER BY log_ViewNums DESC "
    rs.Open strSql, conn, 1, 1
    strtopyear = " "
    While Not rs.EOF
        strtopyear = strtopyear & "<tr class=""data""><td align=""left"">��<a href=""" & patharchives & CStr(rs("log_ID")) & ".html"">" & cutStr(rs("log_Title"),intCutLen) & "</a></td>" 
        rs.movenext
    Wend
    rs.Close

	'ģ���ļ��滻
	txtout = txttemplet
    txtout = Replace(txtout, "<!--��������-->", strnew)
    txtout = Replace(txtout, "<!--��������2-->", strnew2)
    txtout = Replace(txtout, "<!--�������-->", strtemp)
    txtout = Replace(txtout, "<!--�������2-->", strtemp2)
    txtout = Replace(txtout, "<!--������������-->", strcommonth)
    txtout = Replace(txtout, "<!--������������-->", strcomyear)
    txtout = Replace(txtout, "<!--��������-->", strtopmonth)
    txtout = Replace(txtout, "<!--��������-->", strtopyear)
  
    txtout = Replace(txtout, Chr(10), "")
    txtout = Replace(txtout, Chr(13), "")
    txtout = "document.write ('" & txtout & "');"

	'д�����ļ�
'    Set fso = CreateObject("Scripting.FileSystemObject")
'    Set txtfile = fso.OpenTextFile(txtfilename, 2, True)
'    txtfile.Write txtout
'    txtfile.Close

	Dim objStream
	Set objStream = Server.CreateObject("ADODB.Stream")
	With objStream
	.Type = 2
	.Mode = 3
	.Open
'	.Charset = "gb2312"
	.Charset = "utf-8"
	.Position = objStream.Size
	.WriteText = txtout
	.SaveToFile txtfilename,2
	.Close
	End With
	Set objStream = Nothing


End Function

Function cutStr(str,strlen)
    dim i,l,t,c
    l=len(str)
    t=0
    for i=1 to l
    c=Abs(Asc(Mid(str,i,1)))
    if c=1 then
    t=t+2
    else
    t=t+1
    end if
    if t>=strlen then
    cutStr=left(str,i)&".."
    exit for
    else
    cutStr=str
    end if
    next
End Function

Function GetFileDate(filespec)
    Set fs = CreateObject("Scripting.FileSystemObject")
    If fs.FileExists(filespec) Then
		Set f = fs.GetFile(filespec)
		GetFileDate = f.DateLastModified
	    Set f=Nothing
	Else
		GetFileDate="2005-11-11 11:11:11"
	End if
    Set fs=Nothing 
End Function 

Function GetURL(url)
Set Retrieval = Server.CreateObject("Microsoft.XMLHTTP")
With Retrieval
.Open "GET", url, False, "", ""
.Send
GetURL = .ResponseText
End With
Set Retrieval = Nothing
End Function

Function WriteDeliciousFile

	'����ļ���ַ
    txtfilename = "c:\wwwroot\link.js"

    If DateDiff("n", GetFileDate (txtfilename), Now) <=60 Then 'ÿ��60��������һ��Ŀ���ļ�
		Exit Function
		response.end
	End if

    txtout = GetURL (deliciousurl)

	'д�����ļ�
	Dim objStream
	Set objStream = Server.CreateObject("ADODB.Stream")
	With objStream
	.Type = 2
	.Mode = 3
	.Open
'	.Charset = "gb2312"
	.Charset = "utf-8"
	.Position = objStream.Size
	.WriteText = txtout
	.SaveToFile txtfilename,2
	.Close
	End With
	Set objStream = Nothing


End Function

WriteBlogFile  ' �������ļ�JS

'WriteDeliciousFile   '�����ժJS�ļ�

%>