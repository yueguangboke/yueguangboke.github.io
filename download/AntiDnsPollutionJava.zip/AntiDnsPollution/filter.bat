@echo off
java lehui99.at.gmail.DnsResponseFilter
pause
