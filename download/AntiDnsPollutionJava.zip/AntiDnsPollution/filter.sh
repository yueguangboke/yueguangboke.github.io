#!/bin/sh

java lehui99.at.gmail.DnsResponseFilter