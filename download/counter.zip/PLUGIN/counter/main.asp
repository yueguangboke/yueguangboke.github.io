<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog(http://www.rainbowsoft.org)
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    生成静态HTML的分类目录的程序
'// 最后修改：   2006-1-16
'// 最后版本:    1.5
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../c_function.asp" -->
<!-- #include file="../../c_system_lib.asp" -->
<!-- #include file="../../c_system_base.asp" -->
<!-- #include file="../../c_system_event.asp" -->
<%

'*********************************************************
' 目的：    All Category ReBuild
'*********************************************************
Function MakeCounter()

	Dim objRS
	Dim fso, TxtFile,i,j,id

	Set objRS=objConn.Execute("select [log_ID],[log_ViewNums] from [blog_Article] ")

	While Not objRS.eof
		id=CStr(objRS("log_ID"))
		i=objRS("log_ViewNums")
		response.write id
		response.write "..<br>"
		Set fso = CreateObject("Scripting.FileSystemObject")
		If fso.FileExists(BlogPath & "/cache/" & id & ".htm") Then
		'读取缓存计数器
			Set TxtFile=fso.opentextfile(BlogPath & "/cache/" & id & ".htm")
			j=CLng(TxtFile.readline)
			TxtFile.Close
			If j>i then
				response.write "..Update.. " & CStr(i) & " => " & CStr(j) & " ..<br>"
				objConn.Execute("update [blog_Article] set [log_ViewNums] = " & CStr(j) & " where [log_ID] = " & id & " ")
			End if
		End if
		Set fso=Nothing
		objRS.MoveNext
	Wend
	objRS.Close

	Set objRS=Nothing
	response.write "<br>Update Completed."

	MakeCounter=True

End Function
'*********************************************************


Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6) 

MakeCounter

%>

<script language="javascript">
//    alert ("生成成功.");
//	document.location.href="javascript:history.go(-1)"
</script>

<% 
Call System_Terminate()

If Err.Number<>0 then
	Call ShowError(0)
End If
'********************************************************
%>