<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'//              Z-Blog
'// 作    者:    朱煊(zx.asd)
'// 版权所有:    RainbowSoft Studio
'// 技术支持:    rainbowsoft@163.com
'// 程序名称:    
'// 程序版本:    
'// 单元名称:    c_count_js.asp
'// 开始时间:    2005.05.06
'// 最后修改:    
'// 备    注:    辅助计数页
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="c_option.asp" -->
<!-- #include file="c_function.asp" -->
<!-- #include file="c_system_lib.asp" -->
<!-- #include file="c_system_base.asp" -->
<%
Call System_Initialize()

Dim i,j

i=Request.QueryString("id")

Call CheckParameter(i,"int",0)

If i>0 Then

	Dim fso, TxtFile
	Dim objRS

	Set fso = CreateObject("Scripting.FileSystemObject")
	If fso.FileExists(BlogPath & "/cache/" & CStr(i) & ".htm") Then
		'读取缓存计数器
		Set TxtFile=fso.opentextfile(BlogPath & "/cache/" & CStr(i) & ".htm")
		j=TxtFile.readline
		TxtFile.Close
	Else
		Set objRS=objConn.Execute("SELECT [log_ViewNums] FROM [blog_Article] WHERE [log_ID] =" & CStr(i))
		If (Not objRS.bof) And (Not objRS.eof) Then
			j=objRS("log_ViewNums")
		End If
		objConn.Execute("UPDATE [blog_Article] SET [log_ViewNums]=[log_ViewNums] + 1 WHERE [log_ID] =" & CStr(i))
		Set objRS=Nothing
	End If

	'更新缓存计数器
	Set TxtFile=fso.createtextfile(BlogPath & "/cache/" & CStr(i) & ".htm")
	TxtFile.write CStr(j+1)
	TxtFile.close
	Set fso=Nothing

	Response.Clear
	Response.Write "document.write(""" & " | 点击:" & j & """);"
	Response.End

End If

Call System_Terminate()

If Err.Number<>0 then
	Call ShowError(0)
End If
%>