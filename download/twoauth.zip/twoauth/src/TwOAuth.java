import java.io.*;
import java.net.*;
import java.util.*;

import org.scribe.http.*;
import org.scribe.oauth.*;

public class TwOAuth
{

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException
	{
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("proxy.sdc.ubisoft.org", 3128));
		BufferedReader stdinRd = new BufferedReader(new InputStreamReader(System.in));
		Properties tp = new Properties();
		tp.load(TwOAuth.class.getResourceAsStream("/twitter.properties"));
		Scribe sb = new Scribe(tp);
		Token tk = sb.getRequestToken(proxy);
		System.out.println(tk);
		System.out.println("Please visit https://api.twitter.com/oauth/authorize?oauth_token=" + tk.getToken() + " and get the token and verifier, then input the token:");
		tk = new Token(stdinRd.readLine(), tk.getSecret());
		System.out.println("And please input the verifier:");
		tk = sb.getAccessToken(tk, stdinRd.readLine(), proxy);
		System.out.println(tk);
		Request req = new Request(Request.Verb.GET, "https://api.twitter.com/statuses/user_timeline.xml");
		sb.signRequest(req, tk);
		Response resp = req.send(proxy);
		System.out.println(resp.getBody());
		System.out.println("====================================");
		req = new Request(Request.Verb.POST, "https://api.twitter.com/statuses/update.xml");
		req.addBodyParameter("status", "����Test");
		sb.signRequest(req, tk);
		resp = req.send(proxy);
		System.out.println(resp.getBody());
	}

}
