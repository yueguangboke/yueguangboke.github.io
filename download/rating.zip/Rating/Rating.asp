<%
'///////////////////////////////////////////////////////////////////////////////
'// ���Ӧ��:    Z-Blog 1.8�����ϵİ汾
'// �������:    williamlong(http://www.williamlong.info)
'// ��    ע:    ����ͶƱ���
'// ����޸ģ�   2008-9-18
'// ���汾:    
'///////////////////////////////////////////////////////////////////////////////

Dim ID,Score,IP

ID=Clng(Request.Querystring("ID"))
Score=Clng(Request.Querystring("S"))
If Score<1 Then Score=1
If Score>5 Then Score=5
IP=getIP()

Dim strDbPath,Conn,RS
strDbPath = Server.MapPath("Rating.mdb")		'�ؼ������ݿ���
Set Conn = Server.CreateObject("ADODB.Connection")
Conn.Open "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strDbPath
Set Rs = Server.CreateObject("ADODB.RecordSet")
Rs.Open "select * from [Score] Where [ID]=" & ID, Conn, 1, 3
If Rs.Eof Then
	Rs.AddNew
	Rs("ID")=ID
	Rs("Score")=Score
	Rs("Rnumber")=1
	Rs("IP")=IP & ","
	Rs.update
	Response.Write("ok")
	Call CacheScore()
ElseIf InStr(Rs("IP"),IP & ",")>0 Then
	Response.Write("already")
ElseIf InStr(Rs("IP"),IP & ",")=0 Then
	RS("Score")=(Rs("Score")*Rs("Rnumber")+Score)/(Rs("Rnumber")+1)
	Rs("Rnumber")=Rs("Rnumber")+1
	Rs("IP")=Rs("IP") & IP & ","
	Rs.update
	Response.Write("ok")
	Call CacheScore()
Else
	Response.Write("error")
End If

Rs.Close()
Set Rs=Nothing
Conn.Close()
Set Conn=Nothing


Function getIP() 
	Dim strIPAddr 
	If Request.ServerVariables("HTTP_X_FORWARDED_FOR") = "" OR InStr(Request.ServerVariables("HTTP_X_FORWARDED_FOR"), "unknown") > 0 Then 
		strIPAddr = Request.ServerVariables("REMOTE_ADDR") 
	ElseIf InStr(Request.ServerVariables("HTTP_X_FORWARDED_FOR"), ",") > 0 Then 
		strIPAddr = Mid(Request.ServerVariables("HTTP_X_FORWARDED_FOR"), 1, InStr(Request.ServerVariables("HTTP_X_FORWARDED_FOR"), ",")-1) 
	ElseIf InStr(Request.ServerVariables("HTTP_X_FORWARDED_FOR"), ";") > 0 Then 
		strIPAddr = Mid(Request.ServerVariables("HTTP_X_FORWARDED_FOR"), 1, InStr(Request.ServerVariables("HTTP_X_FORWARDED_FOR"), ";")-1) 
	Else 
		strIPAddr = Request.ServerVariables("HTTP_X_FORWARDED_FOR") 
	End If 
	getIP = Trim(Mid(strIPAddr, 1, 30)) 
End Function

Sub CacheScore()
	Dim CScore
	Set RsC = Server.CreateObject("ADODB.RecordSet")
	RsC.Open "select [ID],[Score],[Rnumber] from [Score] Where [ID]=" & Cstr(ID), Conn, 1, 1
	If Not RsC.Eof Then
		CScore = CStr(RsC("Score")) + "," + CStr(RsC("Rnumber"))
	End if
	RsC.Close()
	Set RsC=Nothing
	Set fso = CreateObject("Scripting.FileSystemObject")
	Set f = fso.OpenTextFile(Server.MapPath("Score" & ID & ".txt"), 2, True)
	f.Write CScore
	f.Close
	set f=Nothing
	set fso=Nothing
End Sub
%>