<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog 1.8及以上的版本
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    文章投票插件
'// 最后修改：   2008-9-18
'// 最后版本:    
'///////////////////////////////////////////////////////////////////////////////

'注册插件
Call RegisterPlugin("Rating","ActivePlugin_Rating")

Function ActivePlugin_Rating()

	Call Add_Filter_Plugin("Filter_Plugin_TArticle_Export_Template","Rating_Single")

End Function

Function Rating_Single(ByRef Ftemplate,ByRef Template_Article_Single,ByRef Template_Article_Multi,ByRef Template_Article_Istop,ByRef Template_Article_Multi_WAP,ByRef Template_Article_Single_WAP)

	Dim strCode
	strCode = "<link rel=""stylesheet"" href=""<#ZC_BLOG_HOST#>PLUGIN/Rating/rating.css"" type=""text/css"" /><div id=""RatingPre""></div><Script language=""javascript"" type=""text/javascript"">var PostID=<#article/id#>;</script><Script language=""javascript"" type=""text/javascript"" src=""<#ZC_BLOG_HOST#>PLUGIN/Rating/Rating.js""></script> "

	Template_Article_Single = Replace(Template_Article_Single,"<#article/content#>","<#article/content#>" & strCode)

End Function

'安装插件
Function InstallPlugin_Rating

	Call SetBlogHint(Empty,Empty,True)
    Call Rating_Database_Rename()          

End Function


'卸载插件
Function UnInstallPlugin_Rating

	Call SetBlogHint(Empty,Empty,True)

End Function   
   
'首次安装数据库改名....   
Function Rating_Database_Rename()   
	Dim fso, f, s, pathnew, ranNum   
	Set fso = CreateObject("Scripting.FileSystemObject")   
	if Not fso.fileexists(BlogPath & "/plugin/Rating/Rating.mdb") then   
		Set f = fso.GetFile(BlogPath & "/plugin/Rating/Rating.md_")   
		f.name="Rating.mdb"
		Set f = Nothing   
    end if   
End Function   

%>