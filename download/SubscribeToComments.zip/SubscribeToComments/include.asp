<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog邮件订阅评论插件Subscribe to Comments
'// 插件制作:    William Long (http://www.williamlong.info/)
'// 备    注:    这是一个鼓励博客的评论者参与评论的插件，当读者发表评论或留言后，如果有新的评论系统就会定时自动将新增加的评论内容发送给该读者的邮箱。
'// 最后修改：   2008-7-31
'// 最后版本:    1.0
'///////////////////////////////////////////////////////////////////////////////

'注册插件
Call RegisterPlugin("SubscribeToComments","ActivePlugin_SubscribeToComments")

Function ActivePlugin_SubscribeToComments()

	Call Add_Filter_Plugin("Filter_Plugin_TArticle_Export_Template","SubscribeToComments_SingleInnerCode")

End Function


'文章块模板代码插入
Function SubscribeToComments_SingleInnerCode(ByRef Ftemplate,ByRef Template_Article_Single,ByRef Template_Article_Multi,ByRef Template_Article_Istop,ByRef Template_Article_Multi_WAP,ByRef Template_Article_Single_WAP)

	Template_Article_Single = Replace(Template_Article_Single,"<#template:article_comment#>","<#template:article_comment#>" & SubscribeToComments_Code)

End Function

Function SubscribeToComments_Code
	Dim innerHtml : innerHtml = ""
	innerHtml = innerHtml & "<!-- 月光评论订阅插件 Subscribe to Comments --> <p>&nbsp;&nbsp;&nbsp;&nbsp;<img src='<#ZC_BLOG_HOST#>PLUGIN/SubscribeToComments/email.gif' border='0' alt='' align='absbottom' /> <a href=""http://www.sendmerss.com/profiles.aspx/<#ZC_BLOG_HOST#>/feed.asp?cmt=<#article/id#>"" rel=""nofollow"" target=""_blank"">将这篇文章的最新评论发送到我的信箱</a></p> <!-- 插件结束 -->"
	SubscribeToComments_Code = innerHtml
End Function

'安装插件
Function InstallPlugin_SubscribeToComments

	Call SetBlogHint(Empty,Empty,True)

End Function

'卸载插件
Function UnInstallPlugin_SubscribeToComments

	Call SetBlogHint(Empty,Empty,True)

End Function
%>