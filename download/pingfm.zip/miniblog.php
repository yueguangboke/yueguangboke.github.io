<?php

require_once 'pingfm.php';
$body   .= "{$_POST["message"]}";

foreach ($twitters as $key) {
	$key->post($body);
}

//replace XXX with your private mail address

if(count($_POST) > 0){ 
  mail("XXX@hellotxt.com", "", $body); 
  mail("XXX@addtodiary.com", $body, ""); 
  mail("XXX@h.hatena.ne.jp", "", $body); 
}
?>