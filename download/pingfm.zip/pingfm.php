<?php

require_once 'class-snoopy.php';
if (!class_exists('Services_JSON')) {
    require_once 'JSON.php';
}

//replace your_accout_name|your_account_password|you_app_key|source_name with your real account name, password, application_key, source name

$twitters["digu"] = new PingFm('http://api.minicloud.com.cn/statuses/update.format', 'content', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["twitter"] = new PingFm('http://twitter.com/statuses/update.json', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["fanfou"] = new PingFm('http://api.fanfou.com/statuses/update.json', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["identica"] = new PingFm('http://identi.ca/api/statuses/update.json', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["koornk"] = new PingFm('http://www.koornk.com/api/update/', 'status', array('origin' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["jiwaide"] = new PingFm('http://api.jiwai.de/statuses/update.json', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["zuosa"] = new PingFm('http://api.zuosa.com/statuses/update.json', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["buboo"] = new PingFm('http://api.buboo.tw/update.json', 'message', array('source_key' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["harufm"] = new PingFm('http://haru.fm/api?format=json&command=write', 'content', array('content' => ''), 'your_account_name', 'your_account_password');
$twitters["missui"] = new PingFm('http://www.missui.com/api/update.php?ext=json', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["missui"]->setEncoding('GB2312');
$twitters["mogo2"] = new PingFm('http://api.mogo2.jp/statuses/update.json', 'status', array('status' => ''), 'your_account_name', 'your_account_password');
$twitters["wassr"] = new PingFm('http://api.wassr.jp/statuses/update.json', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["piyo"] = new PingFm('http://piyo.fc2.com/contents/api/?mode=send&key=you_app_key', 'content', array('pid' => 'your_account_name'), 'your_account_name', 'your_account_password');
$twitters["cotobaco"] = new PingFm('http://cotobaco.com/api/rest/', 'message', array('id' => 'your_account_name', 'key' => 'you_app_key', 'cmd' => 'postMessage', 'open' => 'openmode'), 'your_account_name', 'your_account_password');
$twitters["plazes"] = new PingFm('http://plazes.com/activities.xml', 'status', array('status' => '<activity><plaze_id>your_place_id</plaze_id><status>$1</status></activity>'), 'your_account_name', 'your_account_password', 'xml');
$twitters["mexicodiario"] = new PingFm('http://mexicodiario.com/touch.json.php', 'status', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["blip"] = new PingFm('http://api.blip.pl/updates', 'body', array('source' => 'source_name'), 'your_account_name', 'your_account_password');
$twitters["cirip"] = new PingFm('http://www.cirip.ro/statuses/update.json', 'status', array('status' => ''), 'your_account_name', 'your_account_password');


class PingFm {
    var $json;
    var $snoop;
    var $url;
    var $opts;
    var $statusname;
    var $submit_type;
    var $encoding;
    

    var $snoop_options = array(
        'agent'      => 'PingFM Tools - http://www.codingmill.com/forgotthemilk',
        'version'    => '1.00',
        'client'     => 'PingFM Tools',
        'client-url' => 'http://www.codingmill.com/forgotthemilk',
    );

    var $username;
    var $password;
    
    function setEncoding($encoding ='') {
    	$this->encoding = $encoding;
    }

    function PingFm($url = '', $statusname = '', $opts, $username = '', $password = '', $submit_type = '') {

        $this->url            	   = $url;
        $this->statusname          = $statusname;
        $this->opts            	   = $opts;
        $this->username            = $username;
        $this->password            = $password;
        if(submit_type) {
        	$this->submit_type            = $submit_type;
        }
        
        $this->json = new Services_JSON();
    }

    function init_snoopy($username = '', $password = '') {
        if (is_object($this->snoop) and is_a($this->snoop, 'Snoopy')) {
            return;
        }

        $this->snoop             = &new Snoopy;
        $this->snoop->agent      = $this->snoop_options['agent'];
        $this->snoop->rawheaders = array(
            'X-Twitter-Client'         => $this->snoop_options['client'],
            'X-Twitter-Client-Version' => $this->snoop_options['version'],
            'X-Twitter-Client-URL'     => $this->snoop_options['client-url']
        );
        if($this->submit_type == "xml") {
        	$this->snoop->set_submit_xml();
        }

        if ($username) $this->snoop->user = $username;
        if ($password) $this->snoop->pass = $password;
    }

    function post($text = '') {
        if (empty($this->username) or empty($this->password) or empty($text)) {
            return;
        }

        $this->init_snoopy($this->username, $this->password);
        if($this->encoding) {
        	$text = iconv("UTF-8",$this->encoding,$text);
        }
        if($this->submit_type == "xml") {
        	$this->opts[$this->statusname] = str_replace('$1', $text, $this->opts[$this->statusname]);
        } else {
        	$this->opts[$this->statusname] = $text;
        }
        	
        $this->snoop->submit(
            $this->url,
            $this->opts
        );
        return false;
    }

}