<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'//              Z-Blog
'// 作    者:    朱煊(zx.asd)&(sipo)
'// 版权所有:    RainbowSoft Studio
'// 技术支持:    rainbowsoft@163.com
'// 程序名称:    
'// 程序版本:    
'// 单元名称:    sydication.asp
'// 开始时间:    2006.07.30
'// 最后修改:    
'// 备    注:    
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="c_option.asp" -->
<!-- #include file="function/c_function.asp" -->
<!-- #include file="function/c_function_md5.asp" -->
<!-- #include file="function/c_system_lib.asp" -->
<!-- #include file="function/c_system_base.asp" -->
<!-- #include file="function/c_system_event.asp" -->
<!-- #include file="function/rss_lib.asp" -->
<!-- #include file="function/atom_lib.asp" -->
<%
Call System_Initialize()

Dim strAct
strAct="rss"

'如果不是"接收引用"就要检查非法链接
If (strAct<>"tb") And (strAct<>"search") Then Call CheckReference("")

'权限检查
If Not CheckRights(strAct) Then Call ShowError(6)


'/////////////////////////////////////////////////////////////////////////////////
If Not IsEmpty(Request.QueryString("cate")) Then
	Call ExportRSSbyCate(Request.QueryString("cate"))
ElseIf Not IsEmpty(Request.QueryString("tags")) Then
	Call ExportRSSbyTags(Request.QueryString("tags"))
ElseIf Not IsEmpty(Request.QueryString("user")) Then

ElseIf Not IsEmpty(Request.QueryString("date")) Then

ElseIf Not IsEmpty(Request.QueryString("cmt")) Then
	Call ExportRSSbyCmt(Request.QueryString("cmt"))
Else
	Call RedirectBy301("rss.xml")
End If




'/////////////////////////////////////////////////////////////////////////////////
Function ExportRSSbyCate(CateID)

	Dim Rss2Export
	Dim objArticle

	Set Rss2Export = New TRss2Export

	With Rss2Export

		Dim objRS,CateName,CateIntro

		.TimeZone=ZC_TIME_ZONE

		Set objRS=objConn.Execute("SELECT [cate_ID],[cate_Name],[cate_Intro] from [blog_Category] where cate_ID="&CateID)
		If (Not objRS.bof) And (Not objRS.eof) Then
		CateName=TransferHTML(objRS("cate_Name"),"[html-format]")
		CateIntro=TransferHTML(objRS("cate_Intro"),"[html-format]")
		End If        
		objRS.close
	    Set objRS=Nothing

		.AddChannelAttribute "title",TransferHTML(ZC_BLOG_TITLE,"[html-format]") & " - " & CateName
		.AddChannelAttribute "link",TransferHTML(ZC_BLOG_HOST,"[html-format]")
		.AddChannelAttribute "description",TransferHTML(ZC_BLOG_SUBTITLE,"[html-format]") & " - " & CateIntro
		.AddChannelAttribute "generator","RainbowSoft Studio Z-Blog " & ZC_BLOG_VERSION
		.AddChannelAttribute "language",ZC_BLOG_LANGUAGE
		.AddChannelAttribute "copyright",TransferHTML(ZC_BLOG_COPYRIGHT,"[html-format]")
		.AddChannelAttribute "pubDate",Now

				Dim i

				Set objRS=objConn.Execute("SELECT [log_ID],[log_Tag],[log_CateID],[log_Title],[log_Intro],[log_Content],[log_Level],[log_AuthorID],[log_PostTime],[log_CommNums],[log_ViewNums],[log_TrackBackNums],[log_Url],[log_Istop] FROM [blog_Article] WHERE ([log_ID]>0) AND ([log_Level]>2) AND ([log_CateID]="&CateID&") ORDER BY [log_PostTime] DESC")

				If (Not objRS.bof) And (Not objRS.eof) Then
				For i=1 to ZC_RSS2_COUNT
					Set objArticle=New TArticle
					If objArticle.LoadInfoByArray(Array(objRS("log_ID"),objRS("log_Tag"),objRS("log_CateID"),objRS("log_Title"),objRS("log_Intro"),objRS("log_Content"),objRS("log_Level"),objRS("log_AuthorID"),objRS("log_PostTime"),objRS("log_CommNums"),objRS("log_ViewNums"),objRS("log_TrackBackNums"),objRS("log_Url"),objRS("log_Istop"))) Then

						If ZC_RSS_EXPORT_WHOLE Then
						.AddItem objArticle.HtmlTitle,Users(objArticle.AuthorID).Email & " (" & Users(objArticle.AuthorID).Name & ")",objArticle.HtmlUrl,objArticle.PostTime,objArticle.HtmlUrl,objArticle.HtmlContent,Categorys(objArticle.CateID).HtmlName,objArticle.CommentUrl,objArticle.WfwComment,objArticle.WfwCommentRss,objArticle.TrackBackUrl
						Else
						.AddItem objArticle.HtmlTitle,Users(objArticle.AuthorID).Email & " (" & Users(objArticle.AuthorID).Name & ")",objArticle.HtmlUrl,objArticle.PostTime,objArticle.HtmlUrl,objArticle.HtmlIntro,Categorys(objArticle.CateID).HtmlName,objArticle.CommentUrl,objArticle.WfwComment,objArticle.WfwCommentRss,objArticle.TrackBackUrl
						End If

					End If
					objRS.MoveNext
					If objRS.eof Then Exit For
					Set objArticle=Nothing
				Next
				End If

	End With

	objRS.close
	Set objRS=Nothing

	Rss2Export.Execute

	Set Rss2Export = Nothing

End Function



Function ExportRSSbyTags(TagsID)

	Dim Rss2Export
	Dim objArticle

	Set Rss2Export = New TRss2Export

	With Rss2Export

	    Dim objRS,TagName

		.TimeZone=ZC_TIME_ZONE

		TagName=Tags(TagsID).Name

		.AddChannelAttribute "title",TransferHTML(ZC_BLOG_TITLE,"[html-format]") & " - " & TagName
		.AddChannelAttribute "link",TransferHTML(ZC_BLOG_HOST,"[html-format]")
		.AddChannelAttribute "description",TransferHTML(ZC_BLOG_SUBTITLE,"[html-format]") & " - " & TagName
		.AddChannelAttribute "generator","RainbowSoft Studio Z-Blog " & ZC_BLOG_VERSION
		.AddChannelAttribute "language",ZC_BLOG_LANGUAGE
		.AddChannelAttribute "copyright",TransferHTML(ZC_BLOG_COPYRIGHT,"[html-format]")
		.AddChannelAttribute "pubDate",Now

				Dim i

				Set objRS=objConn.Execute("SELECT [log_ID],[log_Tag],[log_CateID],[log_Title],[log_Intro],[log_Content],[log_Level],[log_AuthorID],[log_PostTime],[log_CommNums],[log_ViewNums],[log_TrackBackNums],[log_Url],[log_Istop] FROM [blog_Article] WHERE ([log_ID]>0) AND ([log_Level]>2) AND ([log_Tag] LIKE '%{"&TagsID&"}%') ORDER BY [log_PostTime] DESC")

				If (Not objRS.bof) And (Not objRS.eof) Then
				For i=1 to ZC_RSS2_COUNT
					Set objArticle=New TArticle
					If objArticle.LoadInfoByArray(Array(objRS("log_ID"),objRS("log_Tag"),objRS("log_CateID"),objRS("log_Title"),objRS("log_Intro"),objRS("log_Content"),objRS("log_Level"),objRS("log_AuthorID"),objRS("log_PostTime"),objRS("log_CommNums"),objRS("log_ViewNums"),objRS("log_TrackBackNums"),objRS("log_Url"),objRS("log_Istop"))) Then

						If ZC_RSS_EXPORT_WHOLE Then
						.AddItem objArticle.HtmlTitle,Users(objArticle.AuthorID).Email & " (" & Users(objArticle.AuthorID).Name & ")",objArticle.HtmlUrl,objArticle.PostTime,objArticle.HtmlUrl,objArticle.HtmlContent,Categorys(objArticle.CateID).HtmlName,objArticle.CommentUrl,objArticle.WfwComment,objArticle.WfwCommentRss,objArticle.TrackBackUrl
						Else
						.AddItem objArticle.HtmlTitle,Users(objArticle.AuthorID).Email & " (" & Users(objArticle.AuthorID).Name & ")",objArticle.HtmlUrl,objArticle.PostTime,objArticle.HtmlUrl,objArticle.HtmlIntro,Categorys(objArticle.CateID).HtmlName,objArticle.CommentUrl,objArticle.WfwComment,objArticle.WfwCommentRss,objArticle.TrackBackUrl
						End If

					End If
					objRS.MoveNext
					If objRS.eof Then Exit For
					Set objArticle=Nothing
				Next
				End If

	End With

	objRS.close
	Set objRS=Nothing

	Rss2Export.Execute

	Set Rss2Export = Nothing

End Function




Function ExportRSSbyCmt(intID)

	Dim Rss2Export
	Dim objArticle

	Set Rss2Export = New TRss2Export

	With Rss2Export

		Call CheckParameter(intID,"int",0)

		Set objArticle=New TArticle
		If objArticle.LoadInfoByID(intID) Then

		.TimeZone=ZC_TIME_ZONE

		.AddChannelAttribute "title",TransferHTML(ZC_BLOG_TITLE,"[html-format]")& "-" & objArticle.HtmlTitle
		.AddChannelAttribute "link",objArticle.HtmlUrl
		.AddChannelAttribute "generator","RainbowSoft Studio Z-Blog " & ZC_BLOG_VERSION
		.AddChannelAttribute "language",ZC_BLOG_LANGUAGE
		.AddChannelAttribute "pubDate",objArticle.PostTime

			If objArticle.CommNums>0 Then

				Dim objRS
				Set objRS=objConn.Execute("SELECT * FROM [blog_Comment] WHERE ([comm_ID]>0) AND ([log_ID]="&intID&") ORDER BY [comm_PostTime] DESC")

				Dim objComment

				Do While Not objRS.eof

					Set objComment=New TComment
					If objComment.LoadInfoByArray(Array(objRS("comm_ID"),objRS("log_ID"),objRS("comm_AuthorID"),objRS("comm_Author"),objRS("comm_Content"),objRS("comm_Email"),objRS("comm_HomePage"),objRS("comm_PostTime"),objRS("comm_IP"),objRS("comm_Agent"))) Then
						.AddItem "Re:"&objArticle.HtmlTitle,objComment.Email & " (" & objComment.Author & ")",objArticle.HtmlUrl & "#cmt" & objComment.ID,objComment.PostTime,objArticle.HtmlUrl & "#cmt" & objComment.ID,objComment.HtmlContent,"","","","",""
					End If
					Set objComment=Nothing

					objRS.MoveNext

				Loop

				objRS.close
				Set objRS=Nothing
			End If
		ElseIf intID = 0 Then

		.TimeZone=ZC_TIME_ZONE

		.AddChannelAttribute "title",TransferHTML(ZC_BLOG_TITLE,"[html-format]")& "评论留言"
		.AddChannelAttribute "link",ZC_BLOG_HOST
		.AddChannelAttribute "description",TransferHTML(ZC_BLOG_SUBTITLE,"[html-format]")
		.AddChannelAttribute "generator","Z-Blog " & ZC_BLOG_VERSION
		.AddChannelAttribute "language",ZC_BLOG_LANGUAGE
		.AddChannelAttribute "pubDate",Now

				Set objRS=objConn.Execute("SELECT TOP " & ZC_RSS2_COUNT & " * FROM [blog_Comment] WHERE ([comm_ID]>0) ORDER BY [comm_PostTime] DESC")

				Do While Not objRS.eof

					Set objComment=New TComment
					If objComment.LoadInfoByArray(Array(objRS("comm_ID"),objRS("log_ID"),objRS("comm_AuthorID"),objRS("comm_Author"),objRS("comm_Content"),objRS("comm_Email"),objRS("comm_HomePage"),objRS("comm_PostTime"),objRS("comm_IP"),objRS("comm_Agent"))) And objArticle.LoadInfoByID(objRS("log_ID")) Then
						.AddItem objComment.Author & " 回复:"&objArticle.HtmlTitle,objComment.Email & " (" & objComment.Author & ")",objArticle.HtmlUrl & "#cmt" & objComment.ID,objComment.PostTime,objArticle.HtmlUrl & "#cmt" & objComment.ID,objComment.HtmlContent,"","","","",""
					End If
					Set objComment=Nothing

					objRS.MoveNext

				Loop

				objRS.close
				Set objRS=Nothing
		
		End If
		Set objArticle=Nothing

	End With

	Rss2Export.Execute

	Set Rss2Export = Nothing

End Function
'/////////////////////////////////////////////////////////////////////////////////

If Err.Number<>0 then
	Call ShowError(0)
End If
%>