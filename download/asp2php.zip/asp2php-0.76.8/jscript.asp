<% @LANGUAGE="JSCRIPT" %>
<html>
<body>
<% 

k=5;
k=5+t;
k=t-r;
k=t*r;
k=t/r;
k=t%r+3;
k=t%(r+3);

while (t==0)
{
  k=t;
}

for (t=0; t<10; t++)
{
  k=t;
  p=t;
}

if (p==t)
{
  t=p;
}
  else
if (p==5)
{
  k=t;
}
  else
{
  k=4;
  if (c==5)
  {
%>
HELLO!!!!
<%
  }
}

%>

<script language="vbscript" runat="server">

K=5
If K=6 Then
 If K=1 Then
   Response.Write "hello"
%>
Hello!
<%
 End If
End If

P=4

If K=6 Then End

</script>

</body>
</html>

