<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
	bodyHeader('blockinfo');
	bodyNavigation('blockinfo');
require ("./config_database.php");

$date = date("Y-m-d", $timestamp);

//Get TODAY's data
$result = mysql_query("SELECT id FROM $db_table_adblock WHERE date = '$date'");
    $block_count_today = mysql_num_rows($result);
$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_adblock WHERE date = '$date'");
    $block_visitors_today = mysql_num_rows($result);

//Get THIS WEEKS's data
$weekago = date("Y-m-d", mktime(0,0,0,date("m"),date("d")-7,date("Y")));

$result = mysql_query("SELECT id FROM $db_table_adblock WHERE date >= '$weekago'");
    $block_count_week = mysql_num_rows($result);
$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_adblock WHERE date >= '$weekago'");
    $block_visitors_week = mysql_num_rows($result);

//Get OVERALL data
$result = mysql_query("SELECT id FROM $db_table_adblock");
    $block_count_overall = mysql_num_rows($result);
$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_adblock");
    $block_visitors_overall = mysql_num_rows($result);

?>
<div id="side-bar">
	<div>
		<p class="sideBarTitle">Blocked Information</p>
	</div>
</div>

<div id="main-copy">
	<h1 id="introduction1">Blocked Ads</h1>
	<p>The following table shows the number of pages and unique visitors for which the script blocked ads.</p>
	<table width="60%" border="1" cellpadding="2" cellspacing="0">
		<tr>
			<td width="22%">&nbsp;</td>
			<td width="31%" align="center"><strong>Total Blocks</strong></td>
			<td width="47%" align="center"><strong>Unique Visitors Blocked</strong></td>
		</tr>
		<tr>
			<td><strong>Today</strong></td>
			<td align="center"><?php echo $block_count_today; ?></td>
			<td align="center"><?php echo $block_visitors_today; ?></td>
		</tr>
		<tr>
			<td><strong>This Week</strong></td>
			<td align="center"><?php echo $block_count_week; ?></td>
			<td align="center"><?php echo $block_visitors_week; ?></td>
		</tr>
		<tr>
			<td><strong>Overall</strong></td>
			<td align="center"><?php echo $block_count_overall; ?></td>
			<td align="center"><?php echo $block_visitors_overall; ?></td>
		</tr>
	</table>

	<h1 id="introduction">Recent Blocks</h1>
	<br />

	<table width="75%" border="1" cellpadding="2" cellspacing="1">
		<tr>
			<td width="70%" align="center"><strong>IP Address</strong></td>
			<td width="15%" align="center"><strong>Number of Blocks</strong></td>
			<td width="15%" align="center"><strong>More Info</strong></td>
		</tr>
		<?php

$sql = "SELECT DISTINCT visitor_ip FROM $db_table_adblock";

$result = mysql_query($sql)
or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));

while($row2 = mysql_fetch_array($result)) {
	$visitor_ip = $row2["visitor_ip"];

$result2 = mysql_query("SELECT visitor_ip FROM $db_table_adblock WHERE visitor_ip='$visitor_ip'");
    $block_visitors_count = mysql_num_rows($result2);	
?>
		<tr>
			<td align="left" valign="top"><?php echo $visitor_ip; ?></td>
			<td align="left" valign="top"><?php echo $block_visitors_count; ?></td>
			<td align="left" valign="top"><a href="./blockinfo_visitor.php?visitor_ip=<?php echo $visitor_ip; ?>">Info</a></td>
		</tr>
		<?php }//end while and loop?>
	</table>
</div>
<?php bodyFooter('blockinfo'); ?>
