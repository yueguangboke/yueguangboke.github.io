<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
	bodyHeader('clickinfo');
	bodyNavigation('clickinfo');
require ("./config_database.php");

if (isset($_POST['sortnum'])) {
	$sortnum = $_POST['sortnum'];
	$sortname = $_POST['sortname'];
	$sortorder = $_POST['sortorder'];
}
?>

<div id="side-bar">
	<div>
		<p class="sideBarTitle">Click Information</p>
	</div>
</div>

<div id="main-copy">

	<h1 id="introduction1">View Preferences</h1>

	<p>Choose your sorting preferences.</p>
	<form action="clickinfo.php" method="post" name="sortdata">
		<label>View
		<select name="sortnum">
			<option value="10" selected="selected"<?php if ($sortnum == "10") { echo " SELECTED"; } ?>>10</option>
			<option value="25"<?php if ($sortnum == "25") { echo " SELECTED"; } ?>>25</option>
			<option value="50"<?php if ($sortnum == "50") { echo " SELECTED"; } ?>>50</option>
			<option value="100"<?php if ($sortnum == "100") { echo " SELECTED"; } ?>>100</option>
			<option value="250"<?php if ($sortnum == "250") { echo " SELECTED"; } ?>>250</option>
			<option value="500"<?php if ($sortnum == "500") { echo " SELECTED"; } ?>>500</option>
			<option value="1000"<?php if ($sortnum == "1000") { echo " SELECTED"; } ?>>1000</option>
			<option value="1500"<?php if ($sortnum == "1500") { echo " SELECTED"; } ?>>1500</option>
		</select>
		</label>
		clicks sorted by
		<label>
		<select name="sortname">
			<option value="id" selected="selected"<?php if ($sortname == "id") { echo " SELECTED"; } ?>>Date/Time</option>
			<!--<option value="visitor_ip"<?php if ($sortname == "visitor_ip") { echo " SELECTED"; } ?>>IP Address</option>-->
			<!--<option value="adlogger_channel_id"<?php if ($sortname == "adlogger_channel_id") { echo " SELECTED"; } ?>>AdLogger Channel</option>-->
			<option value="displaypage_url"<?php if ($sortname == "displaypage_url") { echo " SELECTED"; } ?>>Display Page URL</option>
			<!--<option value="ad_targ_url"<?php if ($sortname == "ad_targ_url") { echo " SELECTED"; } ?>>Ad Target URL</option>-->
		</select>
		</label>
		in
		<label>
		<select name="sortorder">
			<option value="desc" selected="selected"<?php if ($sortorder == "desc") { echo " SELECTED"; } ?>>Descending</option>
			<option value="asc"<?php if ($sortorder == "asc") { echo " SELECTED"; } ?>>Ascending</option>
		</select>
		</label>
		order.
		<input type="submit" name="Submit" value="Sort" />
	</form>
	
	<h1 id="introduction">Click Information</h1>
	<br />

	<table width="100%" border="1" cellpadding="2" cellspacing="1">
		<tr>
			<td width="10%" align="center"><strong>Click ID</strong></td>
			<td width="25%" align="center"><strong>Date/Time</strong></td>
			<td width="25%" align="center"><strong>IP Address</strong></td>
			<td width="40%" align="center"><strong>Display Page URL</strong></td>
			<!--<td align="center"><strong>Ad Target URL</strong></td>-->
		</tr>
<?php
if (isset($_POST['sortnum'])) {
	$sql = "SELECT * FROM $db_table_logfiles ORDER BY $sortname $sortorder limit $sortnum";
} else { 
	$sql = "SELECT * FROM $db_table_logfiles ORDER BY id DESC LIMIT 10";
}

	$result = mysql_query($sql) or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));
	
	while($row2 = mysql_fetch_array($result)) {
		$id = $row2['id'];
		$date = $row2['date'];
		$time = $row2['time'];
		$visitor_ip = $row2["visitor_ip"];
		$adlogger_channel_id = $row2["adlogger_channel_id"];
		$displaypage_url = urldecode($row2["displaypage_url"]);
		//$ad_targ_url = urldecode($row2["ad_targ_url"]);
?>
		<tr>
			<td align="left" valign="top"><strong><a href="visitordata.php?id=<?php echo $id; ?>"><?php echo $id; ?></a></strong></td>
			<td align="left" valign="top"><?php echo $date . " " . $time; ?></td>
			<td align="left" valign="top"><?php echo $visitor_ip; ?></td>
			<td align="left" valign="top"><a href="<?php echo $displaypage_url; ?>"><?php echo shortenURL($displaypage_url); ?></a></td>
			<!--<td align="left" valign="top"><?php echo $ad_targ_url; ?></td>-->
		</tr>
<?php } ?>
	</table>
</div>

<?php bodyFooter('clickinfo'); ?>