<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

session_start();
session_destroy();
setcookie("adminglog_cookie", "", time()-31536000, "/");
session_start();
$_SESSION['login_message'] = "You have successfully logged out.";
header("Location: ./login.php");
exit();
?>