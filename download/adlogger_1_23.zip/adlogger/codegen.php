<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
	bodyHeader('codegen');
	bodyNavigation('codegen');
require ("./config_database.php");

$go = $_GET['go'];
?>
<div id="side-bar">
	<div>
		<p class="sideBarTitle">Code Generators</p>
		<ul>
			<li><a href="#jscode">&rsaquo; JavaScript Code</a></li>
			<li><a href="#phpcode">&rsaquo; Wrapping Code</a></li>
			<li><a href="#cache-control">&rsaquo; Cache-Control Code</a></li>
		</ul>
	</div>
</div>

<div id="main-copy">
	<h1 id="jscode">JavaScript Tracking Code</h1>
	<p>This is the code that counts page views and clicks for your ads. Put this code at the bottom of every AdSense page immediately before the &lt;/body&gt; tag.</p>
	<p>Select which channel you would like to use and click Generate.</p>
	
<form id="javascriptCodeGen" method="post" action="codegen.php?go=getjava">
	<table width="100%" border="2" cellpadding="4" cellspacing="0">
		<tr>
				<td width="40%" align="center">
					<select name="channelselect">
						<option selected="selected" value="">Select a Channel (Optional)</option>
							<?php
							$sql = "SELECT id, chan_name FROM $db_table_channels ORDER BY chan_name";			
							$result = mysql_query($sql)
							or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));
										
							while($row2 = mysql_fetch_array($result)) {
								$id = $row2['id'];
								$chan_name = stripslashes($row2['chan_name']);
							?>
						<option value="<?php echo $id; ?>"><?php echo $chan_name; ?></option>
							<?php } ?>
					</select>
						<p><a href="./settings.php">Add/Edit a Channel</a></p>
				</td>
				<td width="20%" align="center">
					<label>
						<input type="submit" name="Submit" value="Generate &gt;&gt;" />
					</label>
				</td>
				<td width="40%">
					<?php if ($go == 'getjava') { $channelselect = $_POST['channelselect'];	?>
<textarea name="javascriptCode" cols="40" rows="5" onclick="select()">
<script type="text/javascript"><!--
var adlogger_loc = "<?php echo $siteurl . $adlogger_loc; ?>";
var channel_id = "<?php echo $channelselect; ?>";
//--></script>
<script src="<?php echo $siteurl . $adlogger_loc; ?>/adloggertracker.js" type="text/javascript">
</script>
<noscript>Powered by AdLogger, <a href="http://www.adlogger.org/index.php/Main_Page">Click Fraud Protection</a>.</noscript></textarea>
					<?php } else { ?>
						<textarea name="textarea" cols="40" rows="5"></textarea>
					<?php } ?>
				</td>
		</tr>
	</table>
</form>


	<h1 id="phpcode">PHP Wrapping Code Generator</h1>
	<p>Enter your Google AdSense code in this box, click generate, and it adds a small PHP scripting code around your AdSense that will disable ads for certain visitors. Note: No changes are made to your AdSense code (as dictated by Google's Terms of Service). The code goes <em>around</em> your AdSense code, leaving it intact and unchanged. Also note, this only works on PHP pages.</p>
	<p>With this code, you can disable ads for a certain IP address, a range of IP addresses, and/or people that are clicking too many ads within a set time period. Optionally, if ads are successfully banned for the visitor, you can have an alternate ad or code appear. This can be plain text, javascript, or HTML code.</p>
	<p>You can set your click-fraud defense settings <a href="./settings.php#settings">here</a>.</p>

<form name="originalAdCode" id="originalAdCode" method="post" action="codegen.php?go=getphp#phpcode">
	<table width="100%" border="2" cellpadding="4" cellspacing="0">
		<tr>
				<td align="center">
					<strong>AdSense Code:</strong><br />
						<textarea name="originalAdSenseCode" cols="30" rows="15" onclick="select();"><?php if (isset($_POST['originalAdSenseCode'])) { echo stripslashes($_POST['originalAdSenseCode']); } else { echo "[Enter your AdSense Code Here]"; } ?></textarea>
					<br />
						<strong>Alternate Ad Code:</strong> (Optional)
						<br />
						<textarea name="alt_ad_code" cols="30" rows="5" onclick="select();"><?php if (isset($_POST['alt_ad_code'])) { echo stripslashes($_POST['alt_ad_code']); } ?></textarea>
					
				</td>
				<td align="center">
					<label>
						<input type="checkbox" name="same_server" value="checkbox" <?php
							if (isset($_POST['originalAdSenseCode'])) { 
								if (isset($_POST['same_server'])) {
									echo "checked=\"checked\"";
								}
							} else {
									echo "checked=\"checked\"";
							}
						?> />
						Check if this code will go on the same server as your AdLogger installation. (Preferred)
					</label>
					<p>&nbsp;</p>
					<input type="submit" name="Submit" value="Generate &gt;&gt;" />
				</td>

<?php
if ($go == 'getphp') {

$originalAdSenseCode = stripslashes($_POST['originalAdSenseCode']);
$alt_ad_code = stripslashes($_POST['alt_ad_code']);

if (isset($_POST['same_server'])) {

$phpopen = <<<EOD
<!-- Start AdLogger Wrapping Code -->
<?php @include_once("$adlogger_doc_path/ad_check_include.php"); if (\$show_ads == 'y') { ?>


EOD;

} else {

$phpopen = <<<EOD
<!-- Start AdLogger Wrapping Code -->
<?php if (!isset(\$ad_check)) { \$ad_check = @file_get_contents("$siteurl$adlogger_loc/ad_check.php?visitor_ip=" . \$_SERVER['REMOTE_ADDR']); } if (\$ad_check == 'y') { ?>


EOD;

}

if ($alt_ad_code !='') {

$phpclose = <<<EOD


<?php } else { ?>

$alt_ad_code

<?php } ?>
<!-- End AdLogger Wrapping Code -->
EOD;

} else {

$phpclose = <<<EOD


<?php } ?>
<!-- End AdLogger Wrapping Code -->
EOD;

}

?>

<td align="center">
<strong>Copy the following code to your site's page:</strong>

<textarea name="newAdsenseCode" cols="40" rows="20" onclick="select();">
<?php echo $phpopen; ?>
<?php echo $originalAdSenseCode; ?>
<?php echo $phpclose;?>
</textarea>
</td>
<?php } ?>
    </tr>
  </table>
</form>


	<h1 id="cache-control">PHP Cache-Control Code</h1>
	<p>The Cache-Control code is very important if you're using the PHP Wrapping Code. It forces the web page to check if ads should be shown every time a visitor reloads your page. Ordinarily, your visitor's browser would "cache" the page in order to make it load faster. This means that it doesn't reload or recheck to see if they've clicked on any ads. To combat this problem, you can put a small snippet of code at the top of each of your web pages.</p>
	<p>This code must be placed before any output is sent to the browser. This usually means it's placed before the &lt;doctype..&gt; and &lt;html&gt; opening code.</p>

		<table width="100%" border="2" cellpadding="4" cellspacing="0">
			<tr>
					<td align="center">
						<p>If this is going on a website located on the same server as your AdLogger setup, please use this code.</p>
<textarea name="phpCacheControlCode_same" cols="75" rows="2" onclick="select();"><?php
$phpCacheControl_same = <<<EOD
<?php @include_once("$adlogger_doc_path/cache_control.php"); ?>
EOD;
echo $phpCacheControl_same;
?></textarea>
						<p>If not, use this code instead.</p>
<textarea name="phpCacheControlCode_dif" cols="75" rows="7" onclick="select();"><?php
$phpCacheControl_dif = <<<EOD
<?php
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
?>
EOD;
echo $phpCacheControl_dif;
?></textarea>
					</td>
			</tr>
		</table>

</div>

<?php bodyFooter('codegen'); ?>