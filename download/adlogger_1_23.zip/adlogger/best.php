<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
require ("./config_database.php");

if (isset($_POST['view_criteria'])) {
	$view_criteria = $_POST['view_criteria'];
	$view_order = $_POST['view_order'];
	$view_num = $_POST['view_num'];
	$view_date = $_POST['view_date'];
} else {
	$view_criteria = "displaypage_url";
	$view_order = "desc";
	$view_num = "10";
}

bodyHeader('best');
bodyNavigation('best');
?>

<div id="side-bar">
	<div>
		<p class="sideBarTitle">Performance Data</p>
	</div>
</div>

<div id="main-copy">
	<h1 id="preferences">Performance Data Preferences</h1>
	<form action="best.php" method="post" id="sortdata">
		<p>
			<label>View the
			<select name="view_num">
				<option value="10"<?php if ($view_num == "10") { echo " SELECTED"; } ?>>10</option>
				<option value="25"<?php if ($view_num == "25") { echo " SELECTED"; } ?>>25</option>
				<option value="50"<?php if ($view_num == "50") { echo " SELECTED"; } ?>>50</option>
				<option value="100"<?php if ($view_num == "100") { echo " SELECTED"; } ?>>100</option>
			</select>
			</label>
			<label>
			<select name="view_order">
				<option value="desc"<?php if ($view_order == "desc") { echo " SELECTED"; } ?>>Best</option>
				<option value="asc"<?php if ($view_order == "asc") { echo " SELECTED"; } ?>>Worst</option>
			</select>
			</label>
			<label>
			<select name="view_criteria">
				<option value="displaypage_url"<?php if ($view_criteria == "displaypage_url") { echo " SELECTED"; } ?>>Pages</option>
				<option value="adlogger_channel_id"<?php if ($view_criteria == "adlogger_channel_id") { echo " SELECTED"; } ?>>Channels</option>
				<option value="visitor_ip"<?php if ($view_criteria == "visitor_ip") { echo " SELECTED"; } ?>>Visitors</option>
				<option value="date"<?php if ($view_criteria == "date") { echo " SELECTED"; } ?>>Days</option>
			</select>
			</label>
			<label> for
			<input name="view_date" type="text" onfocus="showCalendarControl(this);" value="<?php echo $view_date; ?>" size="10">
			</label>
			<input type="submit" name="Submit" value="Sort" />
			<br />
			* Leave date blank to search all records.<br />
			** "Worst" does not include pages with 0 clicks because they don't exist in the database yet.</p>
	</form>
	
	<h1 id="performancedata">Performance Data</h1>
	<table width="100%" border="0" cellpadding="0" cellspacing="0" style="height:38px;">
		<tr>
			<td width="74%" align="center"><strong>Criteria Value</strong></td>
			<td width="26%" align="center"><strong>Clicks</strong></td>
		</tr>
		<tr>
			<td colspan="2"><hr /></td>
		</tr>
		<?php
		if (isset($view_date) && $view_date != '') {
			$view_date2 = date('Y-m-d', strtotime($view_date));
			$view_date3 = "WHERE date = '$view_date2'";
			$view_date4 = "AND date = '$view_date2'";
		} else {
			$view_date3 = '';
			$view_date4 = '';
		}

		$sql = "SELECT DISTINCT $view_criteria, count($view_criteria) as instance_count FROM $db_table_logfiles $view_date3 GROUP BY $view_criteria ORDER BY instance_count $view_order LIMIT $view_num
		";
		$result = mysql_query($sql)
		or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));
		
		while($row2 = mysql_fetch_array($result)) {
			$id = $row2['id'];
			$datetime = $row2['datetime'];
			$date = $row2['date'];
			$visitor_ip = $row2["visitor_ip"];
			$adlogger_channel_id = $row2["adlogger_channel_id"];
			$displaypage_url = $row2["displaypage_url"];
			//$ad_targ_url = $row2["ad_targ_url"];
			//$ad_format = $row2["ad_format"];
		
			if ($view_criteria == 'displaypage_url') {
				$get_criteria = $displaypage_url;
			} elseif ($view_criteria == 'adlogger_channel_id') {
				$get_criteria = $adlogger_channel_id;
			} elseif ($view_criteria == 'visitor_ip') {
				$get_criteria = $visitor_ip;
			} elseif ($view_criteria == 'date') {
				$get_criteria = $date;
			}

				//Get channel info that corresponds to the channel number
				if ($view_criteria == "adlogger_channel_id") {
					$sql2 = "SELECT * FROM $db_table_channels WHERE id='$adlogger_channel_id'";
									 
					$result2 = mysql_query($sql2)
						or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));
							
					while ($row2 = mysql_fetch_array($result2)) {
						$chan_name = stripslashes($row2["chan_name"]);
					}
				}

			//Then check how many times that value shows up in the DB as clicks
			$result_count = mysql_query("select $view_criteria from $db_table_logfiles WHERE $view_criteria = '$get_criteria' $view_date4");
			$instance_click_total = mysql_num_rows($result_count);
		?>
		<tr>
			<td>
				<?php
					if ($view_criteria == "adlogger_channel_id") {
						echo $chan_name;
					} else {
						echo shortenURL($get_criteria);
					}
				?>
			</td>
			<td align="center"><?php echo $instance_click_total;?></td>
		</tr>
		<?php } ?>
	</table>
</div>

<?php bodyFooter('best'); ?>