<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//     AdLogger                                                                 //
//     Copyright 2006 by Trevor Fitzgerald                                      //
//     http://www.adlogger.org                                                  //
//     support@adlogger.org                                                     //
/*                                                                              //
*/      $version_num = '1.23';                                                  //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("../functions.php");
	micro_time('start');
	bodyHeader('install');
	bodyNavigation('install');

error_reporting(E_ALL ^ E_NOTICE);
?>

<div id="main-copy">


<?php if (@$_POST['step'] == "") { ?>

	<p>Welcome and thank you for downloading AdLogger. In just a few moments, you will be able to run the script. Please verify that you have completed the following pre-installation tasks before continuing.</p>
	<p>For detailed instructions on setting up AdLogger, please visit the <a href="http://www.adlogger.org/" target="_blank">online documentation</a>.</p>
	
	<p><strong>Step 1: </strong>A couple basic PHP requirements must be met in order to use the script. The script will not function properly if PHP is running in safe mode or if file_get_contents is not enabled.</p>

		<table width="50%" border="2" align="center" cellpadding="0" cellspacing="0">
			<tr>
				<td width="50%" align="center">PHP not in Safe Mode (required)</td>
				<td width="50%" align="center">
					<?php
					// Check for safe mode
					if (ini_get('safe_mode') ){
						echo 'Not OK';
						$discontinue_install = 'y';
					} else {
						echo 'OK';
					}
					?>
				</td>
			</tr>
			<tr>
				<td align="center">allow_url_fopen Enabled</td>
				<td align="center">
					<?php
					if( ini_get( 'allow_url_fopen' ) == true ) {
						echo 'OK';
					} else {
						echo 'Warning';
						$warning_install = 'y';
					}
					?>
				</td>
			</tr>
			<tr>
				<td align="center">file_get_contents Enabled</td>
				<td align="center">
					<?php
					if (function_exists('file_get_contents')) {
						echo 'OK';
					} else {
						echo 'Warning';
						$warning_install = 'y';
					}
					?>
				</td>
			</tr>
		</table>
	
	<p><strong>Step 2: </strong>CHMOD configuration files to 666.</p>

		<table width="50%" border="2" align="center" cellpadding="0" cellspacing="0">
			<tr>
				<td width="50%" align="center">config_settings.php (required)</td>
				<td width="50%" align="center">
					<?php
					if (is_writable('../config_settings.php')) {
						echo 'Complete';
					} elseif(@chmod('../config_settings.php',0666)) {
						echo 'Complete';
					} else {
						echo 'Incomplete';
						$discontinue_install = 'y';
					}
					?>
				</td>
			</tr>
			<tr>
				<td align="center">config_database.php (required)</td>
				<td align="center">
					<?php
					if (is_writable('../config_database.php')) {
						echo 'Complete';
					} elseif(@chmod('../config_database.php',0666)) {
						echo 'Complete';
					} else {
						echo 'Incomplete';
						$discontinue_install = 'y';
					}
					?>
				</td>
			</tr>
		</table>
		
	<p><strong>Step 3: </strong>Create a database for AdLogger through your server's control panel.</p>
	<p><strong>Step 4: </strong>Continue using this installation wizard.</p>
	<p>Once you're ready, go ahead and continue!</p>

	<div align="center">
		<?php if (isset($warning_install)) { ?>
			<table width="80%" border="2" align="center" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center">
						<p>Warning: Your server isn't 100% compatible with AdLogger but you can still use it without any problem as long as the websites where you'll be using AdLogger are all located on this same server.</p>
					</td>
				</tr>
			</table>
			<p>&nbsp;</p>
		<?php } ?>
		<?php if (!isset($discontinue_install)) { ?>
			<form name="form1" method="post" action="./index.php">
				<input name="step" type="hidden" id="step" value="2">
				<input type="submit" name="Submit" value="Continue">
			</form>
		<?php } else { ?>
			<table width="80%" border="2" align="center" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center">
						<p><strong>Before installation can continue, the above requirements must be satisfied.</strong></p>
						<p>Click here to <a href="<?php echo $_SERVER['PHP_SELF']; ?>">refresh</a> this page once you're ready.</p>
					</td>
				</tr>
			</table>
		<?php } ?>
	</div>
		



<?php } if (@$_POST['step'] == "2") { ?>



	<h1>Server Information</h1>
	<p>Please enter the information for your MySQL server.</p>

		<form name="install_step_2" method="post" action="./index.php" onsubmit="return validate_step_2(this);">

				<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
					<tr>
						<td>Database Hostname (Default hostname is localhost)</td>
						<td><input name="db_host" type="text" id="db_host" value="localhost" size="50"></td>
					</tr>
					<tr>
						<td>Database Port (Default port is 3307)</td>
						<td><input name="db_port" type="text" id="db_port" value="3307" size="50"></td>
					</tr>
					<tr>
						<td>Database Username</td>
						<td><input name="db_user" type="text" id="db_user" size="50"></td>
					</tr>
					<tr>
						<td>Database Password</td>
						<td><input name="db_pass" type="password" id="db_pass" size="50"></td>
					</tr>
					<tr>
						<td>Database Name</td>
						<td><input name="db_name" type="text" id="db_name" size="50"></td>
					</tr>
					<tr>
						<td>Database Table Prefix</td>
						<td><input name="db_table_prefix" type="text" id="db_table_prefix" value="adlogger_" size="50"></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>Site that hosts the AdLogger backend (no trailing slash)</td>
						<td><input name="siteurl" type="text" id="siteurl" value="<?php echo "http://" . $_SERVER['SERVER_NAME']; ?>" size="50" /></td>
					</tr>
					<tr>
						<td>Location of AdLogger files (slash included before, but no trailing slash)</td>
						<td><input name="adlogger_loc" type="text" id="adlogger_loc" value="<?php $adlogger_loc = str_replace("/install/index.php", "", $_SERVER['PHP_SELF']); echo $adlogger_loc; ?>" size="50" /></td>
					</tr>
					<tr>
						<td>Document Path to AdLogger Directory</td>
						<td><input name="adlogger_doc_path" type="text" id="adlogger_doc_path" value="<?php echo $_SERVER['DOCUMENT_ROOT'] . $adlogger_loc; ?>" size="50" /></td>
					</tr>
				</table>

			<p>&nbsp;</p>

			<div align="center">
				<input name="step" type="hidden" id="step" value="3">
				<input type="submit" name="Submit" value="Continue">
			</div>

		</form>



<?php } if (@$_POST['step'] == "3") {



$db_host = $_POST['db_host'];
$db_port = $_POST['db_port'];
$db_user = $_POST['db_user'];
$db_pass = $_POST['db_pass'];
$db_name = $_POST['db_name'];
$db_table_prefix = $_POST['db_table_prefix'];

$db_table_adblock = $db_table_prefix . "adblock";
$db_table_channels = $db_table_prefix . "channels";
$db_table_logfiles = $db_table_prefix . "logfiles";
$db_table_users = $db_table_prefix . "users";

$siteurl = $_POST['siteurl'];
$adlogger_loc = $_POST['adlogger_loc'];
$adlogger_doc_path = $_POST['adlogger_doc_path'];

if (empty($db_host)) {
	$db_host = "localhost";
}

if ($db_port != '3307') {
	$db_host = $db_host . ":" . $db_port;
}

//add variables to config_database.php
$newfile = fopen("../config_database.php", "w");

if (!$newfile) {
	echo "config_database.php was unable to be opened.  Verify that permissions are set to 666.";
	exit();
}

$file_contents = <<<EOD
<?php
\$siteurl = "$siteurl";

\$adlogger_loc = "$adlogger_loc";

\$adlogger_doc_path = "$adlogger_doc_path";

\$db_table_prefix = "$db_table_prefix";

mysql_connect("$db_host", "$db_user", "$db_pass") or die(mysql_error());
mysql_select_db("$db_name") or die(mysql_error());

\$db_table_adblock = \$db_table_prefix . "adblock";
\$db_table_channels = \$db_table_prefix . "channels";
\$db_table_logfiles = \$db_table_prefix . "logfiles";
\$db_table_users = \$db_table_prefix . "users";
?>
EOD;

fwrite($newfile, "$file_contents");
fclose($newfile);

// End of writing config_database.php file
//




// Now, setup the database tables

require ("../config_database.php");
$date = date('Y-m-d', time());

$sql = "";
$source = "
CREATE TABLE IF NOT EXISTS $db_table_adblock (
  `id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL default '0000-00-00',
  `time` time NOT NULL default '00:00:00',
  `visitor_ip` varchar(15) NOT NULL default '',
  `displaypage_url` varchar(250) NOT NULL default '',
  `reason` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS $db_table_channels (
  `id` int(4) NOT NULL auto_increment,
  `chan_name` varchar(50) NOT NULL default '',
  `chan_desc` varchar(250) NOT NULL default '',
  PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS $db_table_logfiles (
  `id` int(12) NOT NULL auto_increment,
  `date` date NOT NULL default '0000-00-00',
  `time` time NOT NULL default '00:00:00',
  `timestamp` varchar(12) NOT NULL default '',
  `visitor_ip` varchar(15) NOT NULL default '',
  `visitor_agent` varchar(250) NOT NULL default '',
  `adlogger_channel_id` int(4) NOT NULL,
  `displaypage_url` varchar(250) NOT NULL default '',
  `ad_targ_url` varchar(50) NOT NULL default '',
  `ad_format` varchar(10) NOT NULL default '',
  PRIMARY KEY  (`id`)
);

CREATE TABLE IF NOT EXISTS $db_table_users (
  `id` int(2) NOT NULL auto_increment,
  `username` varchar(15) NOT NULL default '',
  `password` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
);
";

// read each line from source
$line = trim($source);
// if the line is not a comment (starts with --) append to $sql
if (($line) && (substr($line,0,2) <> "--")) $sql .= $line;

// explode $sql on the semi-colon characters to break out the individual queries
$queries = explode(";",$sql);

// and finally execute each query
foreach($queries as $query)
{
mysql_query($query);
}


require ("../config_database.php");
?>


	<h1>Steps Completed</h1>
	<p>Saving database connection info... complete.<br />Setting up tables in database... complete.</p>
	<h1>AdLogger Settings</h1>
	<p>Please setup your initial settings. These can be changed at any time in your administration panel.</p>

	<form name="install_step_3" method="post" action="./index.php" onsubmit="return validate_step_3(this);">
		<table width="85%" border="2" align="center" cellpadding="4" cellspacing="0">
			<tr>
				<td height="28" colspan="2" align="center" valign="middle"><strong>Administration Panel Access</strong></td>
			</tr>
			<tr>
				<td width="39%" align="center" valign="middle">Username</td>
				<td width="61%" align="center" valign="middle"><input name="username" type="text" id="username" size="30" /></td>
			</tr>
			<tr>
				<td align="center" valign="middle">Password</td>
				<td align="center" valign="middle"><input name="password1" type="password" id="password1" size="30" /></td>
			</tr>
		</table>
		
		<p>&nbsp;</p>
		
		<table width="85%" border="2" align="center" cellpadding="4" cellspacing="0">
			<tr>
				<td height="28" colspan="2" align="center" valign="middle"><strong>Notification Preferences</strong></td>
			</tr>
			<tr>
				<td width="67%" align="center" valign="middle">Email Address </td>
				<td width="33%" align="center" valign="middle"><input name="email" type="text" id="email" size="30" /></td>
			</tr>
			<tr>
				<td align="center" valign="middle">Would you like to receive an email every time a visitor clicks an ad? (Note: This feature is <strong>NOT </strong>recommended for high traffic sites, but it can be exciting if you have a small site! :) )</td>
				<td align="center" valign="middle"><input name="emailnotice" type="radio" value="y" checked="checked" />Yes<input name="emailnotice" type="radio" value="n" />No</td>
			</tr>
			<tr>
				<td align="center" valign="middle">Would you like to receive an email every time a visitor clicks more than one ad? </td>
				<td align="center" valign="middle"><input name="emailalert" type="radio" value="y" checked="checked" />Yes<input name="emailalert" type="radio" value="n" />No</td>
			</tr>
		</table>
			
		<p>&nbsp;</p>
		
		<table width="85%" border="2" align="center" cellpadding="4" cellspacing="0">
			<tr>
				<td height="28" colspan="2" align="center" valign="middle"><strong>Click Fraud Settings</strong></td>
			</tr>
			<tr>
				<td colspan="2" align="center" valign="middle">A visitor can click a maximum of <input name="clickmax" type="text" size="3" /> ad(s) every <input name="clickmaxtime" type="text" size="3" /> hour(s).</td>
			</tr>
		</table>
		
		<p>&nbsp;</p>
		
		<div align="center">
			<input name="step" type="hidden" id="step" value="4">
			<input type="submit" name="Submit" value="Continue">
		</div>
		
	</form>



<?php } if (@$_POST['step'] == "4") {



$username = $_POST['username'];
$password1 = $_POST['password1'];
$email = $_POST['email'];
$emailnotice = $_POST['emailnotice'];
$emailalert = $_POST['emailalert'];
$clickmax = $_POST['clickmax'];
$clickmaxtime = $_POST['clickmaxtime'];

$login_hash = createRandomString(30);

if ($clickmax == '') $clickmax = 99;
if ($clickmaxtime == '') $clickmaxtime = 1;

//add variables to config_settings.php
$newfile = fopen("../config_settings.php", "w");

if (!$newfile) {
echo "config_settings.php was unable to be opened.  Verify that permissions are set to 666.";
exit();
}

$file_contents = <<<EOD
<?php
/*/////////////////////////////////////////////////////
You can change these through your administration panel.
*//////////////////////////////////////////////////////

\$email = "$email"; // Your email address for notifications and lost password

\$email_notice = "$emailnotice"; // Notice on every click? (y or n)

\$email_alert = "$emailalert"; // Alert on multiple click? (y or n)

\$emailalert_num = 5; // Alert after this many clicks

\$clickmax = "$clickmax"; // Number of clicks allowed per visitor

\$clickmaxtime = $clickmaxtime * 3600; // Time in which that visitor can click those ads (in seconds)

\$gmt_dif = "default"; // Your timezone difference from GMT

putenv("TZ=Europe/London");
\$timestamp = time() + 60*60*(\$gmt_dif); // Better correct the time already

\$ip_db_check = 'y'; // If using the PHP wrapping code, should the script check the visitor's IP against the database?

\$ip_range_ban_list = array(
""
);

\$disable_all_ads = "n";

\$login_hash = "$login_hash";

\$version_num = '$version_num';

?>
EOD;

fwrite($newfile, "$file_contents");
fclose($newfile);

// End of writing config_settings.php file
//

require ("../config_database.php");
require ("../config_settings.php");

//Insert Login information into the database
//$username and $password1

// Hash the password using 160-bit hash, SHA-1
$password_hash = sha1($password1);

mysql_query("INSERT INTO $db_table_users
	SET
	username='$username',
	password='$password_hash'
")
or die(mysql_error());
//
$chmodsucces = false;
if(@chmod('../config_database.php',0644)) {
   $chmodsucces = true;
}
?>
	<h1>Steps Completed</h1>
	<p>Saving database connection info... complete.<br />Setting up tables in database... complete.<br />Saving settings... complete.</p>
	<p>Congratulations! AdLogger has been installed successfully!</p>

	<h1>Post Installation Instructions</h1>
	<p><strong>Step 1: </strong>Delete the installation directory (/install).</p>
<?php
if($chmodsucces) {
	echo '<p><font style="text-decoration:line-through;"><strong>Step 2: </strong>CHMOD config_database.php back to 644. </font><font 
style="text-decoration:none; font-weight:bold;">Already Done.</font></p>';
} else {
        echo '<p><strong>Step 2: </strong>CHMOD config_database.php back to 644.</p>';
}
?>
	<p><strong>Step 3: </strong>There are just a few more settings you need to set. Configure your desired settings on the Settings page in your admin panel.</p>
	<p><strong>Step 4: </strong>Before AdLogger can start recording stats, you must place a piece of javascript code on each of your AdSense pages. This code can be found in your admin panel.</p>
	<p><strong>Step 5: </strong>To become fully aware of the strengths and shortcomings of the AdLogger script, please read the <a href="http://www.adlogger.org/" target="_blank">FAQ</a> page. There are some important things you should know.</p>
	<p>If you run into any problems whatsoever, please fill out a bug report and submit it in the <a href="http://www.adlogger.org/forum/" target="_blank">forum</a>. We would like to fix any known issues as soon as possible.</p>


	<table border="1" align="center" cellpadding="0" cellspacing="0">
		<tr>
			<td colspan="2" align="center"><strong>Login Information</strong></td>
		</tr>
		<tr>
			<td colspan="2" align="center">You can log in to your administration panel at the following url:<br /><a href="<?php echo $siteurl . $adlogger_loc; ?>"><?php echo $siteurl . $adlogger_loc; ?></a></td>
		</tr>
	</table>

<?php
function adlogger_update_check_install($version_num, $siteurl) {
	if (url_exists("http://www.adlogger.org/updateinstall.php")) {
		$adlogger_update_status = @file_get_contents("http://www.adlogger.org/updateinstall.php?version=$version_num&site=$siteurl");
		print $adlogger_update_status;
    }
}
@adlogger_update_check_install($version_num, $siteurl); }
?>

</div>

<?php bodyFooter('install'); ?>
