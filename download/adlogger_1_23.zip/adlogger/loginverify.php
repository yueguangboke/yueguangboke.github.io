<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

session_start();

if ($_SESSION['adminglog'] != $login_hash) {
	if (isset($_COOKIE['adminglog_cookie']) && ($_COOKIE['adminglog_cookie'] == $login_hash)) {
		$_SESSION['adminglog'] = $login_hash;
	} else {
		header("Location: ./login.php");
		exit();
	}
}
?>