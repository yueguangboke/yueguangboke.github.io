<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
require ("./config_database.php");

if ($_POST['view_date']) {
	$view_date_f = $_POST['view_date'];
	$view_date = date('Y-m-d', strtotime($view_date_f));
	$range = $_POST['range'];
} else {
	$view_date_f = date("m/d/Y", $timestamp);
	$view_date = date("Y-m-d", $timestamp);
	$range = "no";
}

if ($_POST['view_date2']) {
	$view_date_f = '';
	$view_date_f2 = $_POST['view_date2'];
	$view_date_f3 = $_POST['view_date3'];
	$view_date2 = date('Y-m-d', strtotime($view_date_f2));
	$view_date3 = date('Y-m-d', strtotime($view_date_f3));
	$range = $_POST['range'];
}

if ($range == "no") {
	
	$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE date = '$view_date'");
		$click_count = mysql_num_rows($result);
/*
	$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_as' AND date = '$view_date'");
		$click_count_ads = mysql_num_rows($result);
	$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_al%' AND date = '$view_date'");
		$click_count_links = mysql_num_rows($result);
*/
	$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_logfiles WHERE date = '$view_date'");
		$unique_visitors_click = mysql_num_rows($result);

} else {

	$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE '$view_date2' <= date AND '$view_date3' >= date");
		$click_count = mysql_num_rows($result);
/*
	$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_as' AND '$view_date2' <= date AND '$view_date3' >= date");
		$click_count_ads = mysql_num_rows($result);
	$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_al%' AND '$view_date2' <= date AND '$view_date3' >= date");
		$click_count_links = mysql_num_rows($result);
*/
	$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_logfiles WHERE '$view_date2' <= date AND '$view_date3' >= date");
		$unique_visitors_click = mysql_num_rows($result);

}

bodyHeader('archive');
bodyNavigation('archive');
?>

<div id="side-bar">
	<div>
		<p class="sideBarTitle">Archive Data</p>
	</div>
</div>

<div id="main-copy">
	<h1 id="archive_preferences">Archive Preferences</h1>
	<form action="./archive.php" method="post" id="sortdata">
		<p>View
			<label>performance statistics for </label>
			<input name="view_date" type="text" onfocus="showCalendarControl(this);" value="<?php echo $view_date_f; ?>" size="10">
			.
			<label>
			<input type="submit" name="Submit" value="Sort" />
			</label>
		</p>
		<input type="hidden" name="range" value="no" />
	</form>
	<form action="./archive.php" method="post" id="sortdata1">
		<p>View
			<label>performance statistics from </label>
			<input name="view_date2" type="text" onfocus="showCalendarControl(this);" value="<?php echo $view_date_f2; ?>" size="10">
			through
			<input name="view_date3" type="text" onfocus="showCalendarControl(this);" value="<?php echo $view_date_f3; ?>" size="10">
			.
			<label>
			<input type="submit" name="Submit" value="Sort" />
			</label>
			<input type="hidden" name="range" value="yes" />
	</form>

	<h1 id="archive_statistics">Archive Statistics</h1>
	<br />

	<table width="99%" border="1" cellpadding="0" cellspacing="0">
		<tr>
			<td width="33%" height="53">&nbsp;</td>
			<td width="33%" align="center"><strong>Total Clicks</strong></td>
			<!--<td width="25%" align="center"><strong>Clicks for<br />Ads/Link Units</strong></td>-->
			<td width="33%" align="center"><strong>Unique Visitors That Clicked</strong></td>
		</tr>
		<tr>
			<td align="center"><strong>
				<?php if ($range == "no") { echo $view_date_f; } else {  echo $view_date_f2 . " - " . $view_date_f3; }?>
				</strong></td>
			<td align="center"><?php echo $click_count; ?></td>
			<!--<td align="center"><?php echo $click_count_ads . " / " . $click_count_links; ?></td>-->
			<td align="center"><?php echo $unique_visitors_click; ?></td>
		</tr>
	</table>

	<h1 id="archive_clickinfo">Archived Clicks</h1>
	<br />

	<table width="100%" border="1" cellpadding="2" cellspacing="1">
		<tr>
			<td width="15%" align="center"><strong>Click ID</strong></td>
			<td width="20%" align="center"><strong>Date/Time</strong></td>
			<td width="20%" align="center"><strong>IP Address</strong></td>
			<td width="45%" align="center"><strong>Display Page URL</strong></td>
			<!--<td align="center"><strong>Ad Target URL</strong></td>-->
		</tr>

<?php
if ($range == "no") {
	$sql = "SELECT * FROM $db_table_logfiles WHERE date = '$view_date'";
} else { 
	$sql = "SELECT * FROM $db_table_logfiles WHERE '$view_date2' <= date AND '$view_date3' >= date";
}
			
$result = mysql_query($sql) or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));
			
while($row2 = mysql_fetch_array($result)) {
	$id = $row2['id'];
	$date = $row2['date'];
	$time = $row2['time'];
	$visitor_ip = $row2["visitor_ip"];
	$adlogger_channel_id = $row2["adlogger_channel_id"];
	$displaypage_url = urldecode($row2["displaypage_url"]);
	$ad_targ_url = urldecode($row2["ad_targ_url"]);
?>

		<tr>
			<td align="left" valign="top"><strong><a href="visitordata.php?id=<?php echo $id; ?>"><?php echo $id; ?></a></strong></td>
			<td align="left" valign="top"><?php echo $date . " " . $time; ?></td>
			<td align="left" valign="top"><?php echo $visitor_ip; ?></td>
			<td align="left" valign="top"><a href="<?php echo $displaypage_url; ?>"><?php echo shortenURL($displaypage_url); ?></a></td>
			<!--<td align="left" valign="top"><?php echo $ad_targ_url; ?></td>-->
		</tr>

<?php } ?>
	</table>
</div>

<?php bodyFooter('archive'); ?>