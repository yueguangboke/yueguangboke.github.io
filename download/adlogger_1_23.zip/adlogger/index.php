<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    An open-source tracking tool for AdSense publishers                       //
//                                                                              //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//    -----------------                                                         //
//                                                                              //
//    AdLogger is free software; you can redistribute it and/or modify          //
//    it under the terms of the GNU General Public License as published by      //
//    the Free Software Foundation; either version 2 of the License, or         //
//    (at your option) any later version.                                       //
//                                                                              //
//    AdLogger is distributed in the hope that it will be useful,               //
//    but WITHOUT ANY WARRANTY; without even the implied warranty of            //
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the              //
//    GNU General Public License for more details.                              //
//                                                                              //
//    You should have received a copy of the GNU General Public License         //
//    along with this program; if not, you can find it here:                    //
//    http://www.gnu.org/copyleft/gpl.html                                      //
//                                                                              //
//    -----------------                                                         //
//                                                                              //
//    If you find this script useful, please share it with others.              //
//                          Thank you!                                          //
//                          http://www.adlogger.org                             //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./config_database.php");

require ("./functions.php");
	micro_time('start');
	bodyHeader('index');
	bodyNavigation('index');

require ("./lang/lang_functions.php");

$date = date('Y-m-d', $timestamp);

//Get TODAY's data
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE date = '$date'");
    $click_count_today = mysql_num_rows($result);
/*
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_as' AND date = '$date'");
    $click_count_today_ads = mysql_num_rows($result);
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_al%' AND date = '$date'");
    $click_count_today_links = mysql_num_rows($result);
*/

//Get THIS WEEKS's data
$weekago = $timestamp - 604800;

$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE timestamp > '$weekago'");
    $click_count_week = mysql_num_rows($result);
/*
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_as' AND timestamp > '$weekago'");
    $click_count_week_ads = mysql_num_rows($result);
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_al%' AND timestamp > '$weekago'");
    $click_count_week_links = mysql_num_rows($result);
*/

//Get OVERALL data
$result = mysql_query("SELECT id FROM $db_table_logfiles");
    $click_count_overall = mysql_num_rows($result);
/*
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_as'");
    $click_count_overall_ads = mysql_num_rows($result);
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_al%'");
    $click_count_overall_links = mysql_num_rows($result);
*/

//Get number of TODAY's unique visitors
$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_logfiles WHERE date = '$date'");
    $unique_visitors_click_today = mysql_num_rows($result);

//Get number of WEEKLY unique visitors
$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_logfiles WHERE timestamp > '$weekago'");
    $unique_visitors_click_week = mysql_num_rows($result);

//Get number of OVERALL unique visitors
$result = mysql_query("SELECT DISTINCT visitor_ip FROM $db_table_logfiles");
    $unique_visitors_click = mysql_num_rows($result);

?>

<div id="side-bar">
	<div>
		<p class="sideBarTitle"><?php _lang(INDEX_VERSION_INFO); ?></p>
		<?php adlogger_update_check($version_num); ?>
	</div>
</div>

<div id="main-copy">
	<h1 id="overview"><?php _lang(INDEX_OVERVIEW); ?></h1>
	<p><?php _lang(INDEX_REAL_TIME_STATS); ?>:</p>
	<table width="99%" cellpadding="2" cellspacing="0" border="1">
		<tr>
			<td width="33%">&nbsp;</td>
			<td width="33%" align="center"><strong><?php _lang(INDEX_TOTAL_CLICKS); ?></strong></td>
			<!--<td width="25%" align="center"><strong><?php _lang(INDEX_CLICKS_ADS_LINKS); ?></strong></td>-->
			<td width="33%" align="center"><strong><?php _lang(INDEX_UNIQUE_CLICKS); ?></strong></td>
		</tr>
		<tr>
			<td><strong><?php _lang(INDEX_RANGE_TODAY); ?></strong></td>
			<td align="center"><?php echo $click_count_today; ?></td>
			<!--<td align="center"><?php echo $click_count_today_ads . " / " . $click_count_today_links; ?></td>-->
			<td align="center"><?php echo $unique_visitors_click_today; ?></td>
		</tr>
		<tr>
			<td><strong><?php _lang(INDEX_RANGE_WEEK); ?></strong></td>
			<td align="center"><?php echo $click_count_week; ?></td>
			<!--<td align="center"><?php echo $click_count_week_ads . " / " . $click_count_week_links; ?></td>-->
			<td align="center"><?php echo $unique_visitors_click_week; ?></td>
		</tr>
		<tr>
			<td><strong><?php _lang(INDEX_RANGE_OVERALL); ?></strong></td>
			<td align="center"><?php echo $click_count_overall; ?></td>
			<!--<td align="center"><?php echo $click_count_overall_ads . " / " . $click_count_overall_links; ?></td>-->
			<td align="center"><?php echo $unique_visitors_click; ?></td>
		</tr>
	</table>
	<h1 id="report"><?php _lang(INDEX_REPORT); ?></h1>
	<p><?php _lang_index_report_text($click_count_overall); ?></p>
</div>

<?php bodyFooter('index'); ?>