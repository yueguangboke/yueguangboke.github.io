<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
	bodyHeader('visitordata');
	bodyNavigation('visitordata');
require ("./config_database.php");

$id = $_GET['id'];

$query = "SELECT * FROM $db_table_logfiles WHERE id = '$id'";

$result = mysql_query("$query")
		or die(sprintf("Couldn't execute sql_count, %s: %s", db_errno(), db_error()));

while($row = mysql_fetch_array($result)) {
	$date = $row['date'];
	$time = $row['time'];
	$timestamp = $row['timestamp'];
	$visitor_ip = $row["visitor_ip"];
	$visitor_agent = $row["visitor_agent"];
	$adlogger_channel_id = $row["adlogger_channel_id"];
	$displaypage_url = $row["displaypage_url"];
	$ad_targ_url = $row["ad_targ_url"];
	//$ad_format = $row["ad_format"];

	$visitor_hostname = gethostbyaddr($visitor_ip);
}

	if ($ad_targ_url == '') {
		$ad_targ_url = "<em>Unknown</em>";
	}
	//convertAdFormat($ad_format);

$query2 = "SELECT * FROM $db_table_channels WHERE id='$adlogger_channel_id'";

$result2 = mysql_query($query2) or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));

while ($row = mysql_fetch_array($result2)) {
	$chan_name = stripslashes($row["chan_name"]);
	$chan_desc = stripslashes($row["chan_desc"]);
}

// Get visitor performance stats
//Get OVERALL data
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE visitor_ip = '$visitor_ip'");
    $click_count_overall = mysql_num_rows($result);

/*
$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_as' AND visitor_ip = '$visitor_ip'");
    $click_count_overall_ads = mysql_num_rows($result);

$result = mysql_query("SELECT id FROM $db_table_logfiles WHERE ad_format LIKE '%_al%' AND visitor_ip = '$visitor_ip'");
    $click_count_overall_links = mysql_num_rows($result);
*/

?>

<div id="side-bar">
	<div>
		<p class="sideBarTitle">Detailed Visitor Info</p>
		<ul>
			<li><a href="#visitorinfo">&rsaquo; Visitor Information</a></li>
			<li><a href="#stats">&rsaquo; Visitor Statistics</a></li>
			<li><a href="#pageinfo">&rsaquo; Page Information</a></li>
		</ul>
	</div>
</div>

<div id="main-copy">
	<h1 id="visitorinfo">Visitor Information</h1>
	<br />

	<table width="70%" border="1" cellpadding="2" cellspacing="0">
		<tr>
			<td width="30%" valign="top">Date/Time of Click:</td>
			<td width="70%" valign="top"><?php echo $date . " " . $time; ?></td>
		</tr>
		<tr>
			<td valign="top">Visitor IP address:</td>
			<td valign="top"><?php echo $visitor_ip; ?></td>
		</tr>
		<tr>
			<td valign="top">Visitor Hostname:</td>
			<td valign="top"><?php echo $visitor_hostname; ?></td>
		</tr>
		<tr>
			<td valign="top">Visitor Agent Information:</td>
			<td valign="top"><?php echo $visitor_agent; ?></td>
		</tr>
		<tr>
			<td valign="top">Visitor City, State, Country:</td>
			<td valign="top">Click <a href="http://www.dnsstuff.com/tools/city.ch?ip=<?php echo $visitor_ip; ?>" target="_blank">here</a>.</td>
		</tr>
	</table>

	<h1 id="stats">Visitor Statistics</h1>
	<p>Visitor Performance: </p>

	<table width="50%" border="1" cellpadding="0" cellspacing="0">
		<tr>
			<td width="100%" align="center"><strong>Total Clicks</strong></td>
			<!--<td width="50%" align="center"><strong>Clicks for<br />Ads/Link Units</strong></td>-->
		</tr>
		<tr>
			<td align="center"><?php echo $click_count_overall; ?></td>
			<!--<td align="center"><?php echo $click_count_overall_ads . " " . $click_count_overall_links; ?></td>-->
		</tr>
	</table>

	<p>Visitor Clicking History:</p>

	<table width="90%" border="1" cellpadding="1" cellspacing="0">
		<tr>
			<td width="15%" align="center"><strong>Date/Time</strong></td>
			<td width="85%" align="center"><strong>Page</strong></td>
		</tr>
<?php
//Find out every single page that the visitor went to on your site and get the number of page views and clicks for each:

$query3 = "SELECT date, time, displaypage_url FROM $db_table_logfiles WHERE visitor_ip = '$visitor_ip'";

$result3 = mysql_query("$query3")
		or die(sprintf("Couldn't execute sql_count, %s: %s", db_errno(), db_error()));

while($row3 = mysql_fetch_array($result3)) {
	$date = $row3['date'];
	$time = $row3['time'];
	$displaypage_url = $row3["displaypage_url"];

?>
		<tr>
			<td><?php echo $date . " " . $time; ?></td>
			<td><?php echo shortenURL($displaypage_url); ?></td>
		</tr>
		<?php } ?>
	</table>

	<h1 id="pageinfo">Page Information of the Click</h1>
	<br />

	<table width="75%" border="1" cellpadding="1" cellspacing="0">
		<tr>
			<td width="50%">AdLogger Channel ID:</td>
			<td width="50%"><?php echo $adlogger_channel_id; ?></td>
		</tr>
		<tr>
			<td>AdLogger Channel Name: </td>
			<td><?php echo $chan_name; ?></td>
		</tr>
		<tr>
			<td>AdLogger Channel Description: </td>
			<td><?php echo $chan_desc; ?></td>
		</tr>
		<tr>
			<td>Display Page URL:</td>
			<td><a href="<?php echo $displaypage_url; ?>" target="_blank"><?php echo shortenURL($displaypage_url); ?></a></td>
		</tr>
		<tr>
			<td>Ad Target URL:</td>
			<td><?php echo $ad_targ_url; ?></td>
		</tr>
	</table>

<!--	<h1 id="adinfo">Ad Information</h1>

	<table width="75%" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td width="50%">Ad Height:</td>
			<td width="50%"><?php echo $ad_height; ?></td>
		</tr>
		<tr>
			<td>Ad Width:</td>
			<td><?php echo $ad_width; ?></td>
		</tr>
		<tr>
			<td>Ad Target URL:</td>
			<td><?php echo $ad_targ_url; ?></td>
		</tr>
	</table>-->
</div>

<?php bodyFooter('visitordata'); ?>