<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
	bodyHeader('settings');
	bodyNavigation('settings');
require ("./config_database.php");
?>

<div id="side-bar">
	<div>
		<p class="sideBarTitle">Settings</p>
		<ul>
			<li><a href="#channel">&rsaquo; Channel Information</a></li>
			<li><a href="#refigure">&rsaquo; Refigure Stats</a></li>
			<li><a href="#settings">&rsaquo; Script Settings</a></li>
			<li><a href="#admin">&rsaquo; Admin Info</a></li>
			<li><a href="#script">&rsaquo; Script Info</a></li>
		</ul>
	</div>
</div>

<div id="main-copy">

	<?php if (isset($_SESSION['changesuccess'])) { ?>
		<br />
		<span class='changeSettingMessage'>
			<?php echo $_SESSION['changesuccess']; unset($_SESSION['changesuccess']); ?>
		</span>
	<?php } ?>
	
	<h1 id="channel">Channel Information </h1>
	<p>You can use AdLogger's built-in channel tracking to better monitor individual parts of your site without logging into Google AdSense. Note that these channels have no correlation to your official AdSense Channels. These are for unofficial AdLogger reporting only.</p>
	<p>Add a channel:</p>
	<form name="add_channel" action="change.php?go=addchannel" method="post" id="add_channel" onsubmit="return validate_add_channel(this);">
		<table width="95%" border="2" cellpadding="4" cellspacing="0">
			<tr>
				<td width="31%" align="center"><strong>Channel Name</strong></td>
				<td width="48%" align="center"><strong>Channel Description </strong></td>
				<td width="21%" align="center">&nbsp;</td>
			</tr>
			<tr>
				<td align="center" valign="middle"><input name="chan_name" type="text" size="30" />
				</td>
				<td align="center" valign="middle"><input name="chan_desc" type="text" size="50" />
				</td>
				<td align="center" valign="middle"><input type="submit" name="Submit" value="Add Channel" />
				</td>
			</tr>
		</table>
	</form>
	<p>View your current channels:</p>
	<table width="95%" border="2" cellpadding="4" cellspacing="0">
		<tr>
			<td width="31%" align="center"><strong>Channel Name</strong></td>
			<td width="48%" align="center"><strong>Channel Description</strong></td>
			<td width="21%" align="center"><strong>Delete</strong></td>
		</tr>
		<?php $sql = "SELECT * FROM $db_table_channels ORDER BY chan_name";
		$result = mysql_query($sql) or die(sprintf("Couldn't execute query, %s: %s", db_errno(), db_error()));
			
		while($row2 = mysql_fetch_array($result)) {
			$id = stripslashes($row2['id']);
			$chan_name = stripslashes($row2['chan_name']);
			$chan_desc = stripslashes($row2["chan_desc"]);
		?>
		<tr>
			<td align="center" valign="middle"><?php echo $chan_name; ?></td>
			<td align="center" valign="middle"><?php echo $chan_desc; ?></td>
			<td align="center" valign="middle"><input type="button" onclick="confirmationChannel(<?php echo $id; ?>);" value="Delete"></td>
		</tr>
		<?php } ?>
	</table>

	<h1 id="settings">Settings and Preferences</h1>

	<?php
	$chmod = substr(sprintf('%o', fileperms('config_settings.php')), -4);
	if ((!is_writable('./config_settings.php')) || (substr($chmod,2) == "44")) { ?>

		<div align="center"><p><strong>Before changes can be saved, you must CHMOD config_settings.php to 666.</strong></p></div>

	<?php } else { $chmod_verify = 'ok'; ?>
		<br />
	<?php } ?>

	<form name="change_settings" action="change.php?go=changesettings" method="post" id="change_settings" onsubmit="return validate_change_settings(this);">
		<table width="95%" border="2" cellpadding="4" cellspacing="0">
			<tr>
				<td colspan="2" align="center" valign="middle">A visitor can click a maximum of
					<input name="clickmax" type="text" value="<?php echo $clickmax; ?>" size="3" />
					ad(s) every
					<input name="clickmaxtime" type="text" value="<?php echo ($clickmaxtime / 3600); ?>" size="3" />
					hour(s).</td>
			</tr>
			<tr>
				<td valign="middle">Your email address (for click notifications and reseting your password)</td>
				<td align="center" valign="middle"><input name="email" type="text" value="<?php echo $email; ?>" size="30" /></td>
			</tr>
			<tr>
				<td valign="middle">Would you like to receive an email after every reported click?</td>
				<td align="center" valign="middle"><input name="emailnotice" type="radio" value="y" checked="checked" />
					Yes
					<?php if ($email_notice == 'n') {?>
					<input name="emailnotice" type="radio" value="n" checked="checked" />
					<?php } else { ?>
					<input name="emailnotice" type="radio" value="n" />
					<?php } ?>
					No</td>
			</tr>
			<tr>
				<td valign="middle"> Would you like to receive an email after multiple reported clicks?</td>
				<td align="center" valign="middle"><input name="emailalert" type="radio" value="y" checked="checked" />
					Yes
					<?php if ($email_alert == 'n') {?>
					<input name="emailalert" type="radio" value="n" checked="checked" />
					<?php } else { ?>
					<input name="emailalert" type="radio" value="n" />
					<?php } ?>
					No</td>
			</tr>
			<tr>
				<td valign="middle">If yes, after how many reported clicks would you like an email alert?</td>
				<td align="center" valign="middle"><label>
					<input name="emailalert_num" type="text" value="<?php echo $emailalert_num; ?>" size="4" />
					</label></td>
			</tr>
			<tr>
				<td align="left" valign="middle">If your timezone differs from the server of which you host your website on. You can change to your timezone here.</td>
				<td align="center" valign="middle"><?php
			if (!isset($gmt_dif) || $gmt_dif == ""){
				$gmt_dif = "default";
			}
			$gmt_dif = "$gmt_dif";
			$gmt_dif = str_replace("-","_",$gmt_dif);
			$gmt_dif = str_replace(".","d",$gmt_dif);
			$gmt_dif = "ts" . $gmt_dif;
			$$gmt_dif = 'selected="selected"';
			?>
					<select name="timezone">
						<option value="default" <?php echo $default ?>>GMT - Western Europe Time, London, Lisbon, Casablanca</option>
						<option value="-12" <?php echo $ts_12 ?>>(GMT -12:00) Eniwetok, Kwajalein</option>
						<option value="-11" <?php echo $ts_11 ?>>(GMT -11:00) Midway Island, Samoa</option>
						<option value="-10" <?php echo $ts_10 ?>>(GMT -10:00) Hawaii</option>
						<option value="-9" <?php echo $ts_9 ?>>(GMT -9:00) Alaska</option>
						<option value="-8" <?php echo $ts_8 ?>>(GMT -8:00) (Adsense Time!) Pacific Time (US &amp; Canada)</option>
						<option value="-7" <?php echo $ts_7 ?>>(GMT -7:00) Mountain Time (US &amp; Canada)</option>
						<option value="-6" <?php echo $ts_6 ?>>(GMT -6:00) Central Time (US &amp; Canada), Mexico City</option>
						<option value="-5" <?php echo $ts_5 ?>>(GMT -5:00) Eastern Time (US &amp; Canada), Bogota, Lima</option>
						<option value="-4" <?php echo $ts_4 ?>>(GMT -4:00) Atlantic Time (Canada), Caracas, La Paz</option>
						<option value="-3.5" <?php echo $ts_3d5 ?>>(GMT -3:30) Newfoundland</option>
						<option value="-3" <?php echo $ts_3 ?>>(GMT -3:00) Brazil, Buenos Aires, Georgetown</option>
						<option value="-2" <?php echo $ts_2 ?>>(GMT -2:00) Mid-Atlantic</option>
						<option value="-1" <?php echo $ts_1 ?>>(GMT -1:00 hour) Azores, Cape Verde Islands</option>
						<option value="0" <?php echo $ts0 ?>>(GMT) Western Europe Time, London, Lisbon, Casablanca</option>
						<option value="1" <?php echo $ts1 ?>>(GMT +1:00) Brussels, Copenhagen, Madrid, Paris, Stockholm</option>
						<option value="2" <?php echo $ts2 ?>>(GMT +2:00) Kaliningrad, South Africa</option>
						<option value="3" <?php echo $ts3 ?>>(GMT +3:00) Baghdad, Riyadh, Moscow, St. Petersburg</option>
						<option value="3.5" <?php echo $ts3d5 ?>>(GMT +3:30) Tehran</option>
						<option value="4" <?php echo $ts4 ?>>(GMT +4:00) Abu Dhabi, Muscat, Baku, Tbilisi</option>
						<option value="4.5" <?php echo $ts4d5 ?>>(GMT +4:30) Kabul</option>
						<option value="5" <?php echo $ts5 ?>>(GMT +5:00) Ekaterinburg, Islamabad, Karachi, Tashkent</option>
						<option value="5.5" <?php echo $ts5d5 ?>>(GMT +5:30) Bombay, Calcutta, Madras, New Delhi</option>
						<option value="6" <?php echo $ts6 ?>>(GMT +6:00) Almaty, Dhaka, Colombo</option>
						<option value="7" <?php echo $ts7 ?>>(GMT +7:00) Bangkok, Hanoi, Jakarta</option>
						<option value="8" <?php echo $ts8 ?>>(GMT +8:00) Beijing, Perth, Singapore, Hong Kong</option>
						<option value="9" <?php echo $ts9 ?>>(GMT +9:00) Tokyo, Seoul, Osaka, Sapporo, Yakutsk</option>
						<option value="9.5" <?php echo $ts9d5 ?>>(GMT +9:30) Adelaide, Darwin</option>
						<option value="10" <?php echo $ts10 ?>>(GMT +10:00) Eastern Australia, Guam, Vladivostok</option>
						<option value="11" <?php echo $ts11 ?>>(GMT +11:00) Magadan, Solomon Islands, New Caledonia</option>
						<option value="12" <?php echo $ts12 ?>>(GMT +12:00) Auckland, Wellington, Fiji, Kamchatka</option>
					</select></td>
			</tr>
			<tr>
				<td valign="middle"> Should the script check against the database to determine if it should show ads? (If no, the script will rely only  banned IP addresses/ranges to determine if it should show ads. If yes, the script will check to see if any clicks came from the visitor's IP recently.)</td>
				<td align="center" valign="middle">
					<input name="ip_db_check" type="radio" value="y" checked="checked" />Yes
					<input name="ip_db_check" type="radio" value="n" <?php if ($ip_db_check == 'n') echo "checked=\"checked\""; ?> />No
				</td>
			</tr>
			<tr>
				<td valign="middle">Banned IPs and IP ranges. Ads will not appear for the IP addresses/ranges that you enter. (eg: 192.168.0.1 and	213.94.). Separate by new line.<br />If you have a static IP address, you can enter <?php echo $_SERVER['REMOTE_ADDR']; ?> (your IP) to disable ads for yourself.</td>
				<td align="center" valign="middle">
					<textarea name="bannedips" rows="5" cols="30"><?php
					foreach($ip_range_ban_list as $i => $ip){
						if ($i != 0) {
							$bannedstring .= "\n";
						}
						$bannedstring .= "$ip";
					}
					echo $bannedstring;
					?></textarea>
				</td>
			</tr>
			<tr>
				<td valign="middle">Would you like to disable ads for everyone? This is an easy way if you ever want to turn off all of your ads for some reason.<br />All ads surrounded by the PHP Wrapping Code will not appear and will show the alternate ad, if specified.</td>
				<td align="center" valign="middle">
					<input name="disable_all_ads" type="radio" value="y" checked="checked" />
					Yes
					<?php if ($disable_all_ads == 'n') {?>
					<input name="disable_all_ads" type="radio" value="n" checked="checked" />
					<?php } else { ?>
					<input name="disable_all_ads" type="radio" value="n" />
					<?php } ?>
					No
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center">
					<?php if ($chmod_verify == 'ok') { ?>
						<input type="hidden" name="login_hash" value="<?php echo $login_hash; ?>" />
						<input type="hidden" name="version_num" value="<?php echo $version_num; ?>" />
						<input type="submit" name="Submit2" value="Update" />
					<?php } else { 
						echo '<strong>Changes cannot be saved at this time. You must CHMOD config_settings.php to writable status (666).</strong>';
					} ?>
				</td>
			</tr>
		</table>
	</form>
		
	<h1 id="refigure">Refigure Log Files</h1>
	<p>If you have ads blocked for yourself and don't want those statistics to appear on the Blocked Info page, you can delete yourself from the blocked log files.
	<form name="drop_yourself" action="change.php?go=dropyourself_block" method="post" onsubmit="return validate_drop_yourself(this);">
		<table width="95%" border="2" cellpadding="4" cellspacing="0">
			<tr>
				<td width="80%" align="center" valign="middle">IP address that you would like dropped from the blocked logs: <input name="ip_delete" type="text" value="<?php echo visitorIP(); ?>" size="15" maxlength="15" /></td>
				<td width="20%" align="center" valign="middle"><input type="submit" name="Submit" value="Delete" /></td>
			</tr>
		</table>
	</form>
	<p>Alternatively, you can choose to delete ALL log entries from your database. It will reset all of your statistics back to &quot;0&quot;. This cannot be undone.</p>
	<form action="" method="get">
		<table width="95%" border="2" cellpadding="4" cellspacing="0">
			<tr>
				<td width="80%" align="center" valign="middle">Delete all logs? (Important: This can <strong>NOT</strong> be undone!)</td>
				<td width="20%" align="center" valign="middle"><input type="submit" value="Delete" onclick="confirmationDelLogs();" /></td>
			</tr>
		</table>
	</form>

	<h1 id="admin">Admin Information</h1>
	<p>Change Username and Password:</p>
	<form name="change_user_pass" action="change.php?go=userpass" method="post" onsubmit="return validate_change_user_pass(this);">
		<table width="95%" border="2" cellpadding="4" cellspacing="0">
			<tr>
				<td width="25%" align="center" valign="middle"><strong>
					<label>Username</label>
					</strong></td>
				<td width="25%" align="center" valign="middle"><strong>New Password</strong></td>
				<td width="25%" align="center" valign="middle"><strong>Confirm New Password </strong></td>
				<td width="25%" align="center" valign="middle">&nbsp;</td>
			</tr>
			<tr>
				<td align="center" valign="middle"><input name="user" type="text" size="30" /></td>
				<td align="center" valign="middle"><input name="password1" type="password" size="30" /></td>
				<td align="center" valign="middle"><input name="password2" type="password" size="30" /></td>
				<td align="center" valign="middle"><input type="submit" name="Submit" value="Update" /></td>
			</tr>
		</table>
	</form>
	<h1 id="script"> Script and Database Information</h1>
	<p>Your current script settings are listed here:</p>
	<table width="80%" border="2" cellpadding="4" cellspacing="0">
		<tr>
			<td width="25%" align="center" valign="middle"><strong>Name</strong></td>
			<td width="75%" align="center" valign="middle"><strong>Value</strong></td>
		</tr>
		<tr>
			<td align="center" valign="middle">Version</td>
			<td align="center" valign="middle"><?php echo $version_num; ?></td>
		</tr>
		<tr>
			<td align="center" valign="middle">Site URL</td>
			<td align="center" valign="middle"><?php echo $siteurl; ?></td>
		</tr>
		<tr>
			<td align="center" valign="middle">AdLogger Location</td>
			<td align="center" valign="middle"><?php echo $adlogger_loc; ?></td>
		</tr>
		<tr>
			<td align="center" valign="middle">AdLogger Doc Path</td>
			<td align="center" valign="middle"><?php echo $adlogger_doc_path; ?></td>
		</tr>
	</table>
	<p>Your current database connection settings  were setup when you installed the script. As of now, the only way to change these is by opening config_database.php with an editor and changing the values.</p>
</div>

<?php bodyFooter('settings'); ?>