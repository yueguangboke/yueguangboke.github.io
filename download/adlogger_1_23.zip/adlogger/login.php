<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

session_start();

if ($_SESSION['adminglog'] == "y") {
	header("Location: ./");
	exit();
}

require ("./functions.php");
	micro_time('start');
	bodyHeader('login');
	bodyNavigation('login');

require ("./config_database.php");
require ("./config_settings.php");

?>

<div id="main-copy">
	<h1 id="introduction">Login</h1>
	<p>Enter your username and password to monitor your stats.</p>
			
				<?php
					if (is_dir('install')) {
						echo "<span class=\"loginMessage\">Please delete the install directory for security reasons before continuing.</span><br /><br />";
					}
					$chmod = substr(sprintf('%o', fileperms('config_database.php')), -4);
					if (substr($chmod,2) != "44") {
						echo "<span class=\"loginMessage\">Please CHMOD config_database.php back to 644 before continuing.</span><br /><br />";
					}
					if (isset($_SESSION['login_message'])) {
						echo "<span class=\"loginMessage\">" . $_SESSION['login_message'] . "</span><br /><br />";
						unset($_SESSION['login_message']);
					}
				?>
			
	<form name="loginform" method="post" action="./logincheck.php">
		<table width="35%"	 border="1" cellpadding="2" cellspacing="0">
			<tr>
				<td width="50%"><strong>Username</strong></td>
				<td width="50%"><input name="username" type="text" size="25" id="loginbox"></td>
			</tr>
			<tr>
				<td><strong>Password</strong></td>
				<td><input name="password" type="password" size="25"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><strong>Remember me?</strong>
					<label>
					<input name="remember" type="checkbox" id="remember" value="checkbox" />
					</label></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="Submit" value="Login">
					<br />
					<a href="./pwreset.php">Forget your password?</a></td>
			</tr>
		</table>
	</form>
</div>

<?php bodyFooter('login'); ?>
