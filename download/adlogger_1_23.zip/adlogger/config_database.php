<?php
/*
This will get replaced with database connection
info and script settings after installation.
*/
?>