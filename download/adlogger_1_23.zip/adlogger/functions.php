<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

// For displaying the load time for each page.  Shown in the footer.
function micro_time($where) {
	global $micro_time, $micro_time_start, $micro_time_end;
	list($usec, $sec) = explode(" ", microtime());
	$micro_time = ((float)$usec + (float)$sec);
	if ($where == 'start') {
		$micro_time_start = $micro_time;
		return $micro_time_start;
	} elseif ($where == 'end') {
		echo ($micro_time - $micro_time_start);
	} else {
		return "unknown";
	}
}

// Global header for each page
function bodyHeader($page) { ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<link rel="stylesheet" type="text/css" href="<?php if ($page == 'install') echo "."; ?>./styles/sinorca-screen.css" media="screen" title="Sinorca (screen)">
<link rel="stylesheet alternative" type="text/css" href="<?php if ($page == 'install') echo "."; ?>./styles/sinorca-screen-alt.css" media="screen" title="Sinorca (alternative)">
<link rel="stylesheet" type="text/css" href="<?php if ($page == 'install') echo "."; ?>./styles/sinorca-print.css" media="print">
<?php if (($page == 'archive') || ($page == 'best')) { ?>
<link href="./styles/CalendarControl.css" rel="stylesheet" type="text/css">
<?php } ?>
<?php if ($page == 'install') { ?>
<title>AdLogger Install</title>
<?php } else { ?>
<title>AdLogger Admin</title>
<?php } 
if ($page == 'settings') { ?>
<script type="text/javascript">
	<!--
		function confirmationChannel(channel_drop_id) {
			var answer = confirm("Are you sure you want to delete that channel?")
			if (answer){
				window.location = "change.php?go=dropchannel&id=" + channel_drop_id;
			}
		}
		function confirmationDelLogs() {
			var answer = confirm("Are you sure you want to delete all of your logs?")
			if (answer){
				window.location = "change.php?go=Delete";
			}
		}
		function validate_add_channel() {
			var theMessage = "Please complete the following: \n-----------------------------------\n";
			var noErrors = theMessage;
	
			if (document.add_channel.chan_name.value=="") {
				theMessage = theMessage + "\n --> Channel Name";
			}

			if (theMessage == noErrors) {
				return true;
			} else {
				alert(theMessage);
				return false;
			}
		}

		function validate_change_settings() {
			var theMessage = "Please complete the following: \n-----------------------------------\n";
			var noErrors = theMessage;
	
			if (document.change_settings.email.value=="") {
				theMessage = theMessage + "\n --> Email Address";
			}
	
			if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(document.change_settings.email.value)){
				theMessage = theMessage + "\n --> Enter a valid e-mail address";
			}
	
			if (document.change_settings.emailalert_num.value=="") {
				theMessage = theMessage + "\n --> Email alert number";
			}
	
			if (theMessage == noErrors) {
				return true;
			} else {
				alert(theMessage);
				return false;
			}
		}

		function validate_drop_yourself() {
			var theMessage = "Please complete the following: \n-----------------------------------\n";
			var noErrors = theMessage;
	
			if (document.drop_yourself.ip_delete.value=="") {
				theMessage = theMessage + "\n --> IP Address to Drop";
			}

			if (theMessage == noErrors) {
				return true;
			} else {
				alert(theMessage);
				return false;
			}
		}

		function validate_change_user_pass() {
			var theMessage = "Please complete the following: \n-----------------------------------\n";
			var noErrors = theMessage;
	
			if (document.change_user_pass.user.value=="") {
				theMessage = theMessage + "\n --> New Username";
			}
			
			if (document.change_user_pass.password1.value=="") {
				theMessage = theMessage + "\n --> New Password";
			}
			
			if (document.change_user_pass.password2.value=="") {
				theMessage = theMessage + "\n --> Password Confirmation";
			}

			if (theMessage == noErrors) {
				return true;
			} else {
				alert(theMessage);
				return false;
			}
		}
	//-->
</script>
<?php } elseif ($page == 'install') { ?>
<script type="text/javascript">
	<!-- Begin
		function validate_step_2() {
		
		var theMessage = "Please complete the following: \n-----------------------------------\n";
		var noErrors = theMessage;
		
		// make sure field is not blank
		if (document.install_step_2.db_host.value=="") {
		theMessage = theMessage + "\n --> Database Host";
		}
		
			// make sure field is not blank
		if (document.install_step_2.db_port.value=="") {
		theMessage = theMessage + "\n --> Database Port";
		}
		
				// make sure field is not blank
		if (document.install_step_2.db_user.value=="") {
		theMessage = theMessage + "\n --> Database Username";
		}
		
				// make sure field is not blank
		if (document.install_step_2.db_pass.value=="") {
		theMessage = theMessage + "\n --> Database Password";
		}
		
					// make sure field is not blank
		if (document.install_step_2.db_name.value=="") {
		theMessage = theMessage + "\n --> Database Name";
		}
		
					// make sure field is not blank
		if (document.install_step_2.db_table_prefix.value=="") {
		theMessage = theMessage + "\n --> Database Prefix";
		}
		
					// make sure field is not blank
		if (document.install_step_2.siteurl.value=="") {
		theMessage = theMessage + "\n --> Your Site URL";
		}
		
		// make sure field is not blank
		if (document.install_step_2.adlogger_loc.value=="") {
		theMessage = theMessage + "\n --> AdLogger Directory Location";
		}
		
			// make sure field is not blank
		if (document.install_step_2.adlogger_doc_path.value=="") {
		theMessage = theMessage + "\n --> AdLogger Server Document Path";
		}
		
		// If no errors, submit the form
		if (theMessage == noErrors) {
		return true;
		
		} else {
		
		// If errors were found, show alert message
		alert(theMessage);
		 return false;
		}
		}
		
		function validate_step_3() {
		
		var theMessage = "Please complete the following: \n-----------------------------------\n";
		var noErrors = theMessage;
		
		// make sure field is not blank
		if (document.install_step_3.username.value=="") {
		theMessage = theMessage + "\n --> Username";
		}
		
			// make sure field is not blank
		if (document.install_step_3.password1.value=="") {
		theMessage = theMessage + "\n --> Password";
		}
		
				// make sure field is not blank
		if (document.install_step_3.email.value=="") {
		theMessage = theMessage + "\n --> Email Address";
		}
		
		// validate an e-mail address
		if (!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/.test(document.install_step_3.email.value)){
		theMessage = theMessage + "\n --> Enter a valid e-mail address";
		}
		
		// If no errors, submit the form
		if (theMessage == noErrors) {
		return true;
		
		} else {
		
		// If errors were found, show alert message
		alert(theMessage);
		 return false;
		}
		}
	// End -->
</script>
<?php } ?>
</head>
<?php }

// Top navigation for underneath the header
function bodyNavigation($page) {

if ($page == 'login') {
   echo '<body onload="document.getElementById(\'loginbox\').focus();">';
} else {
   echo '<body>';
}

if (($page == 'archive') || ($page == 'best')) { ?>

	<script type="text/javascript" src="./CalendarControl.js" language="javascript"></script>

<?php } ?>

<div id="top"><a href="#main-copy" class="doNotDisplay doNotPrint">Skip to main content.</a></div>
<div id="header">
	<div class="superHeader">
		<div class="right"> | <a href="./logout.php">Logout</a> | </div>
	</div>
	<div class="midHeader">
		<?php if ($page == 'install') { ?>
		<h1 class="headerTitle">AdLogger Installation</h1>
		<?php } else { ?>
		<h1 class="headerTitle">AdLogger Admin Page</h1>
		<?php } ?>
	</div>
	<div class="subHeader"><?php if ($page != 'install') { ?><span class="doNotDisplay">Navigation:</span> <a href="./">Performance Overview</a> | <a href="./archive.php">Archive Data </a> | <a href="./best.php">Performance Data </a> | <a href="./clickinfo.php">Click Info </a> | <a href="./blockinfo.php">Blocked Info </a> | <a href="./codegen.php">Code Generators</a>| <a href="./settings.php">Settings</a> | <a href="./support.php">Support</a><?php } ?></div>
</div>
<?php }

// Global footer for each page.
function bodyFooter($page) { ?>
<div id="footer">
	<div class="left">Page generated in <?php micro_time('end'); ?> seconds.<br /><a href="http://www.adlogger.org/">http://www.adlogger.org/</a></div>
	<div class="right">Copyright &copy; 2006 <a href="http://www.adlogger.org/">AdLogger</a> and <a href="http://www.trevorfitzgerald.com/">Trevor Fitzgerald</a>. All rights reserved.<br />AdLogger is provided under the GNU General Public License.</div>
</div>
</body>
</html><?php }

// Get IP address (this function also located in trackclick.php)
function visitorIP() {
	$ipParts = explode(".", $_SERVER['REMOTE_ADDR']);
	if ($ipParts[0] == "165" && $ipParts[1] == "21") {    
    	if (getenv("HTTP_CLIENT_IP")) {
        	$ip = getenv("HTTP_CLIENT_IP");
        } elseif (getenv("HTTP_X_FORWARDED_FOR")) {
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        } elseif (getenv("REMOTE_ADDR")) {
            $ip = getenv("REMOTE_ADDR");
        }
    } else {
       return $_SERVER['REMOTE_ADDR'];
   	}
   	return $ip;
}


function shortenURL($shortenlink) {
	if (strlen($shortenlink) > 55) {
		$shortenlink = substr($shortenlink, 0, 18) . '...' . substr($shortenlink, -32);
	} elseif ($shortenlink == '') {
		$shortenlink = "Unknown";
	}
	return $shortenlink;
}

/*
function convertAdFormat($ad_format) {
	global $ad_width, $ad_height;
	// Convert Ad Format into height and width
	// Get position of the "x" and "_"
	$explodex = 'x';
	$explode_ = '_';
	$posx = strpos($ad_format, $explodex);
	$pos_ = strpos($ad_format, $explode_);
	$dif = $pos_ - $posx - 1;
	// Using the position of x and _, find the values in between
	$ad_width = substr($ad_format, 0, $posx);
	$ad_height = substr($ad_format, ($posx + 1), $dif);
}
*/

// Create a random password for when people forget their password and need it reset.
function createRandomString($characters) {
    $chars = "abcdefghijkmnpqrstuvwxyz23456789ABCDEFGHJKLMNPQRSTUVWXYZ";
    srand((double)microtime()*1000000);
    $i = 0;
    $pass = '' ;
    while ($i <= $characters) {
        $num = rand() % 56;
        $tmp = substr($chars, $num, 1);
        $pass = $pass . $tmp;
        $i++;
    }
    return $pass;
}

// The next 3 functions are for update notifications.
function url_exists($url) {
	$handle = @fopen($url, "r");
	if ($handle === false)
		return false;
	fclose($handle);
	return true;
}
function adlogger_update_check($version_num) {
	if (url_exists("http://www.adlogger.org/updatecheck.php")) {
		$adlogger_update_status = @file_get_contents("http://www.adlogger.org/updatecheck.php?version=$version_num");
		print $adlogger_update_status;
    }
}
?>