<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./config_database.php");

$ref = "./settings.php";
$go = $_GET['go'];

if ($go == "addchannel") {

	$chan_name = mysql_real_escape_string(($_POST['chan_name']));
	$chan_desc = mysql_real_escape_string(($_POST['chan_desc']));
	
	if (empty($chan_name)) {
			$_SESSION['changesuccess'] = "Error: Please enter a channel name.";
			header("Location: " . $ref);
			exit();
	}
	
	mysql_query("INSERT INTO $db_table_channels
		SET 
		chan_name='$chan_name',
		chan_desc='$chan_desc'
	")
	or die(mysql_error());
	$_SESSION['changesuccess'] = "The channel, " . stripslashes($_POST['chan_name']) . ", has been added successfully.";

} elseif ($go == "setcookie") {

	setcookie("durelog", 100, time()+32000000, "/");
	$_SESSION['changesuccess'] = "You have successfully disabled ads for yourself.";

} elseif ($go == "unsetcookie") {

	setcookie ("durelog", "", time()-32000000, "/");
	$_SESSION['changesuccess'] = "You have successfully enabled ads for yourself.";

} elseif ($go == "dropchannel") {

	$channel_id = $_GET['id'];
	mysql_query("DELETE FROM $db_table_channels WHERE id='$channel_id'")
	or die(mysql_error());
	$_SESSION['changesuccess'] = "Your channel has been deleted successfully.";

} elseif ($go == "userpass") {

	$user = $_POST['user'];
	$password1 = $_POST['password1'];
	$password2 = $_POST['password2'];

	if ((empty($user)) || (empty($password1)) || (empty($password2))) {
			$_SESSION['changesuccess'] = "Error: Please fill out all fields (Username, Password, and Password Confirmation) to change your username/password.";
			header("Location: " . $ref);
			exit();
	}

	$password_hash = sha1($password1);

		if ($password1 == $password2 && $user != '' && $password1 != '') {
			mysql_query("UPDATE $db_table_users SET
			username='$user',
			password='$password_hash'
			")
			or die(mysql_error());
			$_SESSION['changesuccess'] = "Your username/password has been changed successfully.";
		} else {
			$_SESSION['changesuccess'] = "Unable to change the username and password. Please fill out all fields.";
			header("Location: " . $ref);
			exit();
		}

} elseif ($go == "changesettings") {

$email = $_POST['email'];
$emailnotice = $_POST['emailnotice'];
$emailalert = $_POST['emailalert'];
$emailalert_num = $_POST['emailalert_num'];
$clickmax = $_POST['clickmax'];
$clickmaxtime = $_POST['clickmaxtime'];
$gmtdifference = $_POST['timezone'];
$ip_db_check = $_POST['ip_db_check'];
$bannedips = $_POST['bannedips'];
$login_hash = $_POST['login_hash'];
$version_num = $_POST['version_num'];
$disable_all_ads = $_POST['disable_all_ads'];
$bannedips = preg_split('/[\\s]+/', $bannedips);
$bannedstring = "";
foreach($bannedips as $i => $ip){
	if ($i != 0) {
		$bannedstring .= ",\n";
	}
	$bannedstring .= "\"$ip\"";
}

// Make sure that the email address is valid
if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email)) {
	$_SESSION['changesuccess'] = "Error: Please enter a valid email address.";
	header("Location: " . $ref);
	exit();
}

// Make sure that clickmax, clickmaxtime, and emailalert_num are numerical
if (($clickmax != '' && !is_numeric($clickmax)) || ($clickmaxtime != '' && !is_numeric($clickmaxtime)) || ($emailalert_num != '' && !is_numeric($emailalert_num))) {
	$_SESSION['changesuccess'] = "Error: Invalid entry for numerical value.";
	header("Location: " . $ref);
	exit();
}

if ($clickmax == '') $clickmax = 99;
if ($clickmaxtime == '') $clickmaxtime = 1;
if ($emailalert_num == '') $emailalert_num = 5;

//add variables to config_settings.php
$newfile = fopen("./config_settings.php", "w");

if (!$newfile) {
	echo "config_settings.php was unable to be opened.  Verify that permissions are set to 666.";
	exit();
}

$file_contents = <<<EOD
<?php
/*/////////////////////////////////////////////////////
You can change these through your administration panel.
*//////////////////////////////////////////////////////

\$email = "$email"; // Your email address for notifications and lost password

\$email_notice = "$emailnotice"; // Notice on every click? (y or n)

\$email_alert = "$emailalert"; // Alert on multiple click? (y or n)

\$emailalert_num = $emailalert_num; // Alert after this many clicks

\$clickmax = "$clickmax"; // Number of clicks allowed per visitor

\$clickmaxtime = $clickmaxtime * 3600; // Time in which that visitor can click those ads (in seconds)

\$gmt_dif = "$gmtdifference"; // Your timezone difference from GMT

putenv("TZ=Europe/London");
\$timestamp = time() + 60*60*(\$gmt_dif); // Better correct the time already

\$ip_db_check = "$ip_db_check"; // If using the PHP wrapping code, should the script check the visitor's IP against the database?

\$ip_range_ban_list = array(
$bannedstring
);

\$disable_all_ads = "$disable_all_ads";

\$login_hash = "$login_hash";

\$version_num = '$version_num';

?>
EOD;

fwrite($newfile, "$file_contents");
fclose($newfile);

// End of writing config_settings.php file
//

$_SESSION['changesuccess'] = "You have successfully updated your script settings.";


} elseif ($go == "Delete") {

	mysql_query("DELETE FROM $db_table_logfiles")
		or die(mysql_error());
	$num_rows1 = mysql_affected_rows();
	mysql_query("DELETE FROM $db_table_adblock")
		or die(mysql_error());
	$num_rows2 = mysql_affected_rows();
	$num_rows = $num_rows1 + $num_rows2;
	$_SESSION['changesuccess'] = "You have successfully deleted $num_rows log entries.";

	mysql_query("ALTER TABLE $db_table_logfiles AUTO_INCREMENT = 1")
		or die(mysql_error());
	mysql_query("ALTER TABLE $db_table_adblock AUTO_INCREMENT = 1")
		or die(mysql_error());

} elseif ($go == "dropyourself_block") {

	$ip_delete = $_POST['ip_delete'];

	if (empty($ip_delete)) {
			$_SESSION['changesuccess'] = "Error: Please enter an IP address to delete.";
			header("Location: " . $ref);
			exit();
	}

	mysql_query("DELETE FROM $db_table_adblock WHERE visitor_ip='$ip_delete'")
	or die(mysql_error());
	$num_rows = mysql_affected_rows();
	$_SESSION['changesuccess'] = "You have successfully deleted $num_rows instances of $ip_delete from your block logs.";

} else {

	echo "<h1>Error: No action has been specified.</h1>";
	exit();

}
header("Location: " . $ref);
exit();
?>