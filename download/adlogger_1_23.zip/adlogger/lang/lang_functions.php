<?php
require_once ("./lang/en/index.php");

function _lang($translate_string) {
	echo $translate_string;
}

function _lang_index_report_text($click_count_overall) {
	$translate_string = sprintf(INDEX_REPORT_TEXT, $click_count_overall, $click_count_overall, $click_count_overall_ads, $click_count_overall_links);
	echo $translate_string;
}
?>