<?php
/*
Language: English
Translation by: Trevor Fitzgerald
Translated on: September 8, 2006
*/
/*
//Header
define("HEADER_ADMIN_PAGE", "Admin Page"); //As in "AdLogger Admin Page"
define("HEADER_LOGOUT", "Logout");
define("HEADER_META_TITLE", "Admin"); //As in "AdLogger Admin"

//Navigation
define("NAV_PERF_OV", "Performance Overview");
define("NAV_ARCHIVE", "Archive Data");
define("NAV_PERF_DATA", "Performance Data");
define("NAV_CLICK_INFO", "Click Info");
define("NAV_BLOCK_INFO", "Blocked Info");
define("NAV_CODE_GEN", "Code Generator");
define("NAV_SETTINGS", "Settings");
define("NAV_SUPPORT", "Support");

//Footer
define("FOOT_TIMING", "Page generated in %s seconds."); //%s
define("FOOT_COPYRIGHT", "Copyright &copy; 2006 AdLogger and Trevor Fitzgerald. All rights reserved.");
define("FOOT_LICENSE", "AdLogger is provided under the GNU General Public License.");
*/
//Index Page (Performance Overview)
define("INDEX_VERSION_INFO", "Version Info");
define("INDEX_OVERVIEW", "Overview");
define("INDEX_REAL_TIME_STATS", "Real-Time Statistics");
define("INDEX_TOTAL_CLICKS", "Total Clicks");
define("INDEX_CLICKS_ADS_LINKS", "Clicks for<br />Ads/Link Units");
define("INDEX_UNIQUE_CLICKS", "Unique Visitors That Clicked");
define("INDEX_RANGE_TODAY", "Today");
define("INDEX_RANGE_WEEK", "This Week");
define("INDEX_RANGE_OVERALL", "Overall");
define("INDEX_REPORT", "Report");
define("INDEX_REPORT_TEXT", "AdLogger has reported a total of %s clicks. This includes the number of clicks on ad units as well as link units. You may or may not have registered that many clicks on your official account page, but that is the approximate number of click-throughs that AdLogger recorded for each format. Your official account will not record a click on link units unless a click is made on the subsequent ad page."); //%s
//You must call each of the variables in this order: 1) $click_count_overall 2) $click_count_overall 3) $click_count_overall_ads 4) $click_count_overall_links
/*

//Archive Data Page
define("ARC_ARC_DATA", "Archive Data");
define("ARC_PAST_PREF", "Past Performance Preferences");
define("ARC_STATS", "Archive Statistics");
define("ARC_CLICKS", "Archived Clicks");
define("ARC_VIEW_SINGLE", "View performance statistics for %s"); //%s
define("ARC_VIEW_RANGE", "View performance statistics from %s through %s"); //%s
define("ARC_SORT_BUTTON", "Sort");
define("ARC_TOT_CLICKS", "Total Clicks");
define("ARC_AD_LINK_CLICKS", "Clicks for<br>Ads/Link Units");
define("ARC_UNIQUE_CLICKS", "Unique Visitors That Clicked");
define("ARC_CLICK_ID", "Click ID");
define("ARC_DATE_TIME", "Date/Time");
define("ARC_IP_ADDR", "IP Address");
define("ARC_DISP_PAGE", "Display Page URL");

//Performance Data Page
define("PD_PERF_DATA", "Performance Data");
define("PD_DATA_PREF", "Performance Data Preferences");
define("PD_FORM_TEXT", "View the %s %s %s for %s"); //%s
define("PD_FORM_BEST", "Best");
define("PD_FORM_WORST", "Worst");
define("PD_FORM_PAGES", "Pages");
define("PD_FORM_CHANNELS", "Channels");
define("PD_FORM_VISITORS", "Visitors");
define("PD_FORM_DAYS", "Days");
define("PD_FORM_SORT", "Sort");
define("PD_FOOTNOTE_1", "* Leave date blank to search all records.");
define("PD_FOOTNOTE_2", "** \"Worst\" does not include pages with 0 clicks because they don't exist in the database yet.");
define("PD_PERF_DATA_TABLE", "Performance Data");
define("PD_CRITERIA_VALUE", "Criteria Value");
define("PD_CLICKS", "Clicks");

//Performance Data Page
define("CI_CLICK_INFO", "Click Info");
define("CI_VIEW_PREF", "View Preferences");
define("CI_SORT_PREF", "Choose your sorting preferences.");
define("CI_SORT_FORM", "View %s clicks sorted by %s in %s order.");
define("CI_SORT_DATE_TIME", "Date/Time");
define("CI_SORT_DISP_URL", "Display Page URL");
define("CI_SORT_DESC", "Descending");
define("CI_SORT_ASC", "Ascending");
define("CI_SORT_BUTTON", "Sort");
define("CI_CLICK_INFORMATION", "Click Information");
define("CI_TBL_CLICK_ID", "Click ID");
define("CI_TBL_DATE_TIME", "Date/Time");
define("CI_TBL_IP_ADDR", "IP Address");
define("CI_TBL_DISP_PAGE", "Display Page URL");

//Blocked Info
define("BLOCK_INFO", "Blocked Information");
define("BLOCK_ADS", "View Preferences");
define("BLOCK_TBL_INFO", "Choose your sorting preferences.");
define("BLOCK_TBL_BLOCKS", "View %s clicks sorted by %s in %s order.");
define("BLOCK_TBL_UNIQUE", "Date/Time");
define("BLOCK_TBL_TODAY", "View %s clicks sorted by %s in %s order.");
define("BLOCK_TBL_WEEK", "Date/Time");
define("BLOCK_TBL_OVERALL", "Display Page URL");
define("BLOCK_RECENT", "Recent Blocks");
define("BLOCK_TBL_IP", "IP Address");
define("BLOCK_TBL_BLOCK_NUM", "Number of Blocks");
define("BLOCK_TBL_MORE_INFO", "More Info");
*/

?>