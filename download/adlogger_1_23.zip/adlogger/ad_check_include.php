<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

error_reporting(0);

$adlogger_file_path = str_replace("ad_check_include.php", "", __FILE__);

require ("$adlogger_file_path" . "config_database.php");
require ("$adlogger_file_path" . "config_settings.php");

function visitorIP() {
	$ipParts = explode(".", $_SERVER['REMOTE_ADDR']);
	if ($ipParts[0] == "165" && $ipParts[1] == "21") {    
		if (getenv("HTTP_CLIENT_IP")) {
			$ip = getenv("HTTP_CLIENT_IP");
		} elseif (getenv("HTTP_X_FORWARDED_FOR")) {
			$ip = getenv("HTTP_X_FORWARDED_FOR");
		} elseif (getenv("REMOTE_ADDR")) {
			$ip = getenv("REMOTE_ADDR");
		}
	} else {
		return $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}

$visitor_ip = visitorIP();

$test_done = 'n';

if ($disable_all_ads == 'y') {
	$show_ads = 'n';
	$test_done = 'y';
	$reason = 4;
}

if ($test_done != 'y') {
	foreach ($ip_range_ban_list as $ip_range_ban) {
		if (preg_match('/\\A' . $ip_range_ban . '/', $visitor_ip) && $ip_range_ban != "") {
			$show_ads = 'n';
			$test_done = 'y';
			$reason = 2;
			break;
		}
	}
}

if ($test_done != 'y' && $ip_db_check == 'y') {
	$backlog_timeframe = $timestamp - $clickmaxtime;

	$result = mysql_query("SELECT visitor_ip FROM $db_table_logfiles WHERE visitor_ip = '$visitor_ip' AND timestamp > '$backlog_timeframe' LIMIT $clickmax");
	$visitors_recent_clicks = mysql_num_rows($result);

	if ($visitors_recent_clicks >= $clickmax) {
		$show_ads = 'n';
		$test_done = 'y';
		$reason = 3;
	}
}

if ($show_ads == 'n') {
	$date = date('Y-m-d', $timestamp);
	$time = date('G:i:s', $timestamp);
	mysql_query("INSERT INTO $db_table_adblock SET
		date='$date',
		time='$time',
		visitor_ip='$visitor_ip',
		reason='$reason'
	")
	or die(mysql_error());
}

if ($test_done != 'y') $show_ads = 'y';
?>