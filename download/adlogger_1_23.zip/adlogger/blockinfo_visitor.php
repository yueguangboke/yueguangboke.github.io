<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
	bodyHeader('blockinfoVisitor');
	bodyNavigation('blockinfoVisitor');
require ("./config_database.php");

$visitor_ip = $_GET['visitor_ip'];

$result = mysql_query("SELECT id FROM $db_table_adblock WHERE visitor_ip = '$visitor_ip'");
    $block_count_visitor = mysql_num_rows($result);
?>

<div id="side-bar">
	<div>
		<p class="sideBarTitle">Blocking Info</p>
		<ul>
			<li><a href="#report">&rsaquo; Blocking Report</a></li>
			<li><a href="#history">&rsaquo; Blocking History</a></li>
		</ul>
	</div>
</div>

<div id="main-copy">

	<h1 id="report">Blocking Report</h1>
	<br />

	<table width="75%" border="1">
		<tr>
			<td width="25%"><strong>Visitor IP:</strong></td>
			<td width="75%"><?php echo $visitor_ip; ?></td>
		</tr>
		<tr>
			<td><strong>Visitor Hostname:</strong></td>
			<td><?php echo (gethostbyaddr($visitor_ip)); ?></td>
		</tr>
		<tr>
			<td><strong>Number of blocks:</strong></td>
			<td><?php echo $block_count_visitor; ?></td>
		</tr>
		<tr>
			<td><strong>More info on this visitor:</strong></td>
			<td><a href="http://www.dnsstuff.com/tools/ipall.ch?domain=<?php echo $visitor_ip; ?>">More Info</a></td>
		</tr>
	</table>
	
	<h1 id="history">Blocking History</h1>
	<br />

	<table width="60%" border="1">
		<tr>
			<td width="50%" align="center"><strong>Date/Time of Block</strong></td>
			<td width="50%" align="center"><strong>Reason for Block</strong></td>
		</tr>
		<?php
$query = "SELECT * FROM $db_table_adblock WHERE visitor_ip = '$visitor_ip' ORDER BY id DESC";

$result = mysql_query("$query")
		or die(sprintf("Couldn't execute sql_count, %s: %s", db_errno(), db_error()));

while($row = mysql_fetch_array($result)) {
	$date = $row['date'];
	$time = $row['time'];
	$reason = $row["reason"];
	
	if ($reason == "1") {
		$reason_text = "Cookie was set";
	} elseif ($reason == "2") {
		$reason_text = "On IP Ban List";
	} elseif ($reason == "3") {
		$reason_text = "IP in database";
	} elseif ($reason == "4") {
		$reason_text = "Ads disabled site-wide";
	} else {
		$reason_text = $reason;
	}
?>
		<tr>
			<td><?php echo $date . " " . $time; ?></td>
			<td><?php echo $reason_text; ?></td>
		</tr>
		<?php  } ?>
	</table>
</div>

<?php bodyFooter('blockinfoVisitor'); ?>