<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

require ("./config_settings.php");
require ("./loginverify.php");
require ("./functions.php");
	micro_time('start');
	bodyHeader('support');
	bodyNavigation('support');
require ("./config_database.php");
?>
<div id="side-bar">
	<div>
		<p class="sideBarTitle">Support</p>
			<ul>
				<li><a href="http://www.adlogger.org/" target="_blank">&rsaquo; Documentation</a></li>
				<li><a href="http://www.adlogger.org/forum/" target="_blank">&rsaquo; Forum</a></li>
			</ul>
	</div>
</div>

<div id="main-copy">
	<h1 id="documentation">Documentation</h1>
	<p>Documentation can be found at <a href="http://www.adlogger.org/">http://www.adlogger.org/</a>.</p>
	<p>Nearly all aspects of the site should be well documented and covered in depth. Please read the manual before using AdLogger.</p>
	<h1 id="forum">Forum</h1>
	<p>The best place to get support regarding AdLogger can be found at the forums, at <a href="http://www.adlogger.org/forum/" target="_blank">http://www.adlogger.org/forum/</a></p>
	<p>The forum is a fairly active place with many knowledgeable programmers. Your question should get answered fairly quickly. </p>
	<p>Register for and check out the <a href="http://www.adlogger.org/forum/" target="_blank">Forums</a>!</p>
</div>

<?php bodyFooter('support'); ?>