<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

session_start();
require ("./config_database.php");
require ("./config_settings.php");

	$username = mysql_escape_string($_POST['username']);
	$password = mysql_escape_string($_POST['password']);

	$password_hash = sha1($password);

$query = "SELECT username, password FROM $db_table_users WHERE username='$username' AND password='$password_hash'";
$result = mysql_query($query);

if (mysql_num_rows($result)) {
	$_SESSION['adminglog'] = $login_hash;
		if (isset($_POST['remember'])) {
			setcookie("adminglog_cookie", $login_hash, time()+31536000, "/");
		}
	header("Location: ./");
	exit();
} else {
	$_SESSION['login_message'] = "Invalid Username or Password.";
	header("Location: ./login.php");
	exit();
}
?>