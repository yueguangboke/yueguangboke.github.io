<?php
//
// This will get replaced once the install is successful.
//
// It just redirects the person to the install process if the
// script hasn't been properly setup, yet.
// 
header("Location: ./install/");
exit();
?>