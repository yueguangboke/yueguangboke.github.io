<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

error_reporting(0);

require ("./config_database.php");
require ("./config_settings.php");

function visitorIP() {
	$ipParts = explode(".", $_SERVER['REMOTE_ADDR']);
	if ($ipParts[0] == "165" && $ipParts[1] == "21") {    
		if (getenv("HTTP_CLIENT_IP")) {
			$ip = getenv("HTTP_CLIENT_IP");
		} elseif (getenv("HTTP_X_FORWARDED_FOR")) {
			$ip = getenv("HTTP_X_FORWARDED_FOR");
		} elseif (getenv("REMOTE_ADDR")) {
			$ip = getenv("REMOTE_ADDR");
		}
	} else {
		return $_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}

$visitor_ip = visitorIP();
$visitor_agent = htmlspecialchars($_SERVER['HTTP_USER_AGENT']);

$date = date('Y-m-d', $timestamp);
$time = date('G:i:s', $timestamp);

$ch_id = mysql_real_escape_string(htmlspecialchars($_GET['ch_id']));
$ad_target = mysql_real_escape_string(htmlspecialchars($_GET['ad_target']));
$ad_format = '';
$page = mysql_real_escape_string(htmlspecialchars($_SERVER["HTTP_REFERER"]));

mysql_query("INSERT INTO $db_table_logfiles	SET
date ='$date',
time ='$time',
timestamp ='$timestamp',
visitor_ip='$visitor_ip',
visitor_agent='$visitor_agent',
adlogger_channel_id='$ch_id',
displaypage_url='$page',
ad_targ_url='$ad_target',
ad_format='$ad_format'
")
or die(mysql_error());

$backlog_timeframe = $timestamp - $clickmaxtime;
$result = mysql_query("SELECT visitor_ip FROM $db_table_logfiles WHERE visitor_ip = '$visitor_ip' AND timestamp > '$backlog_timeframe'");
$visitors_recent_clicks = mysql_num_rows($result);

if ($email_alert == "y" && ($visitors_recent_clicks >= $emailalert_num)) {

	$msg = "AdLogger reports a multiple click by one of your visitors. The details of the report are below:<BR><BR>
	Visitor IP - $visitor_ip<BR><BR>
	Visitor Agent - $visitor_agent<BR><BR>
	Date/Time of click - $date $time<BR><BR>
	AdLogger estimates this person has clicked a total of $visitors_recent_clicks ads.<BR><BR>
	Details:<BR>
	Page of the click - <a href=$ref>$page</a><BR><BR><BR>
	These notices are part of your AdLogger settings. To change, log in to your AdLogger Admin panel <a href=$siteurl$adlogger_loc>here</a>.
	";

	$subject = "AdLogger Multiple Click Notification";
	$mailheaders  = "MIME-Version: 1.0\n";
	$mailheaders .= "Content-type: text/html; charset=iso-8859-1\n";

	$to = $email;
	$mailheaders .= "From: AdLogger <$email> \n";
	$mailheaders .= "Reply-To: $email\n\n";

	mail($to, $subject, $msg, $mailheaders);

} elseif ($email_notice == "y") {

	$msg = "AdLogger reports a click on your site. It reports the following:<BR><BR>
	Visitor IP - $visitor_ip<BR><BR>
	Visitor Agent - $visitor_agent<BR><BR>
	Date/Time of click - $date $time<BR><BR>
	Details:<BR>
	Page of the click - <a href=$ref>$page</a><BR><BR><BR>
	These notices are part of your AdLogger settings. To change, log in to your AdLogger Admin panel <a href=$siteurl$adlogger_loc>here</a>.
	";

	$subject = "AdLogger Click Notification";
	$mailheaders  = "MIME-Version: 1.0\n";
	$mailheaders .= "Content-type: text/html; charset=iso-8859-1\n";

	$to = $email;
	$mailheaders .= "From: AdLogger <$email> \n";
	$mailheaders .= "Reply-To: $email\n\n";

	mail($to, $subject, $msg, $mailheaders);
}
?>