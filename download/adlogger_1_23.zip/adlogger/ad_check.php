<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

error_reporting(0);

require ("./config_database.php");
require ("./config_settings.php");

$visitor_ip = mysql_escape_string($_GET['visitor_ip']);

$test_done = 'n';

if ($disable_all_ads == 'y') {
	$show_ads = 'n';
	$test_done = 'y';
	$reason = 4;
}

if ($test_done != 'y') {
	foreach ($ip_range_ban_list as $ip_range_ban) {
		if (preg_match('/\\A' . $ip_range_ban . '/', $visitor_ip) && $ip_range_ban != "") {
			$show_ads = 'n';
			$test_done = 'y';
			$reason = 2;
			break;
		}
	}
}

if ($test_done != 'y' && $ip_db_check == 'y') {
	$backlog_timeframe = $timestamp - $clickmaxtime;

	$result = mysql_query("SELECT visitor_ip FROM $db_table_logfiles WHERE visitor_ip = '$visitor_ip' AND timestamp > '$backlog_timeframe' LIMIT $clickmax");
	$visitors_recent_clicks = mysql_num_rows($result);
	
	if ($visitors_recent_clicks >= $clickmax) {
		$show_ads = 'n';
		$test_done = 'y';
		$reason = 3;
	}
}

if ($show_ads == 'n') {
	$date = date('Y-m-d', $timestamp);
	$time = date('G:i:s', $timestamp);
	mysql_query("INSERT INTO $db_table_adblock
		SET
		date='$date',
		time='$time',
		visitor_ip='$visitor_ip',
		reason='$reason'
	")
	or die(mysql_error());
}

if ($test_done != 'y') $show_ads = 'y';

echo $show_ads;
?>