<?php
//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//    AdLogger                                                                  //
//    Copyright 2006 by Trevor Fitzgerald                                       //
//    http://www.adlogger.org                                                   //
//    support@adlogger.org                                                      //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////

session_start();
require ("./functions.php");
	micro_time('start');
require ("./config_database.php");
require ("./config_settings.php");

if (isset($_POST['reset']) && isset($_POST['submitted_email'])) {

	$submitted_email = $_POST['submitted_email'];

	if ($submitted_email == $email) {

		$random_password = createRandomString(7);
		$random_password_sha = sha1($random_password);
		
		//Insert the new password into the database encrypted
		
			mysql_query("UPDATE $db_table_users SET
			password='$random_password_sha'
			")
			or die(mysql_error());
		
		//Send an email with the new password:
		
			$msg = "
			Your password has just been reset.<BR><BR>
			New password: $random_password<BR>
			Login here: " . $siteurl . $adlogger_loc
			;
			
			$subject = "AdLogger Password Reset";
			$mailheaders  = "MIME-Version: 1.0\n";
			$mailheaders .= "Content-type: text/html; charset=iso-8859-1\n";
			
			$to = $email;
			$mailheaders .= "From: AdLogger <$email> \n";
			$mailheaders .= "Reply-To: $email\n\n";
			
			mail($to, $subject, $msg, $mailheaders);

		$_SESSION['login_message'] = "Your password has been successfully reset and sent to your email address.";
		header("Location: ./login.php");
		exit();
	
	} else {
	
		$_SESSION['login_message'] = "The email address must match the one in your configuration settings.";
		header("Location: ./pwreset.php");
		exit();
	
	}
	
}

bodyHeader('pwreset');
bodyNavigation('pwreset');

?>

<div id="main-copy">
	<h1 id="introduction">Reset Password</h1>
	<p>Enter your email address to reset your password.</p>
	<?php if (isset($_SESSION['login_message'])) { ?>
		<span class="changeSettingMessage"><?php echo $_SESSION['login_message'] . "<br /><br />"; unset($_SESSION['login_message']); ?></span>
		<?php } ?>
	<form action="pwreset.php" method="post">
		<table width="50%" border="0" align="center" cellpadding="5" cellspacing="0">
			<tr>
				<td width="50%" align="center">Email Address: </td>
				<td width="50%" align="center"><label>
					<input name="submitted_email" type="text" id="submitted_email">
					</label></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="hidden" name="reset" value="reset">
					<input type="submit" name="Submit" value="Reset Password"></td>
			</tr>
		</table>
	</form>
</div>

<?php bodyFooter('pwreset'); ?>