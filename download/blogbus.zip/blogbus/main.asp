<%@ CODEPAGE=65001 %>
<%

	Response.Redirect "tool.asp" 

%>