<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog(http://www.rainbowsoft.org)
'// 插件制作:    williamlong
'// 备    注:    Z-Blog导出到BlogBus
'// 最后修改：   
'// 最后版本:    
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% 'On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../c_function.asp" -->
<!-- #include file="../../c_system_lib.asp" -->
<!-- #include file="../../c_system_base.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6)

BlogTitle="Z-Blog到BlogBus导出程序"


Dim intMinID
Dim intMaxID

Dim objRS
Set objRS=objConn.Execute("SELECT TOP 1 [log_ID] FROM [blog_Article] ORDER BY [log_ID] ASC")
If (Not objRS.bof) And (Not objRS.eof) Then
intMinID=objRS("log_ID")
End If
Set objRS=Nothing
Set objRS=objConn.Execute("SELECT TOP 1 [log_ID] FROM [blog_Article] ORDER BY [log_ID] DESC")
If (Not objRS.bof) And (Not objRS.eof) Then
intMaxID=objRS("log_ID")
End If
Set objRS=Nothing


%><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<%=ZC_BLOG_LANGUAGE%>" lang="<%=ZC_BLOG_LANGUAGE%>">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Content-Language" content="<%=ZC_BLOG_LANGUAGE%>" />
	<link rel="stylesheet" rev="stylesheet" href="../../CSS/admin.css" type="text/css" media="screen" />
	<script language="JavaScript" src="../../script/common.js" type="text/javascript"></script>
	<title><%=BlogTitle%></title>
</head>
<body>

			<div id="divSidebar">
<div id="divTitle">
<img src="../../image/edit/titlezblog.gif" title="RainbowSoft Studio Z-Blog" alt="RainbowSoft Studio Z-Blog"/>
</div>
<div id="divManage">
<ul>
<li><a href="../../cmd.asp?act=PlugInMng"><%=ZC_MSG065%></a></li>
</ul>
</div>
			</div>
			
<div id="divMain">
<%

%>

<form border="1" name="edit" id="edit" method="post" action="blogbus.asp">
<p>范围</p>
<hr/>
<p>文件ID 从<input type="text" name="inpMin" value="<%=intMinID%>"/> 到 <input type="text" name="inpMax" value="<%=intMaxID%>"/></p>
<br/>
<p>选项</p>
<hr/>
<p><input          checked type="checkbox" name="chkCnt" value="true"/>导出正文</p>
<p><input          checked type="checkbox" name="chkInr" value="true"/>导出摘要</p>
<!--
<p><input          checked type="checkbox" name="chkTag" value="true"/>导出Tags</p>
<p><input          checked type="checkbox" name="chkCmt" value="true"/>导出评论</p>
<p><input          checked type="checkbox" name="chkTb"  value="true"/>导出引用</p>
-->
<hr/>
<p><input type="submit" class="button" value="提交" name="B1" onclick='' /> </p>
</form>
<br/>
</div>
<script>


</script>
</body>
</html>
<%
Call System_Terminate()

If Err.Number<>0 then
  Call ShowError(0)
End If
%>

