DB2ASP (Build 1.00.0035)

http://www.moon-blog.com

Summary
-------
DB2ASP generates an Active Server Page framework from an Access database. The framework contains Script subroutines to display and validate html forms and update the selected table or query. This won't do everything for you but it will jumpstart your development process by automatically generating tedious code.

Overview
--------
So many of the applications I create involve using web-based html forms to update Access databases that one day I just got tired of doing the same stuff over and over and came up with the idea for this program. The framework created by the program will display a blank form and data view, you can enter data into the form and write the form data back to the database. The wizard eliminates about 80% of the redundant coding associated with these types of applications. You'll still have to make modifications to the resulting code to fit your specific situations.

You need VB6 with service pack 5 and DAO 3.6 on your machine for the db2asp to run.

UI Details
----------
Run db2asp.exe.

In the Register Form, if you don't have a register code, Click Cancel.

Click Select.

Select an existing Access database.

Select a table.

Select the fields you want to appear on the html form.

Select the filter method and search field.

Verify your selections.

Click Start.

Some ASP file which containing the JavaScript code will be generated on the output path. Copy this file and database to your Inetput/wwwroot path and run it. You can also edit it with your editor.

Code Details
------------
The prgoram creates a Dim statement for each database field you selected. It also dims several other variables used throughout the framework.

Verify that sDBName points to a valid path on your server.

db.asp
------------
You can change your database connect string here. You can also change your database to another database system, such as SQL Server.

If you use SQLServer, change your connstr as below.
connstr="driver={SQL Server};server=localhost;uid=sa;pwd=;database=DatabaseName"

fileedit.asp
------------
This file is your data edit form. You can change your edit form interface here.

filelist.asp
-----------------
This file is your data listview interface.

filefilter.asp
------------------
This file is your data data filter form.

Hints
-----
Your Access database must have a field named "ID", and it should auto increase.

Your Access database must writeble. check the property of the database file.

DB2ASP History
----------------------------
Build 1.00.0016 (01/10/03) Initial release.
