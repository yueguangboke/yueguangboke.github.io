<%
dim conn
dim connstr
set conn=server.CreateObject("adodb.connection")
connstr = "Provider=Microsoft.JET.OLEDB.4.0;User Id=Admin;Data Source = demo.mdb "
conn.Open connstr 
%>
