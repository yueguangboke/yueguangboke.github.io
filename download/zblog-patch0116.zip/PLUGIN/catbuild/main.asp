<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog(http://www.rainbowsoft.org)
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    生成静态HTML的分类目录的程序
'// 最后修改：   2006-1-16
'// 最后版本:    1.5
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../c_function.asp" -->
<!-- #include file="../../c_system_lib.asp" -->
<!-- #include file="../../c_system_base.asp" -->
<!-- #include file="../../c_system_event.asp" -->
<%

'*********************************************************
' 目的：    All Category ReBuild
'*********************************************************
Function MakeCatReBuild()

	Dim objPage
	Dim objRS
	Dim ArtList
	Dim cate_id,cate_Intro,cate_year,cate_month

	'生成分类目录文件开始
	Set objRS=objConn.Execute("SELECT cate_id,cate_Intro FROM blog_Category ORDER BY cate_id ")
	While Not objRS.eof
		'取得目录ID
		cate_id=cstr(objRS("cate_id"))
		cate_Intro=cstr(objRS("cate_Intro"))
		'生成一个分类目录文件
		Set ArtList=New TArticleList
		ArtList.LoadCache
		ArtList.template="CATALOG"
		If ArtList.ExportByCache(Request.QueryString("page"),cate_id,Request.QueryString("auth"),Request.QueryString("date"),Request.QueryString("tags"),ZC_DISPLAY_MODE_ALL) Then
			ArtList.Build
			ArtList.FileName=cate_Intro
			ArtList.Save
		End If
		Set ArtList=Nothing
		objRS.MoveNext
	Wend
	objRS.Close
	Set objRS=Nothing
	'生成分类目录文件结束

	'生成日期目录文件开始
	Set objRS=objConn.Execute("SELECT year(log_posttime) as cate_year,month(log_posttime) as cate_month FROM blog_Article group by year(log_posttime),month(log_posttime) ")
	While Not objRS.eof
		'取得目录ID
		cate_year=cstr(objRS("cate_year"))
		cate_month=cstr(objRS("cate_month"))
		'生成一个日期目录文件
		Set ArtList=New TArticleList
		ArtList.LoadCache
		ArtList.template="CATALOG"
		If ArtList.ExportByCache(Request.QueryString("page"),Request.QueryString("cate"),Request.QueryString("auth"),cate_year & "-" & cate_month,Request.QueryString("tags"),ZC_DISPLAY_MODE_ALL) Then
			ArtList.Build
			ArtList.FileName=cate_year & "_" & right("00"&cate_month,2)
			ArtList.Save
		End If
		Set ArtList=Nothing
		objRS.MoveNext
	Wend
	objRS.Close
	Set objRS=Nothing
	'生成日期目录文件结束

	MakeCatReBuild=True

End Function
'*********************************************************


Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6) 

MakeCatReBuild

%>

<script language="javascript">
    alert ("文件生成成功.");
	document.location.href="javascript:history.go(-1)"
</script>

<% 
Call System_Terminate()

If Err.Number<>0 then
	Call ShowError(0)
End If
'********************************************************
%>