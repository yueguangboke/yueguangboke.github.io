<%
'///////////////////////////////////////////////////////////////////////////////
'//              Z-Blog
'// 作    者:    朱煊(zx.asd)
'// 版权所有:    RainbowSoft Studio
'// 技术支持:    rainbowsoft@163.com
'// 程序名称:    
'// 程序版本:    
'// 单元名称:    c_system_event.asp
'// 开始时间:    2005.02.11
'// 最后修改:    
'// 备    注:    
'///////////////////////////////////////////////////////////////////////////////



'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    用户登陆
'*********************************************************
Public Function Login()

	If Request.Form("edtCheckOut")<>Session("loginvalid") Then Call ShowError(8)

	If BlogUser.Verify=False Then
		Call ShowError(8)
	Else
		Response.Redirect "cmd.asp?act=admin"
	End If
End Function
'*********************************************************




'*********************************************************
' 目的：    用户退出
'*********************************************************
Public Function Logout()
	Response.Cookies("username")=""
	Response.Cookies("password")=""
	Response.Write "<script language=""JavaScript"" src=""script/common.js"" type=""text/javascript""></script>"
	Response.Write "<script language=""JavaScript"" type=""text/javascript"">"
	Response.Write "SetCookie(""username"","""","""");"
	Response.Write "SetCookie(""password"","""","""");"
	Response.Write "window.location=""" & ZC_BLOG_HOST & """;"
	Response.Write "</script>"
End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    文件上抟
'*********************************************************
Function UploadFile(bolAutoName)

	Dim objUpLoadFile
	Set objUpLoadFile=New TUpLoadFile

	objUpLoadFile.AuthorID=BlogUser.ID

	If objUpLoadFile.UpLoad(bolAutoName) Then UploadFile=True

End Function
'*********************************************************




'*********************************************************
' 目的：     文件删除
'*********************************************************
Function DelFile(intID)

	Dim objUpLoadFile
	Set objUpLoadFile=New TUpLoadFile

	If objUpLoadFile.LoadInfoByID(intID) Then

		If (objUpLoadFile.AuthorID=BlogUser.ID) Or (CheckRights("Root")=True) Then
			If objUpLoadFile.Del Then DelFile=True
		End If

	Else
		Exit Function
	End If

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Post Article
'*********************************************************
Function PostArticle()

	Dim s
	Dim objRegExp

	If Request.Form("edtID")<>"0" Then
		Dim objTestArticle
		Set objTestArticle=New TArticle
		If objTestArticle.LoadInfobyID(Request.Form("edtID")) Then
			If Not((objTestArticle.AuthorID=BlogUser.ID) Or (CheckRights("Root")=True)) Then Exit Function
			objTestArticle.DelFile
		Else
			Call ShowError(9)
		End If
	End If

	Dim objArticle
	Set objArticle=New TArticle
	objArticle.ID=Request.Form("edtID")
	objArticle.CateID=Request.Form("edtCateID")
	objArticle.AuthorID=Request.Form("edtAuthorID")
	objArticle.Level=Request.Form("edtLevel")
	objArticle.PostTime=Request.Form("edtYear") & "-" & Request.Form("edtMonth") & "-" & Request.Form("edtDay") & " " &  Request.Form("edtTime")
	objArticle.Title=Request.Form("edtTitle")
	objArticle.Tag=ParseTag(Request.Form("edtTag"))
	objArticle.Alias=Request.Form("edtAlias")

	objArticle.Intro=Request.Form("txaIntro")

	Select Case LCase(Request.QueryString("type"))
	Case ""
		objArticle.Content=Request.Form("txaContent")
	Case "htmlarea"
		objArticle.Content=Request.Form("ta")

		If objArticle.Intro="" Then
			s=objArticle.Content
			Set objRegExp=New RegExp
			objRegExp.IgnoreCase =True
			objRegExp.Global=True
			objRegExp.Pattern="<[^>]*>"
			s=objRegExp.Replace(s,"")
			s=Left(s,ZC_TB_EXCERPT_MAX) & "..."
			objArticle.Intro=s
		End If
	Case "tinymce"
		objArticle.Content=Request.Form("txaContent")

		If objArticle.Intro="" Then
			s=objArticle.Content
			Set objRegExp=New RegExp
			objRegExp.IgnoreCase =True
			objRegExp.Global=True
			objRegExp.Pattern="<[^>]*>"
			s=objRegExp.Replace(s,"")
			s=Left(s,ZC_TB_EXCERPT_MAX) & "..."
			objArticle.Intro=s
		End If
	Case "fckeditor"
		objArticle.Content=Request.Form("txaContent")

		If objArticle.Intro="" Then
			s=objArticle.Content
			Set objRegExp=New RegExp
			objRegExp.IgnoreCase =True
			objRegExp.Global=True
			objRegExp.Pattern="<[^>]*>"
			s=objRegExp.Replace(s,"")
			s=Left(s,ZC_TB_EXCERPT_MAX) & "..."
			objArticle.Intro=s
		End If
	Case "ewebeditor"
		objArticle.Content=Request.Form("txaContent")

		If objArticle.Intro="" Then
			s=objArticle.Content
			Set objRegExp=New RegExp
			objRegExp.IgnoreCase =True
			objRegExp.Global=True
			objRegExp.Pattern="<[^>]*>"
			s=objRegExp.Replace(s,"")
			s=Left(s,ZC_TB_EXCERPT_MAX) & "..."
			objArticle.Intro=s
		End If
	Case Else
		objArticle.Content=Request.Form("txaContent")

		If objArticle.Intro="" Then
			s=objArticle.Content
			Set objRegExp=New RegExp
			objRegExp.IgnoreCase =True
			objRegExp.Global=True
			objRegExp.Pattern="<[^>]*>"
			s=objRegExp.Replace(s,"")
			s=Left(s,ZC_TB_EXCERPT_MAX) & "..."
			objArticle.Intro=s
		End If
	End Select

	If objArticle.Post Then
		Call BuildArticle(objArticle.ID)
		PostArticle=True
	End If

End Function
'*********************************************************




'*********************************************************
' 目的：    Del Article
'*********************************************************
Function DelArticle(intID)

	If intID<>"" Then
		Dim objTestArticle
		Set objTestArticle=New TArticle
		If objTestArticle.LoadInfobyID(intID) Then
			If Not((objTestArticle.AuthorID=BlogUser.ID) Or (CheckRights("Root")=True)) Then Exit Function
		Else
			Call ShowError(9)
		End If
		Set objTestArticle=Nothing
	End If

	Dim objArticle
	Set objArticle=New TArticle

	If objArticle.LoadInfoByID(intID) Then

		If objArticle.Del Then DelArticle=True
		BlogReBuild_Comments

		Dim objNavArticle
		Dim objRS
		Set objRS=objConn.Execute("SELECT TOP 1 [log_ID] FROM [blog_Article] WHERE ([log_Level]>2) AND ([log_PostTime]<#" & objArticle.PostTime & "#) ORDER BY [log_PostTime] DESC")
		If (Not objRS.bof) And (Not objRS.eof) Then
			Set objNavArticle=New TArticle
			objNavArticle.LoadInfoByID(objRS("log_ID"))
			If objNavArticle.Export(ZC_DISPLAY_MODE_ALL) Then
				objNavArticle.template="SINGLE"
				objNavArticle.SaveCache
				objNavArticle.Build
				objNavArticle.Save
			End If
			Set objNavArticle=Nothing
		End If
		Set objRS=Nothing
		Set objRS=objConn.Execute("SELECT TOP 1 [log_ID] FROM [blog_Article] WHERE ([log_Level]>2) AND ([log_PostTime]>#" & objArticle.PostTime & "#) ORDER BY [log_PostTime] ASC")
		If (Not objRS.bof) And (Not objRS.eof) Then
			Set objNavArticle=New TArticle
			objNavArticle.LoadInfoByID(objRS("log_ID"))
			If objNavArticle.Export(ZC_DISPLAY_MODE_ALL) Then
				objNavArticle.template="SINGLE"
				objNavArticle.SaveCache
				objNavArticle.Build
				objNavArticle.Save
			End If
			Set objNavArticle=Nothing
		End If
		Set objRS=Nothing

	End If

End Function
'*********************************************************




'*********************************************************
' 目的：    Build Article
'*********************************************************
Function BuildArticle(intID)

	Dim objArticle
	Set objArticle=New TArticle
	If objArticle.LoadInfoByID(intID) Then
		objArticle.Statistic
		If objArticle.Export(ZC_DISPLAY_MODE_ALL) Then
			objArticle.template="SINGLE"
			objArticle.SaveCache
			objArticle.Build
			objArticle.Save
		End If

		If ZC_USE_NAVIGATE_ARTICLE=True Then

			Dim objNavArticle
			Dim objRS
			Set objRS=objConn.Execute("SELECT TOP 1 [log_ID] FROM [blog_Article] WHERE ([log_Level]>2) AND ([log_PostTime]<#" & objArticle.PostTime & "#) ORDER BY [log_PostTime] DESC")
			If (Not objRS.bof) And (Not objRS.eof) Then
				Set objNavArticle=New TArticle
				objNavArticle.LoadInfoByID(objRS("log_ID"))
				If objNavArticle.Export(ZC_DISPLAY_MODE_ALL) Then
					objNavArticle.template="SINGLE"
					objNavArticle.SaveCache
					objNavArticle.Build
					objNavArticle.Save
				End If
				Set objNavArticle=Nothing
			End If
			Set objRS=Nothing
			Set objRS=objConn.Execute("SELECT TOP 1 [log_ID] FROM [blog_Article] WHERE ([log_Level]>2) AND ([log_PostTime]>#" & objArticle.PostTime & "#) ORDER BY [log_PostTime] ASC")
			If (Not objRS.bof) And (Not objRS.eof) Then
				Set objNavArticle=New TArticle
				objNavArticle.LoadInfoByID(objRS("log_ID"))
				If objNavArticle.Export(ZC_DISPLAY_MODE_ALL) Then
					objNavArticle.template="SINGLE"
					objNavArticle.SaveCache
					objNavArticle.Build
					objNavArticle.Save
				End If
				Set objNavArticle=Nothing
			End If
			Set objRS=Nothing

		End If

		BuildArticle=True

	End If

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Post Category
'*********************************************************
Function PostCategory()

	Dim objCategory
	Set objCategory=New TCategory
	objCategory.ID=Request.Form("edtID")
	objCategory.Name=Request.Form("edtName")
	objCategory.Order=Request.Form("edtOrder")
	objCategory.Alias=Request.Form("edtAlias")
	If objCategory.Post Then PostCategory=True
	Set objCategory=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    Del Category
'*********************************************************
Function DelCategory(intID)

	Dim objCategory
	Set objCategory=New TCategory
	objCategory.ID=intID
	If objCategory.Del Then DelCategory=True
	Set objCategory=Nothing

End Function
'*********************************************************



'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Post Comment
'*********************************************************
Function PostComment()

	If ZC_COMMENT_VERIFY_ENABLE Then
		If Request.Form("inpVerify")<>Session("commentvalid") Then Exit Function
	End If

	Dim objComment
	Dim objArticle

	Set objComment=New TComment
	Set objArticle=New TArticle

	objComment.log_ID=Request.Form("inpID")
	objComment.AuthorID=BlogUser.ID
	objComment.Author=Request.Form("inpName")
	objComment.Content=Request.Form("inpArticle")
	objComment.Email=Request.Form("inpEmail")
	objComment.HomePage=Request.Form("inpHomePage")

	Dim objUser
	For Each objUser in Users
		If IsObject(objUser) Then
			If (UCase(objUser.Name)=UCase(objComment.Author)) And (objUser.ID<>objComment.AuthorID) Then Call ShowError(6)
			If (objUser.ID=objComment.AuthorID) And (UCase(objUser.Name)<>UCase(objComment.Author)) Then Call ShowError(31)
			If (objUser.ID=objComment.AuthorID) And (UCase(objUser.Name)=UCase(objComment.Author)) Then
				objComment.Author=objUser.Name
			End If
		End If
	Next

	If objComment.Post Then
		If objArticle.LoadInfoByID(objComment.log_ID) Then
			objArticle.Statistic
			If objArticle.Export(ZC_DISPLAY_MODE_ALL) Then
				objArticle.template="SINGLE"
				objArticle.SaveCache
				objArticle.Build
				objArticle.Save
			End If
			BlogReBuild_Comments
			PostComment=True
		End If
	End if

	Set objComment=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    Del Comment
'*********************************************************
Function DelComment(intID,intLog_ID)

	Dim objComment
	Dim objArticle

	Set objComment=New TComment
	Set objArticle=New TArticle

	If objComment.LoadInfobyID(intID) Then

		Dim objTestArticle
		Set objTestArticle=New TArticle
		If objTestArticle.LoadInfobyID(objComment.log_ID) Then
			If Not((objComment.AuthorID=BlogUser.ID) Or (objTestArticle.AuthorID=BlogUser.ID) Or (CheckRights("Root")=True)) Then Exit Function
		Else
			Call ShowError(9)
		End If
		Set objTestArticle=Nothing

		If objComment.Del Then
			If objArticle.LoadInfoByID(objComment.log_ID) Then
				objArticle.Statistic
				If objArticle.Export(ZC_DISPLAY_MODE_ALL) Then
					objArticle.template="SINGLE"
					objArticle.SaveCache
					objArticle.Build
					objArticle.Save
				End If
				BlogReBuild_Comments
				DelComment=True
			End If
		End If

	End If

	Set objComment=Nothing

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Post TrackBack
'*********************************************************
Function PostTrackBack(intID)

	Dim objTrackBack
	Dim objArticle

	Set objTrackBack=New TTrackBack
	Set objArticle=New TArticle

	objTrackBack.log_ID=intID
	objTrackBack.URL=Request.Form("url")
	objTrackBack.Title=Request.Form("title")
	objTrackBack.Blog=Request.Form("blog_name")
	objTrackBack.Excerpt=Request.Form("excerpt")

	If objTrackBack.Post Then
		If objArticle.LoadInfoByID(objTrackBack.log_ID) Then
			objArticle.Statistic
			If objArticle.Export(ZC_DISPLAY_MODE_ALL) Then
				objArticle.template="SINGLE"
				objArticle.SaveCache
				objArticle.Build
				objArticle.Save
			End If
			BlogReBuild_TrackBacks
			PostTrackBack=True
		End If
	End If

	Set objTrackBack=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    Del TrackBack
'*********************************************************
Function DelTrackBack(intID,intLog_ID)

	Dim objTrackBack
	Dim objArticle

	Set objTrackBack=New TTrackBack
	Set objArticle=New TArticle

	If objTrackBack.LoadInfobyID(intID) Then

		Dim objTestArticle
		Set objTestArticle=New TArticle
		If objTestArticle.LoadInfobyID(objTrackBack.log_ID) Then
			If Not((objTestArticle.AuthorID=BlogUser.ID) Or (CheckRights("Root")=True)) Then Exit Function
		Else
			Call ShowError(9)
		End If
		Set objTestArticle=Nothing

		If objTrackBack.Del Then
			If objArticle.LoadInfoByID(objTrackBack.log_ID) Then
				objArticle.Statistic
				If objArticle.Export(ZC_DISPLAY_MODE_ALL) Then
					objArticle.template="SINGLE"
					objArticle.SaveCache
					objArticle.Build
					objArticle.Save
				End If
				BlogReBuild_TrackBacks
				DelTrackBack=True
			End If
		End If

	End If

	Set objTrackBack=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    Send TrackBack
'*********************************************************
Function SendTrackBack()

	Dim objTrackBack
	Dim objArticle

	Set objTrackBack=New TTrackBack
	Set objArticle=New TArticle

	If objArticle.LoadInfobyID(Request.Form("edtID")) Then
		objTrackBack.URL=objArticle.Url
		objTrackBack.Title=objArticle.Title
		objTrackBack.Blog=ZC_BLOG_NAME
		objTrackBack.Excerpt=Left(objArticle.HtmlContent,250)
	Else
		Call ShowError(9)
	End If

	If objTrackBack.Send(Request.Form("edtTrackBack")) Then SendTrackBack=True
	Set objTrackBack=Nothing

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Edit User
'*********************************************************
Function EditUser()

	Dim objUser
	Set objUser=New TUser
	objUser.ID=Request.Form("edtID")
	objUser.Level=Request.Form("edtLevel")
	objUser.Name=Request.Form("edtName")
	objUser.PassWord=Request.Form("edtPassWord")
	objUser.Email=Request.Form("edtEmail")
	objUser.HomePage=Request.Form("edtHomePage")

	If Not((CInt(objUser.ID)=BlogUser.ID) Or (CheckRights("Root")=True)) Then Exit Function

	If objUser.Edit(BlogUser) Then EditUser=True

	Set objUser=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    Del User
'*********************************************************
Function DelUser(intID)

	Dim objRS
	Dim objUser
	Dim objUpLoadFile

	Set objUser=New TUser
	objUser.ID=intID
	If objUser.Del(BlogUser) Then DelUser=True
	Set objUser=Nothing

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Archives()

	Dim i
	Dim j
	Dim l
	Dim n
	Dim objRS
	Dim objStream

	'Archives
	Dim strArchives
	Set objRS=objConn.Execute("SELECT * FROM [blog_Article] WHERE ([log_Level]>1) ORDER BY [log_PostTime] DESC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		Dim dtmYM()
		i=0
		j=0
		ReDim Preserve dtmYM(0)
		Do While Not objRS.eof
			j=UBound(dtmYM)
			i=Year(objRS("log_PostTime")) & "-" & Month(objRS("log_PostTime"))
			If i<>dtmYM(j) Then
				ReDim Preserve dtmYM(j+1)
				dtmYM(j+1)=i
			End If
			objRS.MoveNext
		Loop
	End If
	objRS.Close
	Set objRS=Nothing

	If Not IsEmpty(dtmYM) Then
		For i=1 to UBound(dtmYM)

			l=Year(dtmYM(i))
			n=Month(dtmYM(i))+1
			IF n>12 Then l=l+1:n=1

			Set objRS=objConn.Execute("SELECT COUNT([log_ID]) FROM [blog_Article] WHERE ([log_Level]>1) AND [log_PostTime] BETWEEN #"& Year(dtmYM(i)) &"-"& Month(dtmYM(i)) &"-1# AND #"& l &"-"& n &"-1#")

			If (Not objRS.bof) And (Not objRS.eof) Then
				strArchives=strArchives & "<li><a href="""& ZC_BLOG_HOST & ZC_STATIC_DIRECTORY & "/" & Year(dtmYM(i)) & "_" & Right("00"&Month(dtmYM(i)),2) &  "." & ZC_STATIC_TYPE & """>" & Year(dtmYM(i)) & " " & ZVA_Month(Month(dtmYM(i))) & " (" & objRS(0) & ")" +"</a></li>"
				If ZC_ARCHIVE_COUNT>0 Then
					If i=ZC_ARCHIVE_COUNT Then Exit For
				End If
			End If

			objRS.Close
			Set objRS=Nothing
		Next
	End If

	strArchives=TransferHTML(strArchives,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/archives.asp",strArchives,"utf-8",True)

	BlogReBuild_Archives=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Catalogs()

	Dim objRS
	Dim objStream

	'Catalogs
	Dim strCatalog
	Set objRS=objConn.Execute("SELECT * FROM [blog_Category] ORDER BY [cate_Order] ASC,[cate_Count] DESC,[cate_ID] ASC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		Do While Not objRS.eof
			strCatalog=strCatalog & "<li><a href="""& Categorys(objRS("cate_ID")).Url & """>"+Categorys(objRS("cate_ID")).Name + " (" & Categorys(objRS("cate_ID")).Count & ")" +"</a></li>"
			objRS.MoveNext
		Loop
	End If
	objRS.Close
	Set objRS=Nothing


	strCatalog=TransferHTML(strCatalog,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/catalog.asp",strCatalog,"utf-8",True)

	BlogReBuild_Catalogs=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Categorys()

	Dim objRS
	Dim objStream
	Dim objArticle
	Dim i

	'Categorys
	Dim strCategory

	Dim Category
	For Each Category in Categorys

		If IsObject(Category) Then

			Set objRS=objConn.Execute("SELECT [log_ID] FROM [blog_Article] WHERE ([log_ID]>0) AND ([log_Level]>1) AND ([log_CateID]="&Category.ID&") ORDER BY [log_PostTime] DESC")

			If (Not objRS.bof) And (Not objRS.eof) Then
				For i=1 to ZC_PREVIOUS_COUNT
					Set objArticle=New TArticle
					If objArticle.LoadInfoByID(objRS("log_ID")) Then
						strCategory=strCategory & "<li><a href="""& objArticle.Url & """>" & objArticle.Title & "</a></li>"
					End If
					Set objArticle=Nothing
					objRS.MoveNext
					If objRS.eof Then Exit For
				Next
			End If
			objRS.close

			strCategory=TransferHTML(strCategory,"[no-asp]")

			Call SaveToFile(BlogPath & "/include/category_"&Category.ID&".asp",strCategory,"utf-8",True)

			strCategory=""

		End If
	Next

	BlogReBuild_Categorys=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Authors()

	Dim objRS
	Dim objStream

	'Authors
	Dim strAuthor
	Dim User
	For Each User in Users
		If IsObject(User) Then
				strAuthor=strAuthor & "<li><a href="""& User.Url & """>"+User.Name + " (" & User.Count & ")" +"</a></li>"
		End If
	Next

	strAuthor=TransferHTML(strAuthor,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/authors.asp",strAuthor,"utf-8",True)

	BlogReBuild_Authors=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Tags()

	Dim objRS
	Dim objStream

	'Authors
	Dim strTag

	Set objRS=objConn.Execute("SELECT * FROM [blog_Tag] ORDER BY [tag_Order] DESC,[tag_Count] DESC,[tag_ID] ASC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		Do While Not objRS.eof
				strTag=strTag & "<li><a href="""& Tags(objRS("tag_ID")).Url & """>"+Tags(objRS("tag_ID")).Name + " (" & Tags(objRS("tag_ID")).Count & ")" +"</a></li>"
			objRS.MoveNext
		Loop
	End If
	objRS.Close
	Set objRS=Nothing

	strTag=TransferHTML(strTag,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/tags.asp",strTag,"utf-8",True)

	BlogReBuild_Tags=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Previous()

	Dim i
	Dim objRS
	Dim objStream
	Dim objArticle

	'Previous
	Dim strPrevious
	Set objRS=objConn.Execute("SELECT [log_ID] FROM [blog_Article] WHERE ([log_ID]>0) AND ([log_Level]>1) ORDER BY [log_PostTime] DESC")

	If (Not objRS.bof) And (Not objRS.eof) Then
		For i=1 to ZC_PREVIOUS_COUNT
			Set objArticle=New TArticle
			If objArticle.LoadInfoByID(objRS("log_ID")) Then
				strPrevious=strPrevious & "<li><a href="""& objArticle.Url & """>" & objArticle.Title & "</a></li>"
			End If
			Set objArticle=Nothing
			objRS.MoveNext
			If objRS.eof Then Exit For
		Next
	End If
	objRS.close

	strPrevious=TransferHTML(strPrevious,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/previous.asp",strPrevious,"utf-8",True)

	BlogReBuild_Previous=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Comments()

	Dim objRS
	Dim objStream
	Dim objArticle

	'Comments
	Dim strComments

	Dim s
	Dim i
	Set objRS=objConn.Execute("SELECT [log_ID],[comm_ID],[comm_Content],[comm_PostTime],[comm_Author] FROM [blog_Comment] ORDER BY [comm_ID] DESC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		For i=1 to ZC_MSG_COUNT
			s=objRS("comm_Content")
			s=Replace(s,vbCrlf,"")
			If len(s)>ZC_RECENT_COMMENT_WORD_MAX Then s=Left(s,ZC_RECENT_COMMENT_WORD_MAX-4)&"..."
			Set objArticle=New TArticle
			If objArticle.LoadInfoByID(objRS("log_ID")) Then
				strComments=strComments & "<li><a href="""& objArticle.Url & "#cmt" & objRS("comm_ID") & """ title=""" & objRS("comm_PostTime") & " post by " & objRS("comm_Author") & """>"+s+"</a></li>"
			End If
			Set objArticle=Nothing
			objRS.MoveNext
			If objRS.eof Then Exit For
		Next
	End If
	objRS.close
	Set objRS=Nothing

	strComments=TransferHTML(strComments,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/comments.asp",strComments,"utf-8",True)

	BlogReBuild_Comments=True

End Function
'*********************************************************



'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_TrackBacks()

	Dim objRS
	Dim objStream
	Dim objArticle

	'TrackBacks
	Dim strTrackBacks

	Dim s
	Dim i
	Set objRS=objConn.Execute("SELECT * FROM [blog_TrackBack] ORDER BY [tb_ID] DESC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		For i=1 to ZC_MSG_COUNT
			s=objRS("tb_Title")
			s=Replace(s,vbCrlf,"")
			If len(s)>ZC_RECENT_COMMENT_WORD_MAX Then s=Left(s,ZC_RECENT_COMMENT_WORD_MAX-5)&"..."
			Set objArticle=New TArticle
			If objArticle.LoadInfoByID(objRS("log_ID")) Then
				strTrackBacks=strTrackBacks & "<li><a href="""& objArticle.Url & "#tb" & objRS("tb_ID") & """ title=""" & objRS("tb_PostTime") & " post by " & Replace(objRS("tb_Blog"),"""","") & """>"+s+"</a></li>"
			End If
			Set objArticle=Nothing
			objRS.MoveNext
			If objRS.eof Then Exit For
		Next
	End If
	objRS.close
	Set objRS=Nothing

	strTrackBacks=TransferHTML(strTrackBacks,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/trackbacks.asp",strTrackBacks,"utf-8",True)

	BlogReBuild_TrackBacks=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Statistics()

	Dim i
	Dim objRS
	Dim objStream

	'重新统计分类及用户的文章数、评论数
	Dim Category
	For Each Category in Categorys
		If IsObject(Category) Then
			Set objRS=objConn.Execute("SELECT COUNT([log_ID]) FROM [blog_Article] WHERE [log_CateID]=" & Category.ID )
			i=objRS(0)
			objConn.Execute("UPDATE [blog_Category] SET [cate_Count]="&i&" WHERE [cate_ID] =" & Category.ID)
			Set objRS=Nothing
		End If
	Next
	Dim User
	For Each User in Users
		If IsObject(User) Then
			Set objRS=objConn.Execute("SELECT COUNT([log_ID]) FROM [blog_Article] WHERE [log_AuthorID]=" & User.ID )
			i=objRS(0)
			objConn.Execute("UPDATE [blog_Member] SET [mem_PostLogs]="&i&" WHERE [mem_ID] =" & User.ID)
			Set objRS=Nothing

			Set objRS=objConn.Execute("SELECT COUNT([comm_ID]) FROM [blog_Comment] WHERE [comm_AuthorID]=" & User.ID )
			i=objRS(0)
			objConn.Execute("UPDATE [blog_Member] SET [mem_PostComms]="&i&" WHERE [mem_ID] =" & User.ID)
			Set objRS=Nothing
		End If
	Next
	Dim Tag
	For Each Tag in Tags
		If IsObject(Tag) Then
			Set objRS=objConn.Execute("SELECT COUNT([log_ID]) FROM [blog_Article] WHERE [log_Tag] LIKE '%{" & Tag.ID & "}%'")
			i=objRS(0)
			objConn.Execute("UPDATE [blog_Tag] SET [tag_Count]="&i&" WHERE [tag_ID] =" & Tag.ID)
			Set objRS=Nothing
		End If
	Next

	'Statistics
	Dim strStatistics
	Set objRS=Server.CreateObject("ADODB.Recordset")
	objRS.CursorType = adOpenKeyset
	objRS.LockType = adLockReadOnly
	objRS.ActiveConnection=objConn
	objRS.Source=""


	objRS.Open("SELECT COUNT([log_ID])AS allArticle,SUM([log_CommNums]) AS allCommNums,SUM([log_ViewNums]) AS allViewNums,SUM([log_TrackBackNums]) AS allTrackBackNums FROM [blog_Article]")
	If (Not objRS.bof) And (Not objRS.eof) Then
		strStatistics=strStatistics & "<li>"& ZC_MSG082 &":" & objRS("allArticle") & "</li>"
		strStatistics=strStatistics & "<li>"& ZC_MSG124 &":" & objRS("allCommNums") & "</li>"
		strStatistics=strStatistics & "<li>"& ZC_MSG125 &":" & objRS("allTrackBackNums") & "</li>"
	End If
	objRS.Close

	strStatistics=strStatistics & "<li>"& ZC_MSG083 &":" & ZC_BLOG_CSS & "</li>"
	strStatistics=strStatistics & "<li>"& ZC_MSG084 &":" & ZC_BLOG_LANGUAGE & "</li>"

	Set objRS=Nothing

	strStatistics=TransferHTML(strStatistics,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/statistics.asp",strStatistics,"utf-8",False)

	BlogReBuild_Statistics=True

End Function
'*********************************************************




'*********************************************************
' 目的：    Blog ReBuild
'*********************************************************
Function MakeBlogReBuild()

	BlogReBuild_Statistics

	GetCategory()
	GetUser()
	GetTags()
	GetKeyWords()

	BlogReBuild_Archives

	BlogReBuild_Previous

	BlogReBuild_Comments

	BlogReBuild_TrackBacks

	BlogReBuild_Catalogs

	BlogReBuild_Calendar

	BlogReBuild_Authors

	BlogReBuild_Tags

	BlogReBuild_Categorys

	BuildAllCache

	ExportRSS

	ExportATOM

	ClearGlobeCache
	LoadGlobeCache

	'Response.Write RunTime
	'Response.End

	MakeBlogReBuild=True

End Function
'*********************************************************




'*********************************************************
' 目的：    All Files ReBuild
'*********************************************************
Function MakeFileReBuild()

	Dim intPage

	intPage=CInt(Request.QueryString("page"))

	If intPage=0 Then intPage=1

	Dim i,j

	Dim objRS
	Dim objArticle

	Set objRS=Server.CreateObject("ADODB.Recordset")
	objRS.CursorType = adOpenKeyset
	objRS.LockType = adLockReadOnly
	objRS.ActiveConnection=objConn
	objRS.Source="SELECT [log_ID] FROM [blog_Article] WHERE [log_Level]>1"
	objRS.Open()

	If (Not objRS.bof) And (Not objRS.eof) Then

		objRS.PageSize = ZC_REBUILD_FILE_COUNT

		If intPage>objRS.PageCount Then MakeFileReBuild=True:Exit Function

		objRS.AbsolutePage = intPage

		For i = 1 To ZC_REBUILD_FILE_COUNT

			Set objArticle=New TArticle

			If objArticle.LoadInfobyID(objRS("log_ID")) Then
				If objArticle.Export(ZC_DISPLAY_MODE_ALL)= True Then
					objArticle.template="SINGLE"
					objArticle.SaveCache
					objArticle.Build
					objArticle.Save
				End If
			End If

			objRS.MoveNext
			If objRS.eof Then Exit For
		Next

		Response.Write "<html><head><meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8""/><meta http-equiv=""Content-Language"" content=""zh-cn"" /><meta http-equiv=""refresh"" content="""&ZC_REBUILD_FILE_INTERVAL&";URL=cmd.asp?act=FileReBuild&page="&intPage+1&"""/><title>"&ZC_MSG073&"</title></head><body>"&Replace(ZC_MSG152,"%n",ZC_REBUILD_FILE_INTERVAL)&"</body></html>"
	Else

		Response.Redirect "admin.asp?act=BlogMng"

	End If

	'Response.Write RunTime
	'Response.End

End Function
'*********************************************************




'*********************************************************
' 目的：    Create Cache File And Save To Disk
'*********************************************************
Function BuildAllCache()

	Dim strList

	Dim ArticleList
	Dim AuthList
	Dim CateList
	Dim TagsList

	Dim aryAllList()

	Dim objRS
	Dim i
	Dim j
	Dim n
	Dim l
	Dim k

	Set objRS=Server.CreateObject("ADODB.Recordset")
	objRS.CursorType = adOpenKeyset
	objRS.LockType = adLockReadOnly
	objRS.ActiveConnection=objConn
	objRS.Source=""

	objRS.Open("SELECT [log_ID] FROM [blog_Article] WHERE [log_Level]>1 ORDER BY [log_PostTime] DESC")

	If (Not objRS.bof) And (Not objRS.eof) Then

		objRS.PageSize = ZC_DISPLAY_COUNT
		ReDim aryAllList(objRS.PageCount+1)

		For i=1 to objRS.PageCount
			objRS.AbsolutePage=i
			For j = 1 To objRS.PageSize
				If j=1 Then aryAllList(i)="AllPage" & i & "["
				aryAllList(i)=aryAllList(i) & objRS("log_ID") & ";"
				If j=objRS.PageSize Then aryAllList(i)=aryAllList(i) & "]"
				objRS.MoveNext
				If objRS.EOF Then aryAllList(i)=aryAllList(i) & "]":Exit For
			Next
		Next

	End If
	objRS.Close
	strList=strList & Join(aryAllList)


	Dim Category
	For Each Category in Categorys

		If IsObject(Category) Then

			CateList=CateList &  vbTab & Category.ID & vbTab & Category.Name & vbVerticalTab

			objRS.Open("SELECT [log_ID] FROM [blog_Article] WHERE ([log_Level]>1) AND ([log_CateID]=" & Category.ID & ") ORDER BY [log_PostTime] DESC")

			If (Not objRS.bof) And (Not objRS.eof) Then

				objRS.PageSize = ZC_DISPLAY_COUNT
				ReDim aryAllList(objRS.PageCount+1)

				For i=1 to objRS.PageCount
					objRS.AbsolutePage=i
					For j = 1 To objRS.PageSize
						If j=1 Then aryAllList(i)="Cate" & Category.ID & "Page" & i & "["
						aryAllList(i)=aryAllList(i) & objRS("log_ID") & ";"
						If j=objRS.PageSize Then aryAllList(i)=aryAllList(i) & "]"
						objRS.MoveNext
						If objRS.EOF Then aryAllList(i)=aryAllList(i) & "]":Exit For
					Next
				Next
				strList=strList & Join(aryAllList)
				Erase aryAllList

			End If
			objRS.Close

		End If
	Next


	Dim User
	For Each User in Users

		If IsObject(User) Then

			AuthList=AuthList & vbTab & User.ID & vbTab & User.Name & vbVerticalTab

			objRS.Open("SELECT [log_ID] FROM [blog_Article] WHERE ([log_Level]>1) AND ([log_AuthorID]=" & User.ID & ") ORDER BY [log_PostTime] DESC")

			If (Not objRS.bof) And (Not objRS.eof) Then

				objRS.PageSize = ZC_DISPLAY_COUNT
				ReDim aryAllList(objRS.PageCount+1)

				For i=1 to objRS.PageCount
					objRS.AbsolutePage=i
					For j = 1 To objRS.PageSize
						If j=1 Then aryAllList(i)="Auth" & User.ID & "Page" & i & "["
						aryAllList(i)=aryAllList(i) & objRS("log_ID") & ";"
						If j=objRS.PageSize Then aryAllList(i)=aryAllList(i) & "]"
						objRS.MoveNext
						If objRS.EOF Then aryAllList(i)=aryAllList(i) & "]":Exit For
					Next
				Next
				strList=strList & Join(aryAllList)
				Erase aryAllList

			End If
			objRS.Close

		End If
	Next


	Dim Tag
	For Each Tag in Tags

		If IsObject(Tag) Then

			TagsList=TagsList & vbTab & Tag.ID & vbTab & Tag.Name & vbVerticalTab

			objRS.Open("SELECT [log_ID] FROM [blog_Article] WHERE ([log_Level]>1) AND ([log_Tag] LIKE '%{" & Tag.ID & "}%') ORDER BY [log_PostTime] DESC")

			If (Not objRS.bof) And (Not objRS.eof) Then

				objRS.PageSize = ZC_DISPLAY_COUNT
				ReDim aryAllList(objRS.PageCount+1)

				For i=1 to objRS.PageCount
					objRS.AbsolutePage=i
					For j = 1 To objRS.PageSize
						If j=1 Then aryAllList(i)="Tags" & Tag.ID & "Page" & i & "["
						aryAllList(i)=aryAllList(i) & objRS("log_ID") & ";"
						If j=objRS.PageSize Then aryAllList(i)=aryAllList(i) & "]"
						objRS.MoveNext
						If objRS.EOF Then aryAllList(i)=aryAllList(i) & "]":Exit For
					Next
				Next
				strList=strList & Join(aryAllList)
				Erase aryAllList

			End If
			objRS.Close

		End If

	Next


	Set objRS=objConn.Execute("SELECT * FROM [blog_Article] WHERE ([log_Level]>1) ORDER BY [log_PostTime] DESC")
	If (Not objRS.bof) And (Not objRS.eof) Then
		Dim dtmYM()
		i=0
		j=0
		ReDim Preserve dtmYM(0)
		Do While Not objRS.eof
			j=UBound(dtmYM)
			i=Year(objRS("log_PostTime")) & "-" & Month(objRS("log_PostTime"))
			If i<>dtmYM(j) Then
				ReDim Preserve dtmYM(j+1)
				dtmYM(j+1)=i
			End If
			objRS.MoveNext
		Loop
	End If
	objRS.Close
	Set objRS=Nothing


	If Not IsEmpty(dtmYM) Then
		For k=1 to UBound(dtmYM)

			l=Year(dtmYM(k))
			n=Month(dtmYM(k))+1
			IF n>12 Then l=l+1:n=1

			Set objRS=Server.CreateObject("ADODB.Recordset")
			objRS.CursorType = adOpenKeyset
			objRS.LockType = adLockReadOnly
			objRS.ActiveConnection=objConn
			objRS.Source=""

			objRS.Open("SELECT [log_ID] FROM [blog_Article] WHERE ([log_Level]>1) AND [log_PostTime] BETWEEN #"& Year(dtmYM(k)) &"-"& Month(dtmYM(k)) &"-1# AND #"& l &"-"& n &"-1# ORDER BY [log_PostTime] DESC")

			If (Not objRS.bof) And (Not objRS.eof) Then

				objRS.PageSize = ZC_DISPLAY_COUNT
				ReDim aryAllList(objRS.PageCount+1)

				For i=1 to objRS.PageCount
					objRS.AbsolutePage=i
					For j = 1 To objRS.PageSize
						If j=1 Then aryAllList(i)="Date" & Year(dtmYM(k)) & "-" & Month(dtmYM(k)) & "Page" & i & "["
						aryAllList(i)=aryAllList(i) & objRS("log_ID") & ";"
						If j=objRS.PageSize Then aryAllList(i)=aryAllList(i) & "]"
						objRS.MoveNext
						If objRS.EOF Then aryAllList(i)=aryAllList(i) & "]":Exit For
					Next
				Next
				strList=strList & Join(aryAllList)
				Erase aryAllList

			End If

			objRS.Close

		Next

	End If

	Call SaveToFile(BlogPath & "/CACHE/cache_list.asp",strList,"utf-8",False)

	Call SaveToFile(BlogPath & "/CACHE/cache_cate.asp",CateList,"utf-8",False)

	Call SaveToFile(BlogPath & "/CACHE/cache_auth.asp",AuthList,"utf-8",False)

	Call SaveToFile(BlogPath & "/CACHE/cache_tags.asp",TagsList,"utf-8",False)

	BuildAllCache=True

End Function
'*********************************************************




'*********************************************************
' 目的：    
'*********************************************************
Function BlogReBuild_Calendar()

	Dim objStream
	Dim strCalendar
	Dim i,j
	Dim objRS
	Dim k,l,m,n

	'Calendar
	strCalendar=MakeCalendar("")

	strCalendar=TransferHTML(strCalendar,"[no-asp]")

	Call SaveToFile(BlogPath & "/include/calendar.asp",strCalendar,"utf-8",True)

	BlogReBuild_Calendar=True

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    List User Rights
'*********************************************************
Function ListUser_Rights()

	Dim s
	Dim i
	Dim strAction
	Dim aryAction

	strAction="login|verify|logout|admin|cmt|tb|vrs|ArticleMng|ArticleEdt|ArticlePst|ArticleDel|CategoryMng|CategoryPst|CategoryDel|CommentMng|CommentDel|TrackBackMng|TrackBackDel|TrackBackSnd|UserMng|UserEdt|UserCrt|UserDel|BlogReBuild|FileReBuild|FileMng|FileUpload|FileDel|Search|BlogMng|SettingMng|SettingSav|PlugInMng|rss|Root"

	aryAction=Split(strAction, "|")

	s=ZC_MSG019

	Response.Write ZC_MSG001 & ":" & BLogUser.Name & "<br/><br/>"
	Response.Write ZC_MSG079 & ":" & ZVA_User_Level_Name(BLogUser.Level) & "<br/><br/>"

	For i=LBound(aryAction) To UBound(aryAction)

		If Not CheckRights(aryAction(i)) Then s=Replace(s,"%s",":False"&"<br/><br/>",1,1) Else s=Replace(s,"%s",":True"&"<br/><br/>",1,1)

	Next

	Response.Write s

	ListUser_Rights=True

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Export RSS 2.0
'*********************************************************
Function ExportRSS()

	Dim Rss2Export
	Dim objArticle

	Set Rss2Export = New TRss2Export

	With Rss2Export

		.TimeZone=ZC_TIME_ZONE

		.AddChannelAttribute "title",TransferHTML(ZC_BLOG_TITLE,"[html-format]")
		.AddChannelAttribute "link",TransferHTML(ZC_BLOG_HOST,"[html-format]")
		.AddChannelAttribute "description",TransferHTML(ZC_BLOG_SUBTITLE,"[html-format]")
		.AddChannelAttribute "generator","RainbowSoft Studio Z-Blog " & ZC_BLOG_VERSION
		.AddChannelAttribute "language",ZC_BLOG_LANGUAGE
		.AddChannelAttribute "copyright",TransferHTML(ZC_BLOG_COPYRIGHT,"[html-format]")
		.AddChannelAttribute "pubDate",Now

			Dim i
			Dim objRS
			Set objRS=objConn.Execute("SELECT [log_ID],[log_Tag],[log_CateID],[log_Title],[log_Intro],NULL,[log_Level],[log_AuthorID],[log_PostTime],[log_CommNums],[log_ViewNums],[log_TrackBackNums],[log_Url] FROM [blog_Article] WHERE ([log_ID]>0) AND ([log_Level]>2) ORDER BY [log_PostTime] DESC")

			If (Not objRS.bof) And (Not objRS.eof) Then
				For i=1 to ZC_RSS2_COUNT
					Set objArticle=New TArticle
					If objArticle.LoadInfoByArray(Array(objRS("log_ID"),objRS("log_Tag"),objRS("log_CateID"),objRS("log_Title"),objRS("log_Intro"),,objRS("log_Level"),objRS("log_AuthorID"),objRS("log_PostTime"),objRS("log_CommNums"),objRS("log_ViewNums"),objRS("log_TrackBackNums"),objRS("log_Url"))) Then
					.AddItem objArticle.HtmlTitle,Users(objArticle.AuthorID).Email & " (" & Users(objArticle.AuthorID).Name & ")",objArticle.HtmlUrl,objArticle.PostTime,objArticle.HtmlUrl,objArticle.HtmlIntro,Categorys(objArticle.CateID).HtmlName,objArticle.CommentUrl,objArticle.WfwComment,objArticle.WfwCommentRss,objArticle.TrackBackUrl
					End If
					objRS.MoveNext
					If objRS.eof Then Exit For
					Set objArticle=Nothing
				Next
			End If

	End With

	Rss2Export.Execute

	Rss2Export.SaveToFile(BlogPath & "rss.xml")

	Set Rss2Export = Nothing

	objRS.close
	Set objRS=Nothing
	ExportRSS=True

	Response.ContentType = "text/html"
	Response.Clear

End Function
'*********************************************************




'*********************************************************
' 目的：    Export ATOM 1.0
'*********************************************************
Function ExportATOM()

	Dim objArticle

	Dim Atom10Export
	Set Atom10Export = New TAtom10Export

	Atom10Export.TimeZone=ZC_TIME_ZONE

	Dim AtomEntry

	Dim AtomFeed
	Set AtomFeed = New TAtomFeed

	With AtomFeed

		.atomTitle=TransferHTML(ZC_BLOG_TITLE,"[html-format]")
		.atomSubtitle=TransferHTML(ZC_BLOG_SUBTITLE,"[html-format]")
		.atomID=ZC_BLOG_HOST
		.atomLink "alternate","text/html",ZC_BLOG_HOST
		.atomLink "self","application/atom+xml",ZC_BLOG_HOST & "atom.xml"
		'.atomPerson "author",BlogUser.Name,BlogUser.Email,BlogUser.HomePage
		.atomGenerator "RainbowSoft Studio Z-Blog","http://www.rainbowsoft.org/",ZC_BLOG_VERSION
		.atomUpdated=Now

	End With

	Atom10Export.GetFeed(AtomFeed.Node)


	Dim i
	Dim objRS
	Set objRS=objConn.Execute("SELECT [log_ID],[log_Tag],[log_CateID],[log_Title],[log_Intro],NULL,[log_Level],[log_AuthorID],[log_PostTime],[log_CommNums],[log_ViewNums],[log_TrackBackNums],[log_Url] FROM [blog_Article] WHERE ([log_ID]>0) AND ([log_Level]>2) ORDER BY [log_PostTime] DESC")

	If (Not objRS.bof) And (Not objRS.eof) Then
		For i=1 to ZC_RSS2_COUNT

			Set objArticle=New TArticle
			Set AtomEntry = New TAtomEntry

			With AtomEntry
				If objArticle.LoadInfoByArray(Array(objRS("log_ID"),objRS("log_Tag"),objRS("log_CateID"),objRS("log_Title"),objRS("log_Intro"),,objRS("log_Level"),objRS("log_AuthorID"),objRS("log_PostTime"),objRS("log_CommNums"),objRS("log_ViewNums"),objRS("log_TrackBackNums"),objRS("log_Url"))) Then

					.atomTitle=objArticle.HtmlTitle
					.atomPerson "author",Users(objArticle.AuthorID).Name,Users(objArticle.AuthorID).Email,Users(objArticle.AuthorID).HomePage
					.atomCategory "",Categorys(objArticle.CateID).Url,Categorys(objArticle.CateID).HtmlName
					.atomUpdated=objArticle.PostTime
					.atomPublished=objArticle.PostTime
					.atomSummary=objArticle.HtmlIntro
					.atomLink "alternate","text/html",objArticle.Url
					.atomID=objArticle.Url

				End If
			End With

			Atom10Export.GetEntry(AtomEntry.Node)
			Set AtomEntry = Nothing
			Set objArticle=Nothing

			objRS.MoveNext
			If objRS.eof Then Exit For

		Next
	End If

	objRS.close
	Set objRS=Nothing


	Atom10Export.Execute

	Atom10Export.SaveToFile(BlogPath & "atom.xml")

	Set Atom10Export = Nothing

	ExportATOM=True

	Response.ContentType = "text/html"
	Response.Clear

End Function
'*********************************************************




'*********************************************************
' 目的：    Export Comment RSS
'*********************************************************
Function RssComment()

	Dim Rss2Export
	Dim objArticle

	Set Rss2Export = New TRss2Export

	With Rss2Export

		Dim intID
		intID=Request.QueryString("id")
		Call CheckParameter(intID,"int",0)

		Set objArticle=New TArticle
		If objArticle.LoadInfoByID(intID) Then

		.TimeZone=ZC_TIME_ZONE

		.AddChannelAttribute "title",TransferHTML(ZC_BLOG_TITLE,"[html-format]")& "-" & objArticle.HtmlTitle
		.AddChannelAttribute "link",objArticle.HtmlUrl
		.AddChannelAttribute "generator","RainbowSoft Studio Z-Blog " & ZC_BLOG_VERSION
		.AddChannelAttribute "language",ZC_BLOG_LANGUAGE
		.AddChannelAttribute "pubDate",objArticle.PostTime

			If objArticle.CommNums>0 Then

				Dim i
				Dim objRS
				Set objRS=objConn.Execute("SELECT * FROM [blog_Comment] WHERE ([comm_ID]>0) AND ([log_ID]="&intID&") ORDER BY [comm_PostTime] DESC")

				Dim objComment

				Do While Not objRS.eof

					Set objComment=New TComment
					If objComment.LoadInfoByArray(Array(objRS("comm_ID"),objRS("log_ID"),objRS("comm_AuthorID"),objRS("comm_Author"),objRS("comm_Content"),objRS("comm_Email"),objRS("comm_HomePage"),objRS("comm_PostTime"),objRS("comm_IP"),objRS("comm_Agent"))) Then
						.AddItem "Re:"&objArticle.HtmlTitle,objComment.Email & " (" & objComment.Author & ")",objArticle.HtmlUrl & "#cmt" & objComment.ID,objComment.PostTime,objArticle.HtmlUrl & "#cmt" & objComment.ID,objComment.HtmlContent,"","","","",""
					End If
					Set objComment=Nothing

					objRS.MoveNext

				Loop

				objRS.close
				Set objRS=Nothing
			End If
		End If
		Set objArticle=Nothing


	End With

	Rss2Export.Execute

	Set Rss2Export = Nothing

	RssComment=True

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Save Blog Setting
'*********************************************************
Function SaveSetting()

	Dim i,j
	Dim s,t
	Dim strContent

	strContent=LoadFromFile(BlogPath & "/c_custom.asp","utf-8")

	Dim strZC_BLOG_HOST
	Dim strZC_BLOG_TITLE
	Dim strZC_BLOG_SUBTITLE
	Dim strZC_BLOG_NAME
	Dim strZC_BLOG_SUB_NAME
	Dim strZC_BLOG_CSS
	Dim strZC_BLOG_COPYRIGHT
	Dim strZC_BLOG_MASTER

	strZC_BLOG_HOST=Request.Form("edtZC_BLOG_HOST")

	strZC_BLOG_TITLE=Request.Form("edtZC_BLOG_TITLE")

	strZC_BLOG_SUBTITLE=Request.Form("edtZC_BLOG_SUBTITLE")

	strZC_BLOG_NAME=Request.Form("edtZC_BLOG_NAME")

	strZC_BLOG_SUB_NAME=Request.Form("edtZC_BLOG_SUB_NAME")

	strZC_BLOG_CSS=Request.Form("edtZC_BLOG_CSS")

	strZC_BLOG_COPYRIGHT=Request.Form("edtZC_BLOG_COPYRIGHT")

	strZC_BLOG_MASTER=Request.Form("edtZC_BLOG_MASTER")

	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_HOST",strZC_BLOG_HOST)
	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_TITLE",strZC_BLOG_TITLE)
	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_SUBTITLE",strZC_BLOG_SUBTITLE)
	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_NAME",strZC_BLOG_NAME)
	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_SUB_NAME",strZC_BLOG_SUB_NAME)
	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_CSS",strZC_BLOG_CSS)
	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_COPYRIGHT",strZC_BLOG_COPYRIGHT)
	Call SaveValueForSetting(strContent,True,"String","ZC_BLOG_MASTER",strZC_BLOG_MASTER)

	Call SaveToFile(BlogPath & "/c_custom.asp",strContent,"utf-8",False)

	SaveSetting=True

End Function
'*********************************************************





'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Post Tag
'*********************************************************
Function PostTag()

	Dim objTag
	Set objTag=New TTag
	objTag.ID=Request.Form("edtID")
	objTag.Name=Request.Form("edtName")
	objTag.Order=Request.Form("edtOrder")
	objTag.Intro=Request.Form("edtIntro")
	If objTag.Post Then PostTag=True
	Set objTag=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    Del Tag
'*********************************************************
Function DelTag(intID)

	Dim objTag
	Set objTag=New TTag
	objTag.ID=intID
	If objTag.Del Then DelTag=True
	Set objTag=Nothing

End Function
'*********************************************************




'/////////////////////////////////////////////////////////////////////////////////////////
'*********************************************************
' 目的：    Post KeyWord
'*********************************************************
Function PostKeyWord()

	Dim objKeyWord
	Set objKeyWord=New TKeyWord
	objKeyWord.ID=Request.Form("edtID")
	objKeyWord.Name=Request.Form("edtName")
	objKeyWord.Url=Request.Form("edtUrl")
	objKeyWord.Intro=Request.Form("edtIntro")
	If objKeyWord.Post Then PostKeyWord=True
	Set objKeyWord=Nothing

End Function
'*********************************************************




'*********************************************************
' 目的：    Del Tag
'*********************************************************
Function DelKeyWord(intID)

	Dim objKeyWord
	Set objKeyWord=New TKeyWord
	objKeyWord.ID=intID
	If objKeyWord.Del Then DelKeyWord=True
	Set objKeyWord=Nothing

End Function
'*********************************************************
%>