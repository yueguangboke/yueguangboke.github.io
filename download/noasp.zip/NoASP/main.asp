﻿<%@ LANGUAGE="VBSCRIPT" CODEPAGE="65001"%>
<% Option Explicit %>
<% 'On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<!-- #include file="..\..\c_option.asp" -->
<!-- #include file="..\..\..\zb_system\function\c_function.asp" -->
<!-- #include file="..\..\..\zb_system\function\c_system_lib.asp" -->
<!-- #include file="..\..\..\zb_system\function\c_system_base.asp" -->
<!-- #include file="..\..\..\zb_system\function\c_system_event.asp" -->
<!-- #include file="..\..\..\zb_system\function\c_system_manage.asp" -->
<!-- #include file="..\..\..\zb_system\function\c_system_plugin.asp" -->
<!-- #include file="..\p_config.asp" -->
<%
Call System_Initialize()
'检查非法链接
Call CheckReference("")
'检查权限
If BlogUser.Level>1 Then Call ShowError(6)
If CheckPluginState("NoASP")=False Then Call ShowError(48)
BlogTitle="NoASP 去ASP化"
%>
<!--#include file="..\..\..\zb_system\admin\admin_header.asp"-->
<!--#include file="..\..\..\zb_system\admin\admin_top.asp"-->
        <div id="divMain">
          <div id="ShowBlogHint">
            <%Call GetBlogHint()%>
          </div>
          <div class="divHeader"><%=BlogTitle%></div>
          <div class="SubMenu"><%=NoASP_SubMenu(0)%></div>
          <div id="divMain2">
            <script type="text/javascript">ActiveTopMenu("aPlugInMng");</script>

            <p>插件已生效，无需保存设置。开关都在 <b>zb_users/plugin/NoASP/include.asp</b> 的「开关区」，改数值后刷新前台即可。</p>

            <table border="1" width="100%" cellspacing="0" cellpadding="6" style="border-collapse:collapse;">
              <tr style="background:#f2f2f2;">
                <td width="22%"><b>处理项</b></td>
                <td width="20%"><b>当前设置</b></td>
                <td><b>说明</b></td>
              </tr>
              <tr>
                <td>指向 .asp 的 &lt;a&gt; 链接</td>
                <td><%=NoASP_UiAnchor(NoASP_AnchorMode)%></td>
                <td>0=去掉 a 标签、保留文字；1=整条链接连文字一起删除；2=保留链接，href 改成 #</td>
              </tr>
              <tr>
                <td>style.css.asp 等资源引用</td>
                <td><%=NoASP_UiBool(NoASP_KeepAssets,"保留","删除")%></td>
                <td>保留则页面样式正常；改成 False 会把 *.css.asp / *.js.asp 引用一起删掉，页面可能掉样式</td>
              </tr>
              <tr>
                <td>内联脚本中的 .asp</td>
                <td><%=NoASP_UiBool(NoASP_DropInlineJs,"整段删除","保留")%></td>
                <td>如主题里写死的 c_html_js.asp 调用脚本，整段 &lt;script&gt; 会被删掉</td>
              </tr>
              <tr>
                <td>浏览数（统计）</td>
                <td><%=NoASP_UiBool(NoASP_LockViewCount,"已停止","正常")%></td>
                <td>统计脚本 c_html_js_add.asp 被删除，前台不再触发 +1；数据库里已有的浏览数不会被改动</td>
              </tr>
              <tr>
                <td>浏览数（显示）</td>
                <td><%=NoASP_UiBool(NoASP_LockViewCount,"不显示","正常显示")%></td>
                <td>article/viewnums、article/addviewcount、article/loadviewcount 全部输出为空</td>
              </tr>
              <tr>
                <td>“浏览:”这类残留文字</td>
                <td><%=NoASP_UiBool(NoASP_DropViewLabel,"清掉","保留")%></td>
                <td>浏览数去掉后，紧跟在后的“浏览:”“阅读:”标签文字一并清掉</td>
              </tr>
              <tr>
                <td>评论提交框 / 提交按钮</td>
                <td><%=NoASP_UiMode(NoASP_CommentMode)%></td>
                <td>1=整块不输出（评论列表保留）；2=保留 HTML，用 CSS 隐藏</td>
              </tr>
            </table>

            <p style="margin-top:12px;color:#666;">
              注意：<br/>
              1) 删掉 .asp 链接后，站内导航会失去跳转能力（文字仍在），这是本插件的目的，不是故障。<br/>
              2) 文件重建（静态化）生成的页面同样会被处理，但已生成的旧静态文件要重建一次才会更新。<br/>
              3) 动态加载侧栏（IsDynamicLoadSildbar）、日历、验证码等都依赖 .asp，被删后不再工作。
            </p>

          </div>
        </div>
        <!--#include file="..\..\..\zb_system\admin\admin_footer.asp"-->

<%
Function NoASP_UiBool(v,strTrue,strFalse)
	If v = True Then
		NoASP_UiBool = strTrue
	Else
		NoASP_UiBool = strFalse
	End If
End Function

Function NoASP_UiAnchor(v)
	Select Case v
		Case 1
			NoASP_UiAnchor = "整条删除"
		Case 2
			NoASP_UiAnchor = "href 改为 #"
		Case Else
			NoASP_UiAnchor = "去掉标签保留文字"
	End Select
End Function

Function NoASP_UiMode(v)
	Select Case v
		Case 2
			NoASP_UiMode = "保留 HTML，CSS 隐藏"
		Case Else
			NoASP_UiMode = "整块删除"
	End Select
End Function
%>

<%Call System_Terminate()%>
