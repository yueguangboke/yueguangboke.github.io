﻿<!-- #include file="function.asp" -->
<%
'************************************************************************
' NoASP 1.0  （Z-BlogASP 2.x 插件）
' 作用：在前台页面输出阶段（动态浏览 / 文件重建 都会经过）做“去 ASP 化”处理
'
'   1. 删除页面中所有指向 .asp 的链接、脚本、表单、图片、iframe 等元素
'   2. 浏览数：去掉统计脚本（不再 +1），并把浏览数相关模板标签置空（不显示）
'   3. 文章单页里的 <script src="..c_html_js_add.asp"></script> 一并删除
'   4. 评论提交框和提交按钮不再输出（默认整块删除，也可改为 CSS 隐藏）
'
' 挂载点（见本文件下方 ActivePlugin_NoASP）：
'   Filter_Plugin_TArticle_Export_TemplateTags  单篇/列表项的模板标签（浏览数置空）
'   Filter_Plugin_TArticle_Build_TemplateTags   单页的模板标签（浏览数置空）
'   Filter_Plugin_TArticleList_Build_TemplateTags  列表页模板标签
'   Filter_Plugin_TArticle_Export_Template_Sub  评论提交框片段
'   Filter_Plugin_TArticle_Build_Template_Succeed      文章/页面整页 HTML
'   Filter_Plugin_TArticleList_Build_Template_Succeed  列表/首页整页 HTML
'************************************************************************

'==================== 开关区（改这里的值即可） ====================
Dim NoASP_AnchorMode 		' <a href="*.asp"> 怎么处理：0=去掉 a 标签保留文字；1=整条链接连文字一起删除；2=保留链接，href 改成 #
Dim NoASP_KeepAssets 		' True=保留 style.css.asp / *.js.asp 这类“资源型” .asp 引用（样式、脚本），False=连它一起删（页面会掉样式）
Dim NoASP_DropInlineJs 		' True=内联 <script> 里出现 .asp 的，整段脚本删掉
Dim NoASP_DropViewLabel 	' True=浏览数去掉后，把残留的“浏览:”“阅读:”等标签文字也清掉
Dim NoASP_CommentMode 		' 评论提交框：1=整块删除；2=保留 HTML 但用 CSS 隐藏
Dim NoASP_LockViewCount 	' True=浏览数模板标签全部置空（不显示）

Sub NoASP_Init()

	NoASP_AnchorMode = 0
	NoASP_KeepAssets = True
	NoASP_DropInlineJs = True
	NoASP_DropViewLabel = True
	NoASP_CommentMode = 1
	NoASP_LockViewCount = True

End Sub
'==================================================================

'注册插件
Call RegisterPlugin("NoASP","ActivePlugin_NoASP")

Function ActivePlugin_NoASP()

	Call NoASP_Init()

	'浏览数：模板标签置空（单篇 + 列表项 + 整页）
	Call Add_Filter_Plugin("Filter_Plugin_TArticle_Export_TemplateTags","NoASP_TagFilter")
	Call Add_Filter_Plugin("Filter_Plugin_TArticle_Build_TemplateTags","NoASP_TagFilter")
	Call Add_Filter_Plugin("Filter_Plugin_TArticleList_Build_TemplateTags","NoASP_TagFilter")

	'评论提交框
	Call Add_Filter_Plugin("Filter_Plugin_TArticle_Export_Template_Sub","NoASP_SubFilter")

	'整页 HTML：删 .asp 元素 / 删统计脚本 / 兜底清理
	Call Add_Filter_Plugin("Filter_Plugin_TArticle_Build_Template_Succeed","NoASP_PageFilter")
	Call Add_Filter_Plugin("Filter_Plugin_TArticleList_Build_Template_Succeed","NoASP_PageFilter")

End Function


Function InstallPlugin_NoASP()

	Call SetBlogHint(Empty,Empty,True)

End Function


Function UnInstallPlugin_NoASP()

	Call SetBlogHint(Empty,Empty,True)

End Function


'************************************************************************
' 模板标签过滤：浏览数相关标签置空
' 对应标签：article/viewnums、article/loadviewcount、article/addviewcount
'************************************************************************
Function NoASP_TagFilter(ByRef aryTemplateTagsName,ByRef aryTemplateTagsValue)

	Dim i

	On Error Resume Next

	If Not IsArray(aryTemplateTagsName) Then Exit Function

	If NoASP_LockViewCount = False Then Exit Function

	For i = 0 To UBound(aryTemplateTagsName)
		Select Case LCase(CStr(aryTemplateTagsName(i)))
			Case "article/viewnums","article/loadviewcount","article/addviewcount"
				aryTemplateTagsValue(i) = ""
		End Select
	Next

	On Error GoTo 0

End Function


'************************************************************************
' 评论提交框片段过滤：Template_Article_Commentpost
'************************************************************************
Function NoASP_SubFilter(ByRef Template_Article_Comment,ByRef Template_Article_Trackback,ByRef Template_Article_Tag,ByRef Template_Article_Commentpost,ByRef Template_Article_Navbar_L,ByRef Template_Article_Navbar_R,ByRef Template_Article_Mutuality)

	On Error Resume Next

	If NoASP_CommentMode = 1 Then
		Template_Article_Commentpost = ""
	End If

	On Error GoTo 0

End Function


'************************************************************************
' 整页 HTML 过滤：删除所有含 .asp 的元素、清理浏览数残留
'************************************************************************
Function NoASP_PageFilter(ByRef html)

	Dim re,mt,s,lastEnd,i,posHead,css

	On Error Resume Next

	If IsNull(html) Then Exit Function
	If Len(html) = 0 Then Exit Function

	Set re = New RegExp
	re.IgnoreCase = True
	re.Global = True

	'--------------------------------------------------------------
	' 1. 带 .asp 地址的 <script src="..."> </script>（含 c_html_js_add.asp / c_html_js.asp?date=now）
	'--------------------------------------------------------------
	re.Pattern = "<script[^>]*src\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>[\s\S]*?</script>"
	html = re.Replace(html,"")

	'自闭合形式 <script ... src="x.asp" />
	re.Pattern = "<script[^>]*src\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*?/>"
	html = re.Replace(html,"")

	'--------------------------------------------------------------
	' 2. 内联 <script> 段落里出现 .asp 的，整段删除
	'--------------------------------------------------------------
	If NoASP_DropInlineJs = True Then

		re.Pattern = "<script[^>]*>[\s\S]*?</script>"
		Set mt = re.Execute(html)

		If mt.Count > 0 Then

			s = html
			html = ""
			lastEnd = 0

			For i = 0 To mt.Count - 1
				html = html & Mid(s,lastEnd+1,mt(i).FirstIndex-lastEnd)
				If InStr(1,mt(i).Value,".asp",vbTextCompare) = 0 Then
					html = html & mt(i).Value
				End If
				lastEnd = mt(i).FirstIndex + mt(i).Length
			Next

			html = html & Mid(s,lastEnd+1)

		End If

		Set mt = Nothing

	End If

	'--------------------------------------------------------------
	' 3. 样式表等 <link href="...asp">
	'--------------------------------------------------------------
	If NoASP_KeepAssets = False Then
		re.Pattern = "<link[^>]*href\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>"
		html = re.Replace(html,"")
	End If

	'--------------------------------------------------------------
	' 4. iframe / object / img / embed / frame / base：整块删除
	'--------------------------------------------------------------
	re.Pattern = "<iframe[^>]*src\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>[\s\S]*?</iframe>"
	html = re.Replace(html,"")

	re.Pattern = "<object[^>]*(?:data|src)\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>[\s\S]*?</object>"
	html = re.Replace(html,"")

	re.Pattern = "<img[^>]*src\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>"
	html = re.Replace(html,"")

	re.Pattern = "<embed[^>]*(?:src|href)\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>"
	html = re.Replace(html,"")

	re.Pattern = "<frame[^>]*src\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>"
	html = re.Replace(html,"")

	re.Pattern = "<base[^>]*href\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>"
	html = re.Replace(html,"")

	'--------------------------------------------------------------
	' 5. 提交到 .asp 的表单（如搜索框、评论框），整块删除
	'--------------------------------------------------------------
	re.Pattern = "<form[^>]*action\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>[\s\S]*?</form>"
	html = re.Replace(html,"")

	'--------------------------------------------------------------
	' 6. 指向 .asp 的 <a> 链接
	'--------------------------------------------------------------
	If NoASP_AnchorMode = 1 Then

		re.Pattern = "<a\s[^>]*href\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>[\s\S]*?</a>"
		html = re.Replace(html,"")

	ElseIf NoASP_AnchorMode = 2 Then

		'只在 <a ...> 内替换 href，避免把样式表等其它元素的地址也改掉
		re.Pattern = "(<a\s[^>]*href\s*=\s*)(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')"
		html = re.Replace(html,"$1""#""")

	Else

		re.Pattern = "<a\s[^>]*href\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')[^>]*>([\s\S]*?)</a>"
		html = re.Replace(html,"$1")

	End If

	'--------------------------------------------------------------
	' 7. 兜底：仍有 href/src 指向 .asp 的（残缺标签、其他标签）
	'    KeepAssets=True 时保留 *.css.asp / *.js.asp 这类资源地址
	'--------------------------------------------------------------
	re.Pattern = "(?:href|src)\s*=\s*(?:""[^""]*\.asp[^""]*""|'[^']*\.asp[^']*')"
	Set mt = re.Execute(html)

	If mt.Count > 0 Then

		s = html
		html = ""
		lastEnd = 0

		For i = 0 To mt.Count - 1
			html = html & Mid(s,lastEnd+1,mt(i).FirstIndex-lastEnd)
			If NoASP_KeepAssets = True Then
				If InStr(1,LCase(mt(i).Value),".css.asp",vbTextCompare) > 0 Or InStr(1,LCase(mt(i).Value),".js.asp",vbTextCompare) > 0 Then
					html = html & mt(i).Value
				End If
			End If
			lastEnd = mt(i).FirstIndex + mt(i).Length
		Next

		html = html & Mid(s,lastEnd+1)

	End If

	Set mt = Nothing

	'--------------------------------------------------------------
	' 8. 浏览数：去掉空计数器容器，再清掉残留的“浏览:”标签文字
	'--------------------------------------------------------------
	If NoASP_LockViewCount = True Then
		re.Pattern = "<span[^>]*class\s*=\s*""[^""]*(?:AddView|LoadView)[^""]*""[^>]*>\s*</span>"
		html = re.Replace(html,"")
	End If

	If NoASP_DropViewLabel = True Then
		re.Pattern = "(?:\s*[|｜/]\s*)?(?:浏览量|浏览数|浏览|阅读量|阅读数|阅读|人气|围观)\s*[：:]\s*(?=<|&nbsp;|$)"
		html = re.Replace(html,"")
	End If

	'--------------------------------------------------------------
	' 9. 评论提交框：隐藏模式下补一条 CSS（主题里写死的提交框也能盖住）
	'--------------------------------------------------------------
	If NoASP_CommentMode = 2 Then

		css = "<style type=""text/css"">#divCommentPost,#frmSumbit,.commentpost,.comment-post,.post-comment{display:none !important;}</style>"

		posHead = InStr(1,html,"</head>",vbTextCompare)
		If posHead > 0 Then
			html = Left(html,posHead-1) & css & Mid(html,posHead)
		Else
			html = css & html
		End If

	End If

	Set re = Nothing

	On Error GoTo 0

End Function
%>
