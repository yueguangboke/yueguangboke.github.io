﻿<%
'****************************************
' NoASP 子菜单
'****************************************
Function NoASP_SubMenu(id)

	Dim aryName,aryPath,aryFloat,aryInNewWindow,i

	aryName=Array("插件说明")
	aryPath=Array("main.asp")
	aryFloat=Array("m-left")
	aryInNewWindow=Array(False)

	For i=0 To Ubound(aryName)
		NoASP_SubMenu=NoASP_SubMenu & MakeSubMenu(aryName(i),aryPath(i),aryFloat(i)&IIf(i=id," m-now",""),aryInNewWindow(i))
	Next

End Function
%>
