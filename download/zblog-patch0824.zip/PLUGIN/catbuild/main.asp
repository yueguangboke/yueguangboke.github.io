<%@ CODEPAGE=65001 %>
<%
'///////////////////////////////////////////////////////////////////////////////
'// 插件应用:    Z-Blog(http://www.rainbowsoft.org)
'// 插件制作:    williamlong(http://www.williamlong.info)
'// 备    注:    生成静态HTML的分类目录的小程序
'// 最后修改：   2005-8-31
'// 最后版本:    1.4
'///////////////////////////////////////////////////////////////////////////////
%>
<% Option Explicit %>
<% On Error Resume Next %>
<% Response.Charset="UTF-8" %>
<% Response.Buffer=True %>
<!-- #include file="../../c_option.asp" -->
<!-- #include file="../../c_function.asp" -->
<!-- #include file="../../c_system_lib.asp" -->
<!-- #include file="../../c_system_base.asp" -->
<!-- #include file="../../c_system_event.asp" -->
<%

Call System_Initialize()

'检查非法链接
Call CheckReference("")

'检查权限
If BlogUser.Level>1 Then Call ShowError(6) 

MakeCatReBuild

%>

<script language="javascript">
    alert ("文件生成成功.");
	document.location.href="javascript:history.go(-1)"
</script>

<% 
Call System_Terminate()

If Err.Number<>0 then
	Call ShowError(0)
End If
'********************************************************
%>